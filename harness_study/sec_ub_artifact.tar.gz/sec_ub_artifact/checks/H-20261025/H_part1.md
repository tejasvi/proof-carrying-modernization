# Pre-registration H, part one: veriforch's record (prep, before the sweep GO)

Prereg: <ROOT>/fv_paper/prereg/PREREG_H_v1.md (sha256 5116f81e…), selection addendum <ROOT>/fv_paper/prereg/H/ADDENDUM_H_selection.md
(59f12f15…). session's rulings of 2026-10-25 (DEVIATIONS, 17:0xZ) apply; they are restated where used below.

## Selection and corpora (step 1, frozen in the addendum)

- notes/theorem/H_selection.tsv (327ce976…) from scripts/h_select.py (0bd4880b…): 5 entry points, processing order
  cgif/cgif_file_fuzzer, cgif/cgif_rgb_fuzzer, yajl-ruby/json_fuzzer, cjson/cjson_read_fuzzer, bzip2/bzip2_compress_target.
- targets/theorem_corpora/CORPORA.tsv (7913304c…) from scripts/h_corpus.py (59feb284…): yajl 1 input (manifest 95a9a86c…),
  cJSON 14 inputs (437886e2…), bzip2 "no public corpus" (ruling: not a part-two candidate), cgif 46 + 9 seeds to be
  generated after the GO (scripts/h_cgif_seeds.py, gcc lines, each generator run in bwrap; 43 of the 46 index seeds have
  an upstream sha256 in fuzz/seeds.sha256, the other 12 seeds are reported as unchecked).

## Builds (prep)

- Semantics: cirlean ffab71e (deps/cirlean-ffab71e, for all of H). Targets targets/h_<project>_<harness>.toml and
  .compile_commands.json from scripts/h_targets.py (5f70fec1…): upstream trees at Theorem's commits in
  targets/theorem_src/<project>@<commit12>/, harness and library unmodified, the library's defines as Theorem's recipe
  built it (cJSON: CMake Release + ENABLE_LOCALES, as Theorem and OSS-Fuzz). `vo scan` per target; the .cir file of every
  translation unit is in runs/h_<project>_<harness>/v0/<variant>/ (kept for the per-program type-punning check).
- Runner: vo-cirrun built for ffab71e, runs/_tools/vo_cirrun_ffab71e/.lake/build/bin/vo-cirrun (36067693…). Wrapper
  scripts/h_cirrun1.py (014ee990…): LLVMFuzzerTestOneInput(array of exactly the input's bytes, size), 60 s wall.
- Native: official LLVM 20.1.8 Linux-X64 (Theorem's clang version), scratch/theorem/toolchain/; verification record
  toolchain/VERIFY.txt (430f6ba9…): sha256 equal to the GitHub release API digest 1ead36b3…, `gh attestation verify`
  with the release's sigstore bundle rc 0 (SLSA v1, release-binaries.yml@refs/tags/llvmorg-20.1.8, source 87f0227c),
  negative control (truncated file) rc 1. Builds plain / ubsan / asan / asan-ubsan of the 5 harnesses
  (scratch/theorem/native/bin20/, scripts/h_native.py c4eca293…, driver scripts/h_native/h_driver.c 3b9b3fae…): Theorem's
  compile flags without the RISC-V target flags, the library's defines, docs/building.md's sanitizer flags. Every
  native run is in bubblewrap (the Rust worker's flags, notes/thrift/T1_rsts.md: all namespaces unshared, read-only
  /usr /etc, binary and input; writable only a per-run work dir; private tmpfs /tmp) under run1.sh. ASan runs:
  ASAN_OPTIONS=detect_leaks=0:allocator_may_return_null=1:abort_on_error=1 (Theorem's sealed settings) plus symbolize=1.
- Controls (in bwrap): heap overflow -> ASan report, symbolized, rc 134; signed overflow -> UBSan trap, SIGILL, rc 132;
  a /tmp write stays in the sandbox.

## The locator (approved by main and session)

- Rule: on every input its outcome, message and stdout, with its location tags removed, must equal the pinned
  vo-cirrun's byte for byte; otherwise that input gets no location ("locator failure").
- scripts/h_locator_gen.py (34a309bf…) checks the sha256 of the pinned CIR/Semantics/Eval.lean (9b593b6d…) and of
  tools/vo_cirrun/VoCirRun.lean (7b99affa…), copies cirlean's interpreter mutual block verbatim (functions renamed
  h<Name>, `partial def`), wraps calls (`⟦call <fn|model|extern|unknown> <callee> @line:col⟧`) and loops
  (`⟦loop @line:col⟧`) so that a UB result carries its backtrace, and copies vo-cirrun's driver. Output
  scratch/theorem/locator/HLocate.lean (1292a11c…); lakefile.toml (1210cdc3…), lean-toolchain (ca5f1f60…); binary
  scratch/theorem/locator/.lake/build/bin/h-locate (224c90e2…). The pin directory was unchanged by the build.
- Differential check (scripts/h_locdiff.py f928182e…) on the 5 smoke inputs: 5 equal, 0 failures
  (scratch/theorem/smoke/LOCDIFF_smoke.tsv, e529b906…; the sweep driver's own check on the same inputs, with the
  current h_cirrun1.py: scratch/theorem/sweeptest/out/*/LOCDIFF.tsv, all equal).
- Distinct finding = (raw message, innermost program function, site: innermost loop or model/external call site).

## Triage classes (session)

- (i) C UB: a sanitizer report, or a reading that cites the C standard clause.
- (ii) model limit: the code reason plus the C rule that makes the code defined.
- (iii) unconfirmed, listed apart.
- An entry point is "UB found" only with at least one class-(i) location; one whose inputs stop only at model limits
  is "blocked", with the limit named.

## Smoke results (one input per harness; crafted for cgif and bzip2, corpus seed for yajl, crafted for cJSON)

| harness | cirlean (pinned) | located at | natives (4 builds) |
|---|---|---|---|
| yajl json_fuzzer, seed.json | normal end (0) | - | all silent |
| cJSON, `1011{"a":[true,null,"x"],"b":{}}\0` | UB: realloc: not a live heap block | cJSON$ensure, call realloc @cJSON.c:500:37 | all silent |
| cgif file, 30 bytes | UB: memcpy: byte-level access not modelled | cgif_file_fuzzer$readdata | all silent |
| cgif rgb, 24 bytes | UB: memcpy: byte-level access not modelled | cgif_rgb_fuzzer$readdata | all silent |
| bzip2, "hello" | UB: read of an indeterminate or ill-typed value | blocksort$fallbackSort, loop @blocksort.c:254:4 | all silent |

Model-limit readings (class (ii) candidates; code reason and C rule):
- cJSON realloc: cJSON_PrintBuffered(json, 1, fmt) mallocs 1 byte and ensure() grows it with realloc. cirlean types
  untyped heap storage at its first cast as T when n == sizeof T (a single object, CIR/Std/Models.lean:449-456), and
  its realloc model accepts only array-typed or untyped blocks (Models.lean:899-918). C: realloc of a pointer returned
  by malloc is defined (C11 7.22.3.5).
- cgif memcpy: the harness's readdata memcpy's 2 input bytes (a uint8_t array) into a uint16_t member; cirlean models
  memcpy only between whole objects of one type. C: memcpy copies the bytes as unsigned char (C11 7.24.2.1), and the
  object's representation is its bytes (6.2.6.1p4), so the copy is defined.

## Asides (outside the census)

- bzip2 fallbackSort (no public corpus, so not in the census; class (ii) per main's reading): the sentinel loop's
  SET_BH(nblock+2i) reads bhtab word (nblock+63)>>5 when nblock % 32 >= 1, one word past the 2 + nblock/32 words
  zeroed in the malloc'd s->ftab. The word lies inside the 65537-word allocation (no overflow), and it is allocated
  storage of type UInt32, which has no trap representations: under C11 6.2.6.1p5 and 6.3.2.1p2 the read yields an
  unspecified value, not undefined behaviour. cirlean is stricter than the standard here.
- cJSON's corpus: all 14 OSS-Fuzz seeds end in '\n', so the harness returns at `if(data[size-1] != '\0') return 0;`
  and part one runs nothing beyond its input checks. With ENABLE_LOCALES (Theorem's and OSS-Fuzz's configuration), every
  number parsed or printed calls localeconv(), which cirlean does not model.

## Compute so far

runs/theorem_h/guard_step1.log 0.005 core-h; runs/theorem_h/guard_prep.log about 0.06 core-h.

## Early run on a corpus input (before the sweep; disclosed to session by main)

- 2026-10-25T17:33:08Z to 17:33:09Z (runs/theorem_h/guard_prep.log, guard pid 2124766): at main's request (timing
  before the projection), h-cirrun ran one corpus input, cgif/cgif_file_fuzzer `noise256_large.seed` (9,000,791 bytes),
  under run1.sh -m 32 with /usr/bin/time. The log runs/theorem_h/timing_noise256_large.seed.out (c98b5720…) holds its
  outcome line (`UB: memcpy: byte-level access not modelled`) and the timing (0.76 s wall, max RSS 419,656 KB). It is
  kept as it is. The sweep runs this input again from frozen copy v2; the early run is not a sweep result.
- Main's ruling (2026-10-25 ~17:40Z): no other run on corpus inputs before the sweep; synthetic inputs only.
  The synthetic 9 MB timing run of the same minute is runs/theorem_h/timing_cgif_file_fuzzer.synthetic9M.bin.out
  (ecb867ed…).
- Earlier corpus-input runs: none. The smoke inputs were crafted (cgif, bzip2, cJSON) or OSS-Fuzz's yajl seed.json,
  which is also yajl's whole corpus (smokes at 16:50Z on the semantics and 16:55Z / 17:11Z natively).

## Part one: results (sweep GO 2026-10-25 after T2's launch at 18:25:08Z)

- Run: 2026-10-25T18:27:01Z to 18:27:44Z, from frozen copy v2 scratch/theorem/frozen_H2_20261025T1732Z (SHA256SUMS
  4a7e8de9…, PINS.sha256 c1284fde…, both `sha256sum -c` rc 0 at 18:26:55Z). nice 19, at most 8 jobs, dispatched only at
  load ≤ 450 and ≥ 150 GB available (load was about 207). Output runs/theorem_h/partone/: SUMMARY.tsv (c889e5f4…),
  TRIAGE.tsv (c7ab3630…), per entry point RESULTS.tsv, DISTINCT.tsv, LOCDIFF.tsv, RUNNERDIFF.tsv and one JSON per run.
  Per-input list with sha256, outcome and location: notes/theorem/H_part1_results.tsv (d226fdf2…; the same sha256s as
  the corpus manifests).
- Runs: 185 (70 h-cirrun, the runner of record; 70 locator; 37 vo-cirrun on the inputs ≤ 16 KB; 8 native runs).
  Locator check 70/70 equal; runner equivalence 37/37 equal. CPU 0.0245 core-h (the sum of the runs' own rusage;
  the guard log's per-job totals round to 0.000).

| entry point | inputs | outcome per input | PREREG_H outcome |
|---|---|---|---|
| cgif/cgif_file_fuzzer | 46 | 46 unsupported construct (`memcpy: byte-level access not modelled`, one location) | blocked: memcpy of input bytes into a uint16_t member (byte-level copy not modelled) |
| cgif/cgif_rgb_fuzzer | 9 | 9 unsupported construct (same message, one location) | blocked: same limit |
| yajl-ruby/json_fuzzer | 1 | 1 normal end | no UB on the corpus |
| cjson/cjson_read_fuzzer | 14 | 14 normal end | no UB on the corpus; all 14 OSS-Fuzz seeds end in '\n', so the harness returns at `if(data[size-1] != '\0') return 0;` and nothing beyond its input checks runs |
| bzip2/bzip2_compress_target | 0 | - | no public corpus |

- Distinct findings and triage (TRIAGE.tsv), both class (ii), model limit:
  - cgif_file_fuzzer$readdata (fuzz/cgif_file_fuzzer.c:16-21, the memcpy at :18), reached as processInput (:133) >
    read_gifconfig (:93) > readdata (:38), the first read: 2 bytes into gconfig.width. 46 of 46 inputs.
  - cgif_rgb_fuzzer$readdata (fuzz/cgif_rgb_fuzzer.c:14-23, the memcpy at :16), reached as processInput (:120) >
    read_gifconfig (:85) > readdata (:34), the first read: 2 bytes into gconfig.width. 9 of 9 inputs.
  - Code reason: readdata memcpy's 2 bytes of the const uint8_t input array into a uint16_t member. cirlean ffab71e
    models memcpy only between element ranges or whole objects of one type (CIR/Std/Models.lean, typedRange?).
  - C rule that makes it defined: memcpy copies the bytes as unsigned char (C11 7.24.2.1) into the object
    representation of the uint16_t (6.2.6.1p4); the member's declared type stays its effective type (6.5p6); an
    exact-width uint16_t has no padding bits (7.20.1.1), so every byte pattern is a value.
  - Sanitizers: the first input of each (all_optim.seed, rgb_255colors.seed) on plain, ubsan, asan and asan-ubsan:
    all silent.
  - No class (i) and no class (iii) finding. No entry point is "UB found".
- Part-two candidates under PREREG_H's rule (harness builds and all corpus inputs run without an unsupported
  construct; bzip2 excluded by session's ruling): yajl-ruby/json_fuzzer only. cgif_file_fuzzer and cgif_rgb_fuzzer are out,
  since every input stops at the memcpy limit.
