import VO.v0.cjson_parse_fuzzer.cJSON_Delete
#print axioms VO.v0.cjson_parse_fuzzer.cJSON_Delete_spec
