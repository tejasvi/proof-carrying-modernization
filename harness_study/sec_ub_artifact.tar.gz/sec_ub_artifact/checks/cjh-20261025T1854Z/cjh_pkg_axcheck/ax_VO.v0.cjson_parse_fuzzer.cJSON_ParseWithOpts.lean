import VO.v0.cjson_parse_fuzzer.cJSON_ParseWithOpts
#print axioms VO.v0.cjson_parse_fuzzer.cJSON_ParseWithOpts_spec
