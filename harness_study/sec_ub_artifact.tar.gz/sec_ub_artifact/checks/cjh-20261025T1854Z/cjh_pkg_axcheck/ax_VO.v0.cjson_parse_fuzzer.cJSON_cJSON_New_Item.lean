import VO.v0.cjson_parse_fuzzer.cJSON_cJSON_New_Item
#print axioms VO.v0.cjson_parse_fuzzer.cJSON_cJSON_New_Item_spec
