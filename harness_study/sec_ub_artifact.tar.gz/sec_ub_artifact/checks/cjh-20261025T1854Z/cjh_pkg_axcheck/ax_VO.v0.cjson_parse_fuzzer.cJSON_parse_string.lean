import VO.v0.cjson_parse_fuzzer.cJSON_parse_string
#print axioms VO.v0.cjson_parse_fuzzer.cJSON_parse_string_spec
