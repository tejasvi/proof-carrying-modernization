# The cJSON harness theorem: statement and the definitions it uses

Copy: replay/cjh-20261025T1854Z/lean_v266d1ed (veriforch package of runs/cjson_parse, cirlean 266d1ed). Files here,
verbatim from the copy (sha256 in SHA256SUMS):

- `harness_theorem_header.lean`: lines 1-17 of VO/v0/cjson_parse_fuzzer/LLVMFuzzerTestOneInput.lean (imports,
  options, the theorem's header up to `:= by`).
- `Entry.lean`: VerifOrch/Cir/Entry.lean, whole (InitExt, CStrAt, MainArgs, ReadableBuf). Same sha256 as the copy's
  file (f13154a6...).
- `cirlean_defs_used.lean`: from cirlean 266d1ed, `Res`, `Res.holds`, `Calls`, `Returns` (CIR/Logic/WP.lean; `Returns`
  is cirlean's, not Entry.lean's), `evalCall`, `allocHeap` (malloc's model), and the generated `ctx`.
- `check_statement.lean` / `.out`: `#check` and `#print` of the same names in a fresh Lean process on the copy's
  oleans, plus `fn_LLVMFuzzerTestOneInput.sym = "LLVMFuzzerTestOneInput" := rfl`.
- `cjson_parse_fuzzer.c`, `reachable.txt`: the harness source that the ClangIR's locations name
  (<ROOT>/veriforch/scratch/cjson_parse_harness/), and veriforch's list of reachable units there.

## The statement (verbatim)

```lean
theorem LLVMFuzzerTestOneInput_spec (data : Ptr) (size : Int) (m : Mem) (hm : VerifOrch.Cir.InitExt module m) (hsize : 0 ≤ size ∧ size ≤ 18446744073709551615) (hbuf : VerifOrch.Cir.ReadableBuf module.initMem.next m data size) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr data, .int size] m (fun _ _ => True) := by
```

in namespace `VO.v0.cjson_parse_fuzzer`, with `open CIR Gen.v0_cjson_parse_fuzzer.Unit`: `module` and `ctx` are the
generated program (both translation units linked, `ctx := Ctx.ofModule module`). The unit record gives the statement
origin as "mechanical" and `assumes: []`; assumed.json is `[]`. The binders are only the input, the memory and the three
preconditions: no hypothesis about a callee.

## What it claims, in plain words

For every pointer `data`, integer `size` and memory `m` such that

- (memory) `m` is well formed (no block at or above `m.next`) and extends the program's initial memory: every block
  below the initial memory's counter (the globals) is unchanged, so the globals hold their initial values;
- (input) `0 ≤ size ≤ 2^64 - 1`, and `data` points to element 0 of a live block numbered at or above that counter (not
  a global) whose type is `uint8_t[size]` and whose `size` elements are all initialised bytes 0..255; ReadableBuf also
  requires `size < 2^63` (no object larger than PTRDIFF_MAX), so the effective bound is every buffer of fewer than 2^63
  bytes;

the call `LLVMFuzzerTestOneInput(data, size)` in cirlean's semantics terminates, reaches no undefined behaviour and
returns normally (no escaping exception). `Returns ... (fun _ _ => True)` puts no condition on the return value or the
final memory. In cirlean an undefined behaviour is any `Res.ub` result, which also covers a call to a function without
a body or a library model; non-termination is `Res.div`; both make `Returns` false. Nothing is claimed about the parse
result (no functional correctness).

Limits of the semantics that the claim inherits: malloc's model always succeeds ("Allocation is assumed to succeed",
CIR/Std/Models.lean:451), so cJSON's allocation-failure paths are not covered; library calls on the path (strtod,
strncmp, strlen, ...) run cirlean's models; the typed-memory defect (punned accesses) is checked separately (cirpun,
../cirpun/).

## The variant (DEVIATIONS 2026-10-25T16:59Z: parse-only variant of cjson_read_fuzzer, locales off)

- The statement does not show it: it names only `fn_LLVMFuzzerTestOneInput` of the generated module.
- The ClangIR does. cjson_parse_fuzzer.cir is the module
  "<ROOT>/veriforch/scratch/cjson_parse_harness/cjson_parse_fuzzer.c"; its only callees are
  cJSON_ParseWithOpts and cJSON_Delete (one call each), and the source it names opens with "Parse-only variant of
  cJSON's OSS-Fuzz harness fuzzing/cjson_read_fuzzer.c (same input checks, same parse call; the printing and minify
  branches are left out)".
- Locales off: in cJSON.cir, `get_decimal_point` returns the constant 46 ('.') (cJSON.cir:9003-9008), and neither .cir
  mentions `localeconv`; cJSON.c (same directory) has the localeconv branch under `#ifdef ENABLE_LOCALES` (lines 48,
  281), so ENABLE_LOCALES was undefined when the ClangIR was made. The .cir files do not record -D flags, and the run
  directory holds no build-flag file (only the two .cir files and the JSON records).
- cirpun's closure from LLVMFuzzerTestOneInput has 15 functions, the 15 units (= reachable.txt without its TU entry).
