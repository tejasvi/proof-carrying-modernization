import VO.v0.cjson_parse_fuzzer.LLVMFuzzerTestOneInput

#check @VO.v0.cjson_parse_fuzzer.LLVMFuzzerTestOneInput_spec
#print VerifOrch.Cir.InitExt
#print VerifOrch.Cir.ReadableBuf
#print CIR.Returns
#print CIR.Calls
#print CIR.Res.holds
#print Gen.v0_cjson_parse_fuzzer.Unit.ctx
example : Gen.v0_cjson_parse_fuzzer.Unit.fn_LLVMFuzzerTestOneInput.sym = "LLVMFuzzerTestOneInput" := rfl
#print axioms VO.v0.cjson_parse_fuzzer.LLVMFuzzerTestOneInput_spec
