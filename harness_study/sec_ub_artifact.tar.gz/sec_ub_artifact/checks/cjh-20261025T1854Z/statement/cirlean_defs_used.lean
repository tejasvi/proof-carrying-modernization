-- CIR/Semantics/Basic.lean:13-19
inductive Res (α : Type) where
  | ok (a : α)
  | ub (msg : String)
  /-- Non-termination: the bottom element of the flat order used by
  `partial_fixpoint`. -/
  | div
  deriving Inhabited

-- CIR/Logic/WP.lean:15-19
/-- `r` terminates without undefined behaviour with a result satisfying `Q`. -/
def Res.holds {α : Type} (r : Res α) (Q : α → Prop) : Prop :=
  match r with
  | .ok a => Q a
  | _ => False

-- CIR/Logic/WP.lean:54-64
/-- Calling `sym` terminates without undefined behaviour and its outcome
(`Exit.ret`/`Exit.exn` and the final memory) satisfies `Q`. -/
def Calls (ctx : Ctx) (sym : String) (args : List Val) (m : Mem) (Q : Exit → Mem → Prop) : Prop :=
  (evalCall ctx sym args m).holds fun r => Q r.1 r.2

/-- A function returns normally (no exception) with `post` holding. -/
def Returns (ctx : Ctx) (sym : String) (args : List Val) (m : Mem)
    (post : Option Val → Mem → Prop) : Prop :=
  Calls ctx sym args m fun e m' => match e with
    | .ret v => post v m'
    | _ => False

-- CIR/Semantics/Eval.lean:980-999
/-- Call a function by symbol: its native model if it has one, else its body
in a fresh SSA environment. -/
def evalCall (ctx : Ctx) (sym : String) (args : List Val) (m : Mem) : Res (Exit × Mem) :=
  match ctx.mod.findFunc? sym with
  | none => .ub ("call to an unknown function " ++ sym)
  | some fd =>
    match fd.model with
    | some mdl => Std.runModel ctx mdl args m
    | none =>
      match fd.body with
      | none => .ub ("call to an external function without a model: " ++ sym)
      | some body => do
        let (e, σ) ← evalRegion ctx body args ⟨m, fun _ => none, []⟩
        match e with
        | .ret v => pure (.ret v, σ.mem)
        | .exn x =>
          if fd.nothrow then .ub "exception escaped a noexcept function"
          else pure (.exn x, σ.mem)
        | _ => .ub "function body exited without cir.return"
partial_fixpoint

-- CIR/Std/Models.lean:449-456
/-- Heap storage of `n` bytes (`operator new`, `malloc`, `calloc`): untyped
until its first cast to `T*`, which gives it the type `T` (or `T[n / sizeof T]`),
zero-initialised for `calloc`. Allocation is assumed to succeed. -/
def allocHeap (m : Mem) (n : Int) (zero : Bool) : Res (Exit × Mem) :=
  -- untyped storage of `n` bytes: `.array (.other "heap") n` (`"heap0"`:
  -- zero-filled), typed at its first cast
  let (b, m) := m.alloc .heap (.array (.other (if zero then "heap0" else "heap")) n.toNat) .undef
  retv (.ptr (.loc b [])) m

-- CIR/Syntax.lean:40-41
  /-- `!cir.int<s, 32>` / `!cir.int<u, 8>` (aliases `!s32i`, `!u8i`, ...). -/
  | int (signed : Bool) (width : Nat)

-- Gen/v0_cjson_parse_fuzzer/Unit.lean:143
def ctx : Ctx := Ctx.ofModule module
