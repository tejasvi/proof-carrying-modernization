/* Parse-only variant of cJSON's OSS-Fuzz harness fuzzing/cjson_read_fuzzer.c (same input checks, same parse call;
   the printing and minify branches are left out). Written for veriforch's parse-only harness theorem: for every
   input buffer, no undefined behaviour. */
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "cJSON.h"

int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size); /* required by C89 */

int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size)
{
    cJSON *json;
    size_t offset = 4;
    int require_termination;

    if(size <= offset) return 0;
    if(data[size-1] != '\0') return 0;
    if(data[0] != '1' && data[0] != '0') return 0;
    if(data[1] != '1' && data[1] != '0') return 0;
    if(data[2] != '1' && data[2] != '0') return 0;
    if(data[3] != '1' && data[3] != '0') return 0;

    require_termination = data[1] == '1' ? 1 : 0;

    json = cJSON_ParseWithOpts((const char*)data + offset, NULL, require_termination);

    if(json == NULL) return 0;

    cJSON_Delete(json);

    return 0;
}
