import CIR
import Gen.v0_cjson_parse_fuzzer.Unit
import VerifOrch.Cir.Entry
import VO.v0.cjson_parse_fuzzer.cJSON_ParseWithOpts
import VO.v0.cjson_parse_fuzzer.cJSON_Delete

open CIR Gen.v0_cjson_parse_fuzzer.Unit

set_option maxHeartbeats 4000000

namespace VO.v0.cjson_parse_fuzzer

set_option cir.inline false in
set_option maxHeartbeats 400000000 in
@[cir_spec]
theorem LLVMFuzzerTestOneInput_spec (data : Ptr) (size : Int) (m : Mem) (hm : VerifOrch.Cir.InitExt module m) (hsize : 0 ≤ size ∧ size ≤ 18446744073709551615) (hbuf : VerifOrch.Cir.ReadableBuf module.initMem.next m data size) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr data, .int size] m (fun _ _ => True) := by
