#!/usr/bin/env python3
"""Proof size of veriforch's cJSON harness theorem: Lean lines of the modules in the harness module's import closure,
split by role. Line rule and closure walk as in tools/proof_lines.py (non-blank lines, without `--` lines and /- -/
blocks; imports followed within the given prefixes only).

Usage: cjh_proof_lines.py PKG_ROOT CIR_ROOT OUT_TSV ROOT_MODULE
Roles:
  generated     Gen.*: the program as cir2lean generated it from the ClangIR (module, functions, constants)
  entry         VerifOrch.*: the fixed calling-convention definitions of the mechanical statement (InitExt, ReadableBuf)
  statement     VO unit modules (not *_given): the theorem headers, from the `theorem` line to the line that ends
                with `:= by` or `:=`
  proof         VO unit modules (not *_given): every other line (imports, options, tactic scripts)
  proof_given   VO *_given modules and GivenPA.*: proof modules supplied whole (bridge lemmas, step bundles)
  library:CIR.X cirlean's semantics and proof library, by first two name components (reported apart)
"""
import os, re, sys

IMP = re.compile(r"^\s*(?:(?:public|private)\s+)?(?:meta\s+)?import\s+(.+)$")
THM = re.compile(r"^(?:@\[[^\]]*\]\s*)?(?:private\s+)?theorem\s+\S+")


def counted(p):
    """Line numbers (0-based) that tools/proof_lines.py's lean_lines counts."""
    out, inc = [], False
    for i, l in enumerate(open(p, encoding="utf-8", errors="replace")):
        if inc:
            if "-/" in l:
                inc = False
            continue
        s = l.strip()
        if not s or s.startswith("--"):
            continue
        if s.startswith("/-"):
            if "-/" not in s:
                inc = True
            continue
        out.append(i)
    return out


def header_lines(p):
    """0-based line numbers of theorem headers (theorem line through the `:= by` / `:=` line)."""
    lines = open(p, encoding="utf-8", errors="replace").read().splitlines()
    hs, i = set(), 0
    while i < len(lines):
        if THM.match(lines[i]):
            j = i
            while j < len(lines) and not re.search(r":=\s*(by)?\s*$", lines[j]):
                j += 1
            hs.update(range(i, min(j, len(lines) - 1) + 1))
            i = j + 1
        else:
            i += 1
    return hs


def main():
    pkg, cir, out, rootmod = sys.argv[1:5]
    roots = {"Gen": pkg, "GivenPA": pkg, "VO": pkg, "VerifOrch": pkg, "CIR": cir}
    todo, seen, rows = [rootmod], set(), []
    while todo:
        m = todo.pop(0)
        if m in seen or m.split(".")[0] not in roots:
            continue
        seen.add(m)
        p = os.path.join(roots[m.split(".")[0]], *m.split(".")) + ".lean"
        if not os.path.exists(p):
            sys.exit("missing source " + p)
        for line in open(p, encoding="utf-8", errors="replace"):
            mm = IMP.match(line.split("--", 1)[0])
            if mm:
                todo.extend(mm.group(1).split())
        c = counted(p)
        top = m.split(".")[0]
        if top == "Gen":
            rows.append((m, "generated", len(c)))
        elif top == "VerifOrch":
            rows.append((m, "entry", len(c)))
        elif top == "GivenPA" or m.endswith("_given") or re.search(r"_given\d+$", m):
            rows.append((m, "proof_given", len(c)))
        elif top == "VO":
            hs = header_lines(p)
            st = sum(1 for i in c if i in hs)
            rows.append((m, "statement", st))
            rows.append((m, "proof", len(c) - st))
        else:
            rows.append((m, "library:" + ".".join(m.split(".")[:2]), len(c)))
    with open(out, "w") as f:
        f.write("module\trole\tlines\n")
        for r in rows:
            f.write("%s\t%s\t%d\n" % r)
    tot, nmod = {}, {}
    for m, r, n in rows:
        k = "library" if r.startswith("library:") else r
        tot[k] = tot.get(k, 0) + n
        nmod.setdefault(k, set()).add(m)
    print("%d modules in closure" % len(seen & {r[0] for r in rows}))
    for k in ("generated", "entry", "statement", "proof", "proof_given", "library"):
        print("%-12s %7d lines in %d modules" % (k, tot.get(k, 0), len(nmod.get(k, ()))))


main()
