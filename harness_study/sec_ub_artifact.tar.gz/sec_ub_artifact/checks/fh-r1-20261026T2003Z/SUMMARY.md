# R1: full cJSON harness theorem at size < 2^61 (checks/fh-r1-20261026T2003Z; copies replay/fh-r1-20261026T2003Z)

RESULT: R1 agrees with the delivery on every point checked: 23/23 announced hashes; the harness call-graph closure has
32 units, all proved with assumes []; the statement is the mechanical entry statement with hsmall : size < 2^61; 90/90
theorem names std; kernel replay of the entry module's 285-module closure all rc 0 (242 package modules + 43 CIR);
ClangIR and Gen regenerate byte-identically from cJSON v1.7.18's sources; proof lines 15,849 reproduced.

Object: veriforch runs/cjson_full/lean_c4ef58d, theorem VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec, on
cirlean pin deps/cirlean-c4ef58d. Checked by the evidence owner's fork, 2026-10-26 from 20:03Z (date -u).

## Copies and announced hashes
- Copies (tools/replay_copy.sh, guarded): package with oleans (830M, 245 Lean sources) and the pin (598M, 184 Lean
  sources, .git excluded). `diff -rq` against both originals: empty (copy_identity/). The pin copy also equals
  <ROOT>/cirlean_frozen/c4ef58d_20261025 (diff -rq empty), the build my fhpin-c4ef58d-20261025 check covers; the pin
  worktree is at c4ef58d4ee99, clean.
- Records (v0/: verify.json, assumed.json, units.json, 113 unit records, callgraph.json, both .cir), the four logs
  (verify/guard canon1, canon2), the producer notes (PROVENANCE_FH, PROOF_SIZE_FH .md/.tsv, AGENT_COST_FH_R1 and _WHOLE
  .md/.json), scheduler.py, adapter.py, targets/cjson_full.toml and .given.json copied: 23/23 announced sha256 equal
  (announced.tsv, announced_check.txt).

## Records
- verify.json: 113 units of the linked module: 32 proved, 35 stuck, 46 blocked. Call-graph closure of
  LLVMFuzzerTestOneInput (callgraph.json edges, own fixpoint): 32 units, every one proved, trust kernel, assumes []
  (closure_unit_status.tsv); statement origins 26 given, 5 llm, 1 mechanical (the entry). So all 35 stuck and 46 blocked
  units lie outside the harness's call graph. assumed.json = {}.
- Run logs: canonical run 1 (guard exit 0, 4.855 core-h) ended with the entry unit stuck; run 2 (guard exit 0, 2.753
  core-h, 09:14:33Z) proved it (bundle fh3_entry_c4ef58d, main GivenPA.FHEntry; "attempt 1 (given) -> proved").

## Statement (statement/check_statement.out, fresh process, rc 0)
- #check: forall data size m, InitExt module m -> 0 <= size /\ size <= 2^64-1 -> ReadableBuf module.initMem.next m data
  size -> size < 2^61 -> Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr data, .int size] m (fun _ _ => True);
  sym = "LLVMFuzzerTestOneInput" by rfl. InitExt, ReadableBuf (0 <= n < 2^63, a live uint8 array block of n bytes after
  the globals), Returns/Calls/Res.holds printed: as in the parse-only check (cjh-20261025T1854Z).
- The header is byte-identical to adapter.py (a8d438df) `_entry_contract` for LLVMFuzzerTestOneInput with
  harness_size_log2 = 61 (targets/cjson_full.toml); the Gen declaration has params [(.ptr (.int false 8)),
  (.int false 64)], ret (.int true 32).
- In words: for every well-formed memory that keeps the globals at their initial values and every live uint8_t[size]
  block after the globals holding bytes 0..255 with size < 2^61, the call of the unmodified upstream harness terminates,
  reaches no undefined behaviour in cirlean's semantics (calls without a body or model are undefined there) and returns
  normally; nothing is said about the result. The proof term applies FHEntry.entry_main to the six callee theorems
  (ParseWithOpts, PrintBuffered, Print, PrintUnformatted, Minify, Delete).

## Axioms
- axcheck.py --leanpath (fresh process per module): 90/90 theorem names of the 32 VO modules with theorems: std
  (r1_pkg_axcheck/axcheck.tsv). The other two VO modules of the closure (scc_cJSON_parse_array_given1,
  scc_cJSON_print_array_given1) only import.
- #print axioms in the statement check: the entry theorem, FHEntry.entry_main and the six callee theorems print exactly
  [propext, Classical.choice, Quot.sound].
- Source grep over the 285 closure files: no axiom declaration; the 10 sorry/native_decide/implemented_by hits are
  comments, docstrings, the cir_native macro definition (unused: the axiom lists carry no Lean.ofReduceBool) and
  loopHead's implemented_by (compiled code only).

## Kernel replay
- leancheck1lp.sh per module (pkg_replay_jobs.py lists; pjobs_v3 N = 2; LEAN_PATH = the copies): 242/242 package modules
  rc 0 (Gen 127, GivenPA 76, VO 34, VerifOrch 5 incl. VerifOrch.Cir.TestEval outside the closure) and the 43 CIR modules
  of the closure rc 0 (r1_pkgall_replay/, r1_cir_replay/).
- closure_verdicts.py (closure_harness.tsv): the entry module's import closure has 285 modules: CIR 43 + the import-only
  root CIR, Gen 127, GivenPA 76, VO 34, VerifOrch 4; every one rc 0 (exit 0). Same set with every VO theorem module as a
  root (closure_probe_all.tsv).
- 287 guarded jobs (statement check, axiom check, 285 replays), 0.106 core-h metered; module wall times sum to 575 s;
  largest GivenPA.POSFinal2 63.0 s, Gen.v0_fuzzing_cjson_read_fuzzer.Unit 60.1 s; the entry module 1.0 s.

## Sources and build inputs
- Source root targets/theorem_src/cjson@acc76239bee0: cJSON.c 75c51de8..., cJSON.h 0578cc29..., fuzzing/cjson_read_fuzzer.c
  a8e94434... equal `git show v1.7.18` (acc76239bee0) in veriforch's local cJSON clone (not a partial clone). The harness is
  the unmodified upstream fuzzing/cjson_read_fuzzer.c.
- Flags (h_cjson_cjson_read_fuzzer.compile_commands.json): cJSON.c with -DNDEBUG -DCJSON_EXPORT_SYMBOLS
  -DCJSON_API_VISIBILITY -DENABLE_LOCALES -fvisibility=hidden; the harness without defines. Locales are on:
  get_decimal_point calls localeconv (2 mentions in cJSON.cir); cirlean c4ef58d models localeconv as a read-only
  record lconv whose decimal_point points to a read-only s8[2] "." (CIR/Std/Models.lean:1015-1023).
- cJSON.cir c1358084..., cjson_read_fuzzer.cir 34aaccad....
- Regeneration (regen/): both .cir files recompiled from those sources with the recorded clang
  (<ROOT>/cirlean_work/toolchain/upstream-4955d32b, -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering, the
  recorded per-file flags) are byte-identical to the run's .cir files; `cir2lean --link Gen.v0_fuzzing_cjson_read_fuzzer.Unit`
  of the pin copy on them (as veriforch's build.py) gives a Gen tree equal to the package's (diff -r empty, 128 files;
  125 functions, 113 with a body, 7 records, 19 globals).

## Scans
- cirpun f365f63 (tool SHA256SUMS verified; --root LLVMFuzzerTestOneInput, both .cir): 32 functions in the closure
  (= the 32 units); FLAG 2, CHAR 0, SIGN 110, AGG 0, NOOBJ 2, ASSUME 0 (cirpun/).
  - FLAG: the two loads in get_decimal_point (cJSON.c:283) through localeconv's result; in the model they read the
    s8* member decimal_point of the lconv record and element 0 of the s8 array, both typed as loaded.
  - NOOBJ: the stores through return_parse_end in cJSON_ParseWithLengthOpts (cJSON.c:1146, 1174), under
    `if (return_parse_end)` / `!= NULL`; the harness passes NULL (cjson_read_fuzzer.c:34): untaken.
- Hexadecimal FP constants: 1 in cJSON.cir (line 711, a float NaN in cJSON_GetNumberValue), 0 in the harness .cir.
  cJSON_GetNumberValue is outside the 32-unit closure, and cJSON.cir references it only at its definition (no call, no
  address use), so the front end's hex-FP reading cannot reach the theorem.

## Proof size (lines_cmp.tsv; tools/fh_lines_cmp.py, the paper's line rule)
- My whole-file recount of the 285 closure files: 40,213 lines (CIR 11,536, Gen 12,820, GivenPA 11,994, VO 3,067,
  VerifOrch 796). The producer's PROOF_SIZE_FH.tsv rows sum to 40,213; by role O 11,354, E 3,835, M 224, V 436
  (O+E+M+V = 15,849 as announced), B 1,185, G 12,820, U 78, L 10,281.
- 275 files equal file by file; 10 unit modules differ by exactly the 901 lines that the producer counts in 10 tactics
  files (every tactics line occurs in its unit module). Whole-file sha256 column: 257/257 equal.

## Cost and core-hours (recorded, not re-measured)
- Guard logs: canon1 4.855 + canon2 2.753 core-h (= 7.608 as announced); 38.010 core-h dedup for all FH logs is the
  producer's figure.
- AGENT_COST_FH_R1.json: per-agent USD = token counts x Opus 5.5 list prices ($4 in, $20 out, $0.20 cache read, $5
  5-min write), sum $427.37 (worker-cjson-0 37.01, worker-cjson-1 130.28, worker-cjson-2 145.32, worker-fh-3 114.76); _WHOLE $540.34.
  Arithmetic re-checked from the ledgers' token counts; not re-derived from transcripts.

## Disclosures
- One `git status --porcelain` on the producer worktree deps/cirlean-c4ef58d (it may refresh that worktree's index stat
  cache); later git reads used --no-optional-locks.

## Questions for producers
- None.
