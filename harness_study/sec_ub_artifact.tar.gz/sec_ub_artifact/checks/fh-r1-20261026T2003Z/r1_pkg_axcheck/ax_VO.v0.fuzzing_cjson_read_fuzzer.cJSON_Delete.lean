import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_Delete
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.cJSON_Delete_spec
