import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_Minify
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.cJSON_Minify_spec
