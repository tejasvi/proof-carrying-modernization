#!/bin/bash
# R1 queue, then R2-64 queue; N=2 Lean jobs, load 450, MemAvailable 150 GB, floor 2 (pjobs_v3).
export TMPDIR=<ROOT>/fv_paper/replay/fh-r1-20261026T2003Z/tmp
python3 -I <ROOT>/fv_paper/evidence/tools/pjobs_v3.py <ROOT>/fv_paper/evidence/checks/fh-r1-20261026T2003Z/r1_jobs_all.txt 2 450 150 2 <ROOT>/fv_paper/evidence/checks/fh-r1-20261026T2003Z/r1_pjobs.log
echo "r1 queue rc=$? $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> <ROOT>/fv_paper/evidence/checks/fh-r1-20261026T2003Z/queue_status.txt
export TMPDIR=<ROOT>/fv_paper/replay/fh-r264-20261026T2003Z/tmp
python3 -I <ROOT>/fv_paper/evidence/tools/pjobs_v3.py <ROOT>/fv_paper/evidence/checks/fh-r264-20261026T2003Z/r264_jobs_all.txt 2 450 150 2 <ROOT>/fv_paper/evidence/checks/fh-r264-20261026T2003Z/r264_pjobs.log
echo "r264 queue rc=$? $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> <ROOT>/fv_paper/evidence/checks/fh-r1-20261026T2003Z/queue_status.txt
