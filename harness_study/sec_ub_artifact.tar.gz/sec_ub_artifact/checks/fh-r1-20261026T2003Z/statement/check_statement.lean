import VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput

#check @VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec
#print VerifOrch.Cir.InitExt
#print VerifOrch.Cir.ReadableBuf
#print CIR.Returns
#print CIR.Calls
#print CIR.Res.holds
#print Gen.v0_fuzzing_cjson_read_fuzzer.Unit.ctx
example : Gen.v0_fuzzing_cjson_read_fuzzer.Unit.fn_LLVMFuzzerTestOneInput.sym = "LLVMFuzzerTestOneInput" := rfl
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec
#print axioms FHEntry.entry_main
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.cJSON_ParseWithOpts_spec
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.cJSON_PrintBuffered_spec
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.cJSON_Print_spec
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.cJSON_PrintUnformatted_spec
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.cJSON_Minify_spec
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.cJSON_Delete_spec
