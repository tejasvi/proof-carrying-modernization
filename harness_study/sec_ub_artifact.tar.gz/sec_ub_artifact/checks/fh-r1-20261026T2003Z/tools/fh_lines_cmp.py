#!/usr/bin/env python3
"""Recount Lean lines of every module in a harness closure (whole files; the paper's line rule as in
tools/proof_lines.py: non-blank lines without `--` lines and /- -/ blocks) and compare with a producer's per-row
proof-size TSV (file[#part], role, lines, bytes, sha256), whose rows of one file are summed.

Usage: fh_lines_cmp.py CLOSURE_TSV PKG_ROOT CIR_ROOT PRODUCER_TSV OUT_TSV
CLOSURE_TSV: closure_verdicts.py output (prefix, module, ...); CIR modules are read from CIR_ROOT, others from PKG_ROOT.
"""
import collections, hashlib, os, sys

def lean_lines(p):
    n, inc = 0, False
    for l in open(p, encoding="utf-8", errors="replace"):
        if inc:
            if "-/" in l:
                inc = False
            continue
        s = l.strip()
        if not s or s.startswith("--"):
            continue
        if s.startswith("/-"):
            if "-/" not in s[2:]:
                inc = True
            continue
        n += 1
    return n

def main():
    clo, pkg, cir, ptsv, out = sys.argv[1:6]
    mine = {}
    for line in open(clo):
        f = line.rstrip("\n").split("\t")
        if len(f) < 2:
            continue
        pre, mod = f[0], f[1]
        rel = os.path.join(*mod.split(".")) + ".lean"
        root, key = (cir, "cirlean-c4ef58d/" + rel) if pre == "CIR" else (pkg, rel)
        p = os.path.join(root, rel)
        mine[key] = (pre, lean_lines(p), hashlib.sha256(open(p, "rb").read()).hexdigest())
    prod = collections.defaultdict(int)
    prod_roles = collections.defaultdict(int)
    prod_role_of = collections.defaultdict(set)
    whole_sha = {}
    for i, line in enumerate(open(ptsv)):
        f = line.rstrip("\n").split("\t")
        if i == 0 or len(f) < 5:
            continue
        file, role, n, sha = f[0], f[1], int(f[2]), f[4]
        base = file.split("#")[0]
        prod[base] += n
        prod_roles[role] += n
        prod_role_of[base].add(role)
        if "#" not in file:
            whole_sha[base] = sha
    rows, same, diff, only_mine, only_prod = [], 0, 0, 0, 0
    for k in sorted(set(mine) | set(prod)):
        a = mine.get(k)
        b = prod.get(k)
        if a and b is not None:
            st = "same" if a[1] == b else "differs"
            same += st == "same"; diff += st == "differs"
        elif a:
            st = "closure_only"; only_mine += 1
        else:
            st = "producer_only"; only_prod += 1
        rows.append([k, a[0] if a else "", str(a[1]) if a else "", str(b) if b is not None else "",
                     ",".join(sorted(prod_role_of.get(k, []))), st])
    with open(out, "w") as o:
        o.write("file\tprefix\tmy_lines\tproducer_lines\tproducer_roles\tstatus\n")
        for r in rows:
            o.write("\t".join(r) + "\n")
    tot_mine = sum(v[1] for v in mine.values())
    by_pre = collections.Counter()
    for v in mine.values():
        by_pre[v[0]] += v[1]
    print(f"closure files {len(mine)}, lines {tot_mine}; by prefix " + ", ".join(f"{k} {v}" for k, v in sorted(by_pre.items())))
    print(f"producer rows summed per file: {len(prod)} files, lines {sum(prod.values())}; by role " +
          ", ".join(f"{k} {v}" for k, v in sorted(prod_roles.items())))
    print(f"files: same {same}, differs {diff}, closure_only {only_mine}, producer_only {only_prod}")
    shabad = [k for k, s in whole_sha.items() if k in mine and mine[k][2] != s]
    print(f"whole-file sha256 rows compared {sum(1 for k in whole_sha if k in mine)}, mismatches {len(shabad)}" +
          (": " + " ".join(shabad[:10]) if shabad else ""))

main()
