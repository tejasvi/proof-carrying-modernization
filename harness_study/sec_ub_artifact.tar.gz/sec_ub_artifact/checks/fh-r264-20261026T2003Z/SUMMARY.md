# R2-64, full cJSON harness on patched cJSON at size < 2^63 (checks/fh-r264-20261026T2003Z; copies replay/fh-r264-20261026T2003Z)

RESULT: R2-64 agrees with the delivery on every point checked: 19/19 announced hashes; the harness call-graph closure
has 32 units, all proved with assumes [], print_string_ptr on the patched body included; the statement is the mechanical
entry statement with no hsmall (only ReadableBuf's size < 2^63); 90/90 theorem names std; kernel replay of the
285-module closure all rc 0; the source is cJSON v1.7.18 plus one 7-line hunk inside print_string_ptr, and ClangIR and
Gen regenerate byte-identically from it; proof lines 15,846 reproduced.

Object: veriforch runs/cjson_full_r2_64/lean_c4ef58d, theorem VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec,
on cirlean pin deps/cirlean-c4ef58d (the same pin as R1; the replay uses the R1 check's pin copy, identical to the
producer's pin and to <ROOT>/cirlean_frozen/c4ef58d_20261025). Checked by the evidence owner's fork, 2026-10-26 from 20:03Z.

## Copies and announced hashes
- Package copy with oleans (840M, 245 Lean sources): `diff -rq` against the original empty (copy_identity/).
- Records (v0/: verify.json, assumed.json, 113 unit records, callgraph.json, both .cir), logs (verify/guard r2a, r2a2),
  producer notes (PROVENANCE_FH_R2_64 and PROOF_SIZE_FH_R2_64 .md in their 14:59Z versions, PROOF_SIZE_FH_R2_64.tsv,
  AGENT_COST_FH_R2_64 .md/.json), scheduler.py, adapter.py, targets/cjson_full_r2_64.toml and .given.json: 19/19
  announced sha256 equal (announced_check.txt). cirlean's bundle <ROOT>/cirlean_work/deliver/print_string_ptr_r2_64
  copied (SHA256SUMS 583dd36a... as announced; sha256sum -c OK; PrintStringPtrSpec.lean a535959d... as announced).

## Records
- verify.json: 113 units, 32 proved, 35 stuck, 46 blocked; the call-graph closure of LLVMFuzzerTestOneInput is the same
  32 units as R1, every one proved, trust kernel, assumes []; origins 26 given, 5 llm, 1 mechanical; assumed.json = {}.
- Run A (guard exit 124, 1.235 core-h, 10:04:39Z) ended before the entry; run A2 (guard exit 0, 6.143 core-h, 14:47:40Z)
  proved it (bundle fh3_entry_r2_c4ef58d, main GivenPA.FHEntry; "attempt 1 (given) -> proved").

## Statement (statement/check_statement.out)
- #check (fresh process, rc 0): forall data size m, InitExt module m -> 0 <= size /\ size <= 2^64-1 -> ReadableBuf
  module.initMem.next m data size -> Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr data, .int size] m
  (fun _ _ => True). No hsmall binder: the only size bound is ReadableBuf's 0 <= n < 2^63. The printed definitions
  (InitExt, ReadableBuf, Returns, Calls, Res.holds, ctx) and the sym rfl check are identical to R1's output.
- The header is byte-identical to adapter.py (a8d438df) `_entry_contract` without harness_size_log2 (the toml has only a
  comment line about it); Gen params [(.ptr (.int false 8)), (.int false 64)], ret (.int true 32).
- In words: as R1, for every live uint8_t[size] input block with size < 2^63 (ReadableBuf's bound), on the patched
  cJSON 1.7.18: the call terminates, reaches no undefined behaviour in cirlean's semantics and returns normally.

## Axioms
- axcheck.py --leanpath (fresh process per module): 90/90 theorem names of the 32 VO modules with theorems: std
  (r264_pkg_axcheck/axcheck.tsv); the two other VO closure modules only import.
- #print axioms (statement check): the entry theorem, FHEntry.entry_main and the six callee theorems print exactly
  [propext, Classical.choice, Quot.sound].
- Source grep over the 285 closure files: no axiom declaration; the same 10 comment/docstring/macro/implemented_by hits
  as R1.

## Kernel replay
- leancheck1lp.sh per module (pjobs_v3 N = 2): 242/242 package modules rc 0 and the 43 CIR modules of the closure rc 0
  (r264_pkgall_replay/, r264_cir_replay/; the CIR modules from the R1 check's pin copy).
- closure_verdicts.py (closure_harness.tsv): 285 modules (CIR 43 + import-only root, Gen 127, GivenPA 76, VO 34,
  VerifOrch 4), every one rc 0.
- 287 guarded jobs, 0.105 core-h metered; module wall times sum to 562 s; largest Gen...Unit 63.6 s, GivenPA.POSFinal2
  54.3 s.

## Source and build inputs
- Source root (toml): veriforch/scratch/fh3/r2/src/cjson@acc76239bee0_fix. Against cJSON v1.7.18 (acc76239bee0) only
  cJSON.c differs (ad801935...; byte-equal to targets/theorem_src/cjson@acc76239bee0_fix/cJSON.c; the root's
  cJSON.c.orig equals v1.7.18's cJSON.c). The difference is one hunk of 7 added lines (patched lines 962-968, after
  v1.7.18 line 961), inside print_string_ptr (v1.7.18 lines 911-1030). cJSON.h and fuzzing/cjson_read_fuzzer.c equal
  v1.7.18. Flags as R1 (fix.compile_commands.json: -DNDEBUG -DCJSON_EXPORT_SYMBOLS -DCJSON_API_VISIBILITY
  -DENABLE_LOCALES -fvisibility=hidden for cJSON.c). cJSON.cir (bca5fae3...) locations name only the patched root
  (6,114 references, 0 to the v1.7.18 root). FIX.diff: sha256 afdae1ca... recorded; the file was not opened.

- Regeneration (regen/): both .cir files recompiled from the patched root with the recorded clang
  (<ROOT>/cirlean_work/toolchain/upstream-4955d32b) and flags are byte-identical to the run's; `cir2lean --link` of the pin on
  them gives a Gen tree equal to the package's (diff -r empty, 128 files).

## Package against R1 (pkgdiff/, pkg_r1_vs_r264.diffq.txt)
- Gen: only F/fn_cJSON_print_string_ptr.lean (25 changed lines; sha256 d63e6efa... as announced, equal to the bundle's
  listed copy) and manifest.json (source line maps shifted by the 7 added lines, file hashes).
- After normalising the bound literal (2^61 -> 2^63, decimal forms included), the module renames PrintSpecs ->
  PrintSpecsX and PrintLemmas -> PrintLemmasX, the removal of hsmall, and comments, code changes remain in:
  - GivenPA/PrintStringPtrSpec.lean: 31 lines (the print_string_ptr theorem on the patched body); its body equals
    cirlean's bundle copy apart from `import Strict` -> `import GivenPA.Strict`;
  - GivenPA/FHEntryB1, FHEntryF0, FHEntryF1: 20 lines each: the string bound passed to the print theorems is derived
    from ReadableBuf's size < 2^63 (hs63) instead of hsmall, local name h61 -> hN63.
  The other 24 differing files and the two renamed modules (VO print/minify modules, GivenPA print steps, FHEntry, the
  entry) differ only by those normalisations; lakefile/manifest only by the package name.

## Scans
- cirpun f365f63: 32 functions in the closure; FLAG 2, CHAR 0, SIGN 110, AGG 0, NOOBJ 2, ASSUME 0, the same sites as R1:
  FLAG at cJSON.c:283 (get_decimal_point through localeconv's result, typed reads of the model's lconv objects); NOOBJ
  at patched cJSON.c:1153 and 1181 (= v1.7.18 1146, 1174; null-guarded, the harness passes NULL).
- Hexadecimal FP: 1 in cJSON.cir (line 711, float NaN in cJSON_GetNumberValue, outside the closure, referenced only at its
  definition), 0 in the harness .cir.

## Proof size (lines_cmp.tsv)
- My recount of the 285 closure files: 40,229 lines (Gen 12,839, GivenPA 11,991, VO 3,067, VerifOrch 796, CIR 11,536);
  the producer's rows sum to 40,229; O 11,351, E 3,835, M 224, V 436 (O+E+M+V = 15,846 as announced), B 1,185, G 12,839
  (+19 against R1), U 78, L 10,281. 275 files equal; 10 unit modules differ by exactly the 901 lines of 10 tactics files
  (every tactics line occurs in its module); whole-file sha256: 257/257 equal.

## Cost and core-hours (recorded, not re-measured)
- Guard logs r2a 1.235 + r2a2 6.143 core-h; the producer's 9.638 core-h dedup includes 0.693 core-h of scratch sessions
  also counted in R1.
- AGENT_COST_FH_R2_64.json: per-agent USD = token counts x list prices; sum $29.59 (worker-cjson-1 14.71, worker-cjson-2 5.12,
  worker-fh-3 9.76); not re-derived from transcripts.

## Questions for producers
- None.
