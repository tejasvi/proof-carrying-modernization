import PSF2

#check @utf16_round4
#print axioms utf16_round4
#check @utf16_values
#print axioms utf16_values
#check @utf16_strong
#print axioms utf16_strong
#check @parse_string_core
#print axioms parse_string_core
#check @parse_string_strong
#print axioms parse_string_strong
