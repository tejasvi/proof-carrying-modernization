import cJSON_Delete_fuzz_harness
import ParseArrayStepStrong
import POSFinal4
import CycleSpecsP2N

theorem parse_object_step_specP : ParseObjectStepSpecP := parse_object_step

#check @CJReal.delete_forest
#print axioms CJReal.delete_forest
#check @parse_array_step
#print axioms parse_array_step
#check @parse_array_step_specP
#print axioms parse_array_step_specP
#check @CIR.po_bsw_spec_n
#print axioms CIR.po_bsw_spec_n
#check @CIR.po_new_spec_n
#print axioms CIR.po_new_spec_n
#check @CIR.po_ps_spec_s2
#print axioms CIR.po_ps_spec_s2
#check @CIR.po_pv_spec_s2
#print axioms CIR.po_pv_spec_s2
#check @CIR.CJ.printable_setPrev
#print axioms CIR.CJ.printable_setPrev
#check @CIR.CJ.forestPrintable_set_head_prev
#print axioms CIR.CJ.forestPrintable_set_head_prev
#check @CIR.CJ.forestPrintable_snoc
#print axioms CIR.CJ.forestPrintable_snoc
#check @CIR.CJ.height_setPrev
#print axioms CIR.CJ.height_setPrev
#check @CIR.CJ.forestHeight_set_head_prev
#print axioms CIR.CJ.forestHeight_set_head_prev
#check @CIR.CJ.forestHeight_append
#print axioms CIR.CJ.forestHeight_append
#check @CIR.CJ.forestHeight_snoc_le
#print axioms CIR.CJ.forestHeight_snoc_le
#check @CIR.PAL.height_newItem
#print axioms CIR.PAL.height_newItem
#check @CIR.PAL.success_ch_s2
#print axioms CIR.PAL.success_ch_s2
#check @CIR.po_new_spec_v4
#print axioms CIR.po_new_spec_v4
#check @parse_object_step
#print axioms parse_object_step
#check @parse_object_step_specP
#print axioms parse_object_step_specP
