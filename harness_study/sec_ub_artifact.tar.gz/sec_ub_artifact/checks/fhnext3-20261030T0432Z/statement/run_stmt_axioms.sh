#!/bin/bash
set -e
C="<ROOT>/fv_paper/evidence/checks/fhnext3-20261030T0432Z"
R="<ROOT>/fv_paper/replay/fhnext3-20261030T0432Z"
export TMPDIR="$R/tmp"
PIN="<ROOT>/cirlean_frozen/next3_7c73739_20261030/.lake/build/lib/lean"
CH="<ROOT>/cirlean_work/scratch/next3_chain/chain_pin7c73739"
H="<ROOT>/cirlean_work/scratch/next3_chain"
LEAN="<ROOT>/.elan/toolchains/leanprover--lean4---v4.35.0/bin/lean"
ulimit -v $((32*1024*1024))

LP_V4="$PIN:$CH/gen:$CH/spec/out_v4:$CH/spec/out:$CH/chain"
LP_V3="$PIN:$CH/gen:$CH/spec/out_v3:$CH/spec/out:$CH/chain"
LP_V0="$PIN:$CH/gen:$CH/spec/out:$CH/chain"

chk() {
  local name="$1" lp="$2" f="$3"
  echo "=== $name ==="
  LEAN_PATH="$lp" "$LEAN" -j 1 -DElab.async=false "$f"
}

cat > "$C/statement/check_v3.lean" << 'L2'
import EnsureUpdateOffset
import Minify
import MinifyString
import PrintArrayStep
import PrintObjectStep
import PrintStringPtrClosed

#check @ensure_spec
#print axioms ensure_spec
#check @update_offset_spec
#print axioms update_offset_spec
#check @skip_oneline_spec
#print axioms skip_oneline_spec
#check @skip_multiline_spec
#print axioms skip_multiline_spec
#check @minify_spec
#print axioms minify_spec
#check @minify_string_spec
#print axioms minify_string_spec
#check @print_array_step
#print axioms print_array_step
#check @print_object_step
#print axioms print_object_step
#check @print_string_ptr_spec_of
#print axioms print_string_ptr_spec_of
#check @print_string_ptr_spec
#print axioms print_string_ptr_spec
L2

chk "v4_bundles" "$LP_V4:$H/fh_pin7c73739_delete/out/cJSON_Delete_next2_v4:$H/fh_pin7c73739_pa/out/parse_array_strong_next2_v4:$H/fh_pin7c73739_po/out/parse_object_strong_next2_v4" "$C/statement/check_v4.lean"
chk "v3_bundles" "$LP_V3:$H/fh_pin7c73739_psp/out/ensure_update_offset_e6ac99a_s2:$H/fh_pin7c73739_minify/out/minify_e6ac99a_s2:$H/fh_pin7c73739_mstring/out/minify_string_e6ac99a_s2:$H/fh_pin7c73739_parray/out/print_array_step_e6ac99a_s2:$H/fh_pin7c73739_pobject/out/print_object_step_e6ac99a_s2:$H/fh_pin7c73739_psp/out/print_string_ptr_e6ac99a_s2" "$C/statement/check_v3.lean"
chk "v0_bundles" "$LP_V0:$H/fh_pin7c73739_pstring/out/parse_string_strong_e6ac99a" "$C/statement/check_v0.lean"
