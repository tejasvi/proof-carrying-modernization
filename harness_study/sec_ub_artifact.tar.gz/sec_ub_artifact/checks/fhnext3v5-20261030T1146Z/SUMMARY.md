RESULT: the CycleSpecsP2N v5 bundle set at cirlean next3 (7c73739: parse_array_strong_next3_v5, parse_object_strong_next3_v5, cJSON_Delete_next3_v5) passes all checks: all 3 announced SHA256SUMS hashes match (790e46ef..., 7946ff56..., 1db06365...) and every file in the 3 packages and SPEC_v5.sha256 verifies with sha256sum -c; all 238 distinct rows in the union of RESOLUTION_v5.tsv verify against their .oleans on disk (matching fhnext3-20261030T0432Z on every shared module except CycleSpecsP2N -> spec/out_v5/CycleSpecsP2N.olean 371b7033...); in a fresh Lean process (statement/check_v5.out, rc = 0), CJReal.delete_forest : DeleteSpecTheirsP, parse_array_step : ParseArrayStepSpecP, and parse_object_step : ParseObjectStepSpecP typecheck against CycleSpecsP2N v5 and all print [propext, Classical.choice, Quot.sound]; all 12 rebuilt v5 modules pass per-module leanchecker rc = 0 and all 3 root modules (cJSON_Delete_fuzz_harness 98.8 s, ParseArrayStepStrong 122.6 s, POSFinal4 152.5 s) pass leanchecker --fresh rc = 0 under ulimit -v 32 GiB.

# Independent check of the CycleSpecsP2N v5 FH bundles at cirlean next3 7c73739

## 1. Hashes, manifests, and resolution tables
- Package manifests (manifests_check.txt):
  - parse_array_strong_next3_v5: SHA256SUMS 790e46efcfb7914f9c96c6f8ac0770b3e3019ee48b4d7840c1a06737e04c9829 (11/11 OK).
  - parse_object_strong_next3_v5: SHA256SUMS 7946ff56daaac610c73ff7a6098d2d9c7bf415e468963f5aca35ffbab8b763fa (19/19 OK).
  - cJSON_Delete_next3_v5: SHA256SUMS 1db06365fbad51104f76278a9ebfc257bf306bb0c548889e181f3196decd6394 (9/9 OK).
  - SPEC_v5.sha256: CycleSpecsP2N.lean (0c5e9e53...), spec/out_v5/CycleSpecsP2N.olean (371b7033...), CJPrintN.olean (1f8d8e25...), PrintSpecsN.olean (254605c8...): 4/4 OK.
- Union of RESOLUTION_v5.tsv (union_resolution_v5.tsv, resolution_v5_check.txt): 238 distinct rows, 0 mismatches on disk; identical to fhnext3-20261030T0432Z's resolution table on all shared modules except CycleSpecsP2N (now pointing to spec/out_v5/CycleSpecsP2N.olean 371b7033...).

## 2. Source diffs against the v4 next3 bundles (source_diffs_v4_to_v5.txt)
- cJSON_Delete_fuzz_harness.lean: 0 diff against cJSON_Delete_next3.
- ParseArrayStepStrong.lean: adds hrel to the h_new binder in parse_array_step and discharges hrel at the New_Item call with decide/reduceMemberRelated; adds SpecCheckPA5.lean.
- parse_object_strong_next3_v5: PALibS2, POCloseS2, POCloseS3, POInvS2, PORecPun, POSpecS2, POSuccS2, and SpecCheckP4N.lean have 0 diff against parse_object_strong_next3; POSpecS4.lean adds po_new_spec_v5 passing hrel, and POSFinal4.lean adds hrel to the h_new binder of parse_object_step and passes po_new_spec_v5.

## 3. Statements, SpecCheck, and axioms in a fresh Lean process (statement/check_v5.out, rc = 0)
- Checked in a single fresh Lean process under g1.sh and ulimit -v 32 GiB against the frozen next3 pin (7c73739), chain_pin7c73739, spec/out_v5, and the hard-linked copy of the 12 rebuilt v5 .oleans (replay/fhnext3v5-20261030T1146Z/out):
  - example : DeleteSpecTheirsP := CJReal.delete_forest
  - example : ParseArrayStepSpecP := parse_array_step
  - theorem parse_object_step_specP : ParseObjectStepSpecP := fun k => parse_object_step k
- #print axioms on CJReal.delete_forest, parse_array_step, parse_array_step_specP, parse_object_step, parse_object_step_specP, and CIR.po_new_spec_v5 all print [propext, Classical.choice, Quot.sound].

## 4. Independent kernel replay (replay/)
- Per-module leancheck1lp.sh (under g1.sh, ulimit -v 32 GiB) on all 12 rebuilt v5 modules (CycleSpecsP2N 0.7 s, cJSON_Delete_fuzz_harness 2.6 s, ParseArrayStepStrong 25.2 s, PALibS2 0.9 s, POCloseS2 0.8 s, POCloseS3 0.8 s, POInvS2 0.8 s, PORecPun 0.7 s, POSFinal4 54.0 s, POSpecS2 0.8 s, POSpecS4 0.7 s, POSuccS2 0.7 s): 12/12 rc = 0 (the other 237 modules of RESOLUTION_v5.tsv were already replayed rc = 0 in checks/fhnext3-20261030T0432Z on byte-identical .oleans).
- Full-closure fresh kernel replay (leanchecker --fresh under coreh_guard_v2 and ulimit -v 32 GiB):
  - cJSON_Delete_fuzz_harness: rc = 0 (98.8 s)
  - ParseArrayStepStrong: rc = 0 (122.6 s)
  - POSFinal4: rc = 0 (152.5 s)
