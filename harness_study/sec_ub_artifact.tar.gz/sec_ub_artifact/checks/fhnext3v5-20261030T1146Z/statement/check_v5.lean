import CycleSpecsP2N
import cJSON_Delete_fuzz_harness
import ParseArrayStepStrong
import POSFinal4

open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit

example : DeleteSpecTheirsP := CJReal.delete_forest
example : ParseArrayStepSpecP := parse_array_step
theorem parse_object_step_specP : ParseObjectStepSpecP := fun k => parse_object_step k

#print ParseArrayStepSpecP
#print ParseObjectStepSpecP
#print DeleteSpecTheirsP
#print axioms CJReal.delete_forest
#print axioms parse_array_step
#print axioms parse_array_step_specP
#print axioms parse_object_step
#print axioms parse_object_step_specP
#print axioms CIR.po_new_spec_v5
