# cirlean pin c4ef58d for the full cjson_read_fuzzer harness: model changes and their tests

Branch `fuzzer266`, a line on top of 266d1ed (the parse-only harness's pin). Built snapshots:
`<ROOT>/cirlean_frozen/90b9c2f_20261025` and `<ROOT>/cirlean_frozen/c4ef58d_20261025` (CIR, cirrun, cir2lean, all Examples).

| commit | change | diff (sha256 in SHA256SUMS) |
|---|---|---|
| 90b9c2f64a641e1801900993f22f1e217b70a1e9 | realloc of a single-object heap block (malloc(1), malloc(sizeof T), typed by the first cast as one T) is the realloc of a one-element array: it was the false UB "realloc: not a live heap block". New model localeconv(): the C locale's struct lconv (decimal_point ".", the other strings "", the char members CHAR_MAX), read-only. WF_runModel extended. | diff_266d1ed_90b9c2f.patch |
| c4ef58d4ee9934f6b05a9e2915a6b7bd2b5e6590 | cir.signbit parsed with its operand as the pseudo-class `signbit` of is_fp_class, evaluated as the sign bit (NaNs and zeros included, as C's signbit); before, the op was unknown (undefined). | diff_90b9c2f_c4ef58d.patch |

Tests (native g++ against cirrun on the ClangIR of the same source; `tests/run.sh` is the difftest runner,
`tests/cases.txt` and `tests/floats_cases.txt` the cases):
- `tests/clib.cpp`: t_realloc_one, t_realloc_struct, t_localeconv.
- `tests/floats.cpp`: t_signbit (std::signbit of -0.5 and -0.0; __builtin_isinf_sign of -inf, +inf and a finite value).
- `outputs/difftest_main_c4ef58d.txt`: the whole difftest at c4ef58d, 177 MATCH and the known gap
  t_gap_emplace (UB at every pin).
- `outputs/difftest_floats_c4ef58d.txt`: the float difftest at c4ef58d, 1118/1118 MATCH.
- `outputs/before_after.txt` (from `before_after.sh`, cirrun on `outputs/*.libcxx.cir`): the new cases at
  the pins before and after each fix. ffab71e: UB / UB / no model for the clib cases, and 90b9c2f: UB for
  t_signbit. Fixed: equal to native (12, 39, 50; 63, 62, 63).
