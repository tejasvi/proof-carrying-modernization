#!/bin/bash
# The new difftest cases on the pins before and after each fix (cirrun on the
# CIR the difftest compiled: outputs/clib.libcxx.cir, outputs/floats.libcxx.cir).
D=$(cd "$(dirname "$0")" && pwd)
FFAB=<ROOT>/cirlean/.lake/build/bin/cirrun               # ffab71e (realloc, localeconv as at 266d1ed)
P90=<ROOT>/cirlean_frozen/90b9c2f_20261025/.lake/build/bin/cirrun
P4E=<ROOT>/cirlean_frozen/c4ef58d_20261025/.lake/build/bin/cirrun
for c in "t_realloc_one 5" "t_realloc_struct 3" "t_localeconv 2"; do
  echo "clib $c | ffab71e: $($FFAB $D/outputs/clib.libcxx.cir $c 2>&1 | tail -1) | 90b9c2f: $($P90 $D/outputs/clib.libcxx.cir $c 2>&1 | tail -1) | c4ef58d: $($P4E $D/outputs/clib.libcxx.cir $c 2>&1 | tail -1)"
done
for c in "t_signbit 0 0" "t_signbit 3 1" "t_signbit -2 5"; do
  echo "floats $c | 90b9c2f: $($P90 $D/outputs/floats.libcxx.cir $c 2>&1 | tail -1) | c4ef58d: $($P4E $D/outputs/floats.libcxx.cir $c 2>&1 | tail -1)"
done
