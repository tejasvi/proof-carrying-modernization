#!/bin/bash
# Differential test: native execution (g++, libstdc++) against the Lean
# semantics (`cirrun` on the ClangIR of the same source).
#   LIB=libcxx (default) compiles the CIR side with libc++ headers,
#   LIB=libstdcxx with the system libstdc++ headers.
#   FILTER=regex limits the cases (matched against "file func").
#   CASES=file replaces cases.txt (e.g. floats_cases.txt).
# Output: one line per case: file func args | native | cirrun | MATCH/MISMATCH/UB
set -u
D=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$D/../.." && pwd)
LIB=${LIB:-libcxx}
FILTER=${FILTER:-.}
CASES=${CASES:-$D/cases.txt}
W=<ROOT>/cirlean_work/std_scratch/difftest
TC=<ROOT>/cirlean_work/toolchain/upstream-4955d32b/bin
CX=<ROOT>/cirlean_work/dl_cir2c_eb2a332/cir2c-eb2a332/libcxx/include/c++/v1
RUN="nice -n 10 taskset -c ${DIFF_CORE:-19}"
CIRRUN=$ROOT/.lake/build/bin/cirrun
mkdir -p "$W"
if [ "$LIB" = libcxx ]; then CIRFLAGS="-nostdinc++ -isystem $CX"; else CIRFLAGS=""; fi

files=$(grep -v '^#' "$CASES" | grep -E "$FILTER" | awk '{print $1}' | sort -u)
for f in $files; do
  drv="$W/${f}_driver.cpp"
  {
    echo '#include <cstdio>'
    echo '#include <cstdlib>'
    echo '#include <cstring>'
    grep -v '^#' "$CASES" | awk -v f="$f" '$1==f {print $2, NF-2}' | sort -u | while read -r fn ar; do
      ps=""; for ((i=0; i<ar; i++)); do ps="$ps${ps:+, }int"; done
      echo "int $fn($ps);"
    done
    echo 'int main(int argc, char **argv) {'
    echo '  int a[8] = {0}; for (int i = 2; i < argc && i < 10; ++i) a[i - 2] = atoi(argv[i]);'
    echo '  try {'
    grep -v '^#' "$CASES" | awk -v f="$f" '$1==f {print $2, NF-2}' | sort -u | while read -r fn ar; do
      as=""; for ((i=0; i<ar; i++)); do as="$as${as:+, }a[$i]"; done
      echo "    if (!strcmp(argv[1], \"$fn\")) { printf(\"%d\\n\", $fn($as)); return 0; }"
    done
    echo '  } catch (...) { printf("exception\n"); return 0; }'
    echo '  return 2;'
    echo '}'
  } > "$drv"
  $RUN g++ -std=c++20 -O0 -o "$W/${f}_native" "$D/$f.cpp" "$drv" 2> "$W/${f}_native.err" ||
    echo "NATIVE BUILD FAILED: $f (see $W/${f}_native.err)"
  timeout 300 $RUN "$TC/clang++" -std=c++20 $CIRFLAGS -fclangir -emit-cir \
    -Xclang -fno-clangir-call-conv-lowering "$D/$f.cpp" -o "$W/$f.$LIB.cir" 2> "$W/$f.$LIB.err" ||
    echo "CIR BUILD FAILED: $f (see $W/$f.$LIB.err)"
done

nm=0; nmm=0; nub=0
while read -r f fn args; do
  case "$f" in \#*|"") continue;; esac
  echo "$f $fn" | grep -qE "$FILTER" || continue
  nat=$(timeout 20 "$W/${f}_native" "$fn" $args 2>&1 | head -1)
  cir=$(timeout 600 $RUN "$CIRRUN" "$W/$f.$LIB.cir" "$fn" $args 2>&1 | head -1)
  cmp="$cir"; case "$cir" in exception*) cmp=exception;; esac
  if [ "$nat" = "$cmp" ]; then st=MATCH; nm=$((nm+1))
  else case "$cir" in UB*|"") st=UB; nub=$((nub+1));; *) st=MISMATCH; nmm=$((nmm+1));; esac
  fi
  printf '%-10s %-22s %-14s | %-12s | %-60s | %s\n' "$f" "$fn" "$args" "$nat" "${cir:0:60}" "$st"
done < "$CASES"
echo "LIB=$LIB  MATCH=$nm  MISMATCH=$nmm  UB/other=$nub"
