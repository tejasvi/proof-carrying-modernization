# ilp32 worktree: HEAD, parent and diff check

Written (date -u): Wed Oct 28 00:39:35 UTC 2026
Started (date -u, file 00_start.txt): Wed Oct 28 00:35:39 UTC 2026

Independent read-only check of the git record behind a frozen worktree.

## Question
- Full id of HEAD in the repository behind <ROOT>/cirlean_frozen/ilp32_e00113f_20261026
  (a frozen worktree whose .git is a pointer file), and its parent commit(s).
- Files changed against the parent, with added and deleted lines (diff --stat).
- Whether <ROOT>/cirlean_work/deliver/ilp32_frozen_manifest_e00113f/COMMIT names
  the same commit as the worktree HEAD.
- Whether the parent is the commit whose id starts with c4ef58d.

## Facts (every value below is copied by program from the evidence files)
    Facts computed by program from the evidence files in this directory and from the inputs named below; no value typed by hand.
    object format (file 11): sha1
    HEAD (rev-parse HEAD, file 10): e00113f7d3c740e3b61ca901497a765939a8a627
    symbolic name of HEAD (rev-parse --symbolic-full-name, file 11): HEAD; detached: yes
    worktree HEAD file <ROOT>/cirlean/.git/worktrees/ilp32_e00113f_20261026/HEAD: e00113f7d3c740e3b61ca901497a765939a8a627; equals rev-parse HEAD: yes
    parent count (rev-parse HEAD^@, file 13): 1
    parents (rev-parse HEAD^@): c4ef58d4ee9934f6b05a9e2915a6b7bd2b5e6590
    parents (log %P, file 14): c4ef58d4ee9934f6b05a9e2915a6b7bd2b5e6590; equal to rev-parse: yes
    parents (cat-file commit parent lines, file 15): c4ef58d4ee9934f6b05a9e2915a6b7bd2b5e6590; equal to rev-parse: yes
    diff --stat parent1..HEAD summary (file 21): 5 files changed, 35 insertions(+), 7 deletions(-)
    numstat totals (log -1 --numstat HEAD, file 30): 5 files, +35 -7
    COMMIT file <ROOT>/cirlean_work/deliver/ilp32_frozen_manifest_e00113f/COMMIT, hex id tokens: e00113f7d3c740e3b61ca901497a765939a8a627
    COMMIT token equals HEAD: yes
    COMMIT bytes identical to HEAD id plus newline (cmp rc 0): yes
    c4ef58d (prefix named in the question) resolves to (rev-parse --verify, file 40): c4ef58d4ee9934f6b05a9e2915a6b7bd2b5e6590
    parent(s) start with c4ef58d: yes
    c4ef58d resolution equals parent1: yes

git diff --stat <parent> HEAD (file 21):
    $ GIT_ALLOW_PROTOCOL=file GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0 git --no-optional-locks -c core.fsmonitor=false -C <ROOT>/cirlean_frozen/ilp32_e00113f_20261026 diff --stat --no-ext-diff --no-textconv c4ef58d4ee9934f6b05a9e2915a6b7bd2b5e6590 HEAD
     CIR/Frontend/Emit.lean   |  2 ++
     CIR/Frontend/Link.lean   |  8 +++++++-
     CIR/Frontend/Parser.lean | 20 ++++++++++++++++++--
     CIR/Module.lean          |  3 +++
     CIR/Semantics/Basic.lean |  9 +++++----
     5 files changed, 35 insertions(+), 7 deletions(-)
    [rc=0]

Added and deleted lines per file (git log -1 --numstat HEAD, file 30; change types in file 31):
    $ GIT_ALLOW_PROTOCOL=file GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0 git --no-optional-locks -c core.fsmonitor=false -C <ROOT>/cirlean_frozen/ilp32_e00113f_20261026 log -1 --no-show-signature --no-ext-diff --no-textconv --format=%H --numstat HEAD
    e00113f7d3c740e3b61ca901497a765939a8a627
    
    2	0	CIR/Frontend/Emit.lean
    7	1	CIR/Frontend/Link.lean
    18	2	CIR/Frontend/Parser.lean
    3	0	CIR/Module.lean
    5	4	CIR/Semantics/Basic.lean
    [rc=0]

## Step 1: repository config, read before any git command
The worktree's .git pointer (file 01) leads to its worktree git dir, whose commondir file leads
to the common git dir (file 02). The common config (file 03) holds a [core] section only: no
remote, promisor or partialclone setting, and no other entry from the scan in file 04 (include,
url, insteadOf, textconv, fsmonitor, trace2 and others). There is no config.worktree, no
objects/info/alternates and no promisor pack file, and the user and system git configs have no
remote, promisor, partialclone, insteadOf or trace2 line (file 04). git was therefore run.
    $ cat <ROOT>/cirlean/.git/config
    [core]
    	repositoryformatversion = 0
    	filemode = true
    	bare = false
    	logallrefupdates = true
    credential-pattern lines in <ROOT>/cirlean/.git/config: 0
    $ command grep -n -i -E "remote|promisor|partialclone" <ROOT>/cirlean/.git/config
    grep rc=1 (0 = a remote/promisor/partialclone line exists, 1 = none, 2 = error)
    $ command grep -n -i -E "include|worktreeconfig|textconv|external|showsignature|fsmonitor|hookspath|insteadof|url|trace2" <ROOT>/cirlean/.git/config
    grep rc=1
    no config.worktree in <ROOT>/cirlean/.git/worktrees/ilp32_e00113f_20261026
    <ROOT>/.gitconfig: present; lines matching remote|promisor|partialclone|insteadof|trace2 (not printed): 0
    <ROOT>/.config/git/config: absent
    /etc/gitconfig: present; lines matching remote|promisor|partialclone|insteadof|trace2 (not printed): 0
    exported GIT_* variable names: [GIT_EDITOR ]
    no objects/info/alternates
    promisor pack files in objects/pack: 0

## Step 2: commands
Every git command ran with the environment and options
    GIT_ALLOW_PROTOCOL=file GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0 git --no-optional-locks -c core.fsmonitor=false -C <ROOT>/cirlean_frozen/ilp32_e00113f_20261026
Only read commands ran (rev-parse, log, cat-file, diff --stat); nothing was fetched, checked out,
stashed, committed or written in any repository, and all output went to this directory only.
diff and log also had --no-ext-diff and --no-textconv, and log had --no-show-signature. The
cat-file record keeps only the tree and parent header lines; author and committer identity lines
were not copied. The manifest directory's own SHA256SUMS was checked with sha256sum -c (file 45).
Each evidence file starts with its exact command line ("$ ...") and ends with its return code
("[rc=N]"). All commands, with the git prefix above shortened to "git":
    01_dotgit_pointer.txt: $ ls -la <ROOT>/cirlean_frozen/ilp32_e00113f_20261026/.git
    01_dotgit_pointer.txt: $ cat <ROOT>/cirlean_frozen/ilp32_e00113f_20261026/.git
    02_resolved_paths.txt: $ ls -la <ROOT>/cirlean/.git/worktrees/ilp32_e00113f_20261026
    02_resolved_paths.txt: $ cat <ROOT>/cirlean/.git/worktrees/ilp32_e00113f_20261026/HEAD
    02_resolved_paths.txt: $ cat <ROOT>/cirlean/.git/worktrees/ilp32_e00113f_20261026/gitdir
    03_common_config.txt: $ cat <ROOT>/cirlean/.git/config
    04_config_scan.txt: $ command grep -n -i -E "remote|promisor|partialclone" <ROOT>/cirlean/.git/config
    04_config_scan.txt: $ command grep -n -i -E "include|worktreeconfig|textconv|external|showsignature|fsmonitor|hookspath|insteadof|url|trace2" <ROOT>/cirlean/.git/config
    05_manifest_dir_listing.txt: $ ls -la <ROOT>/cirlean_work/deliver/ilp32_frozen_manifest_e00113f
    06_manifest_COMMIT.txt: $ wc -c < <ROOT>/cirlean_work/deliver/ilp32_frozen_manifest_e00113f/COMMIT
    06_manifest_COMMIT.txt: $ head -c 4096 <ROOT>/cirlean_work/deliver/ilp32_frozen_manifest_e00113f/COMMIT
    10_rev-parse_HEAD.txt: $ git rev-parse HEAD
    11_rev-parse_context.txt: $ git rev-parse --show-object-format --git-dir --git-common-dir --show-toplevel --symbolic-full-name HEAD
    12_cat-file_type_HEAD.txt: $ git cat-file -t HEAD
    13_rev-parse_parents.txt: $ git rev-parse HEAD^@
    14_log_HEAD.txt: $ git log -1 --no-show-signature --format=commit %H%nparents %P%ntree %T%nauthor-date %aI%ncommitter-date %cI%nsubject %s HEAD
    15_cat-file_commit_HEAD_header.txt: $ git cat-file commit HEAD   [only the tree/parent header lines are kept; author/committer lines not copied]
    21_diff_stat_parent1_HEAD.txt: $ git diff --stat --no-ext-diff --no-textconv c4ef58d4ee9934f6b05a9e2915a6b7bd2b5e6590 HEAD
    30_log_numstat_HEAD.txt: $ git log -1 --no-show-signature --no-ext-diff --no-textconv --format=%H --numstat HEAD
    31_log_name-status_HEAD.txt: $ git log -1 --no-show-signature --no-ext-diff --format=%H --name-status HEAD
    40_rev-parse_verify_c4ef58d.txt: $ git rev-parse --verify --quiet c4ef58d^{commit}
    41_rev-parse_disambiguate_c4ef58d.txt: $ git rev-parse --disambiguate=c4ef58d
    45_manifest_SHA256SUMS_check.txt: $ cd <ROOT>/cirlean_work/deliver/ilp32_frozen_manifest_e00113f && sha256sum -c SHA256SUMS

## Integrity
SHA256SUMS in this directory covers every other file here. Check with: sha256sum -c SHA256SUMS
(run inside this directory).
