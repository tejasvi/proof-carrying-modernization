RESULT: R1 at cirlean next e6ac99a agrees with the delivery: package 492/492 and all 285 listed module hashes verify (the 44 CIR modules equal the frozen pin's manifest); the entry statement and its printed definitions are byte-identical to the c4ef58d check's; all 32 unit theorems and FHEntry.entry_main use exactly propext, Classical.choice, Quot.sound; kernel replay 285/285 modules rc 0 and leanchecker --fresh on the entry module rc 0; 8 unit statements are restated (block and buffer types fixed, two premises added), 24 unchanged, and the entry carries no new hypothesis.

# R1 (whole cJSON harness, size < 2^61) at cirlean next e6ac99a: evidence check

Checked by a fork of the evidence owner, 2026-10-27 09:09Z-09:50Z (date -u). Object: veriforch's sealed package
<ROOT>/veriforch/runs/postfreeze/r1_cjson_e6ac99a/ on the frozen pin <ROOT>/cirlean_frozen/next_e6ac99a_20261027 (e6ac99a, checked in
checks/cirnext-20261027T0143Z). Earlier check of the same theorem at c4ef58d: checks/fh-r1-20261026T2003Z.

## Copies and hashes
- Package SHA256SUMS (b8eeb5c6...): 492/492 OK before and after (pkg_sumcheck_before.txt, pkg_sumcheck_after.txt); 0 symlinks.
  Announced files equal: REPORT.md 53897db8, RESOLUTION.tsv 0ae4a44c, SPEC_RESTATEMENTS.md 928bc916, axioms_all_32_units.txt
  77dd2288, entry_diff_c4ef58d_vs_e6ac99a.txt 06a3f4c8, leanchecker_closure.log 9024264a.
- Copy: replay/r1next-20261027T0909Z/pkg (cp -rL; 0 symlinks; diff -rq against the package empty, copy_identity_diff.txt;
  492/492 OK in the copy before and after).
- RESOLUTION.tsv: 285 modules, every listed .olean hash OK (resolution_check.txt): 44 CIR.* from the frozen pin, 241 in lib/.
  The frozen pin's MANIFEST_build.sha256 (825e6dc0, from checks/cirnext-20261027T0143Z/records) verifies 126/126 before and
  after, and the 44 CIR oleans of the closure equal it (cir44_vs_manifest.txt). The 44 are the c4ef58d closure's 43 CIR
  modules plus the import-only root CIR (same names).
- Cirlean's bundles <ROOT>/cirlean_work/deliver/fh_bundles_e6ac99a_final: SHA256SUMS (42df4a1e...) 15/15 OK.

## Entry statement (statement/check_statement.lean, fresh process, rc 0)
- LEAN_PATH = the copy's lib + the frozen pin + the toolchain. #check @VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec
  and #print of VerifOrch.Cir.InitExt, VerifOrch.Cir.ReadableBuf, CIR.Returns, CIR.Calls, CIR.Res.holds and the Unit's ctx:
  36 lines, byte-identical to the c4ef58d check's output (statement/defs_diff.txt empty). In words, as before: for every
  well-formed memory that keeps the globals at their initial values and every live uint8 array block of size bytes after
  the globals (0 <= size <= 2^64-1, ReadableBuf's n < 2^63, bytes 0..255) with size < 2^61, the call of the harness returns
  normally in the semantics; nothing is said about the result. sym = "LLVMFuzzerTestOneInput" by rfl.
- The statement text is the same, but the semantics under it is cirlean e6ac99a, which treats type-punned scalar accesses
  as undefined (except record members, as checked in cirnext); the theorem now excludes those as well.

## Axioms
- Same fresh process: the 32 unit theorems (the closure's 32 units, the same set as at c4ef58d after the renaming
  cJSON$x -> cJSON_x; units_c4ef58d_mapped.txt = units_e6ac99a_axfile.txt) and FHEntry.entry_main: 33/33 print exactly
  [propext, Classical.choice, Quot.sound] (statement/axioms_joined.txt); no error in the output.

## Kernel replay
- tools/leancheck1lp.sh per module, pjobs_v3 N = 2, every job guarded: 285/285 modules of RESOLUTION.tsv rc 0 (replay/;
  module wall times sum 621 s; largest VO...cJSON_parse_hex4 8.8 s).
- leanchecker --fresh VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput (the module's whole environment in one fresh
  process, so the full import closure whatever its list): rc 0, 360 s (fresh_entry.out).
- Controls (scripts/ctl.sh, control/): BadCtl, a false theorem added with kernel checking off, rc 1 (kernel declaration type
  mismatch); GoodCtl rc 0.
- A closure computed from the package's src/ (closure_from_src.py) is incomplete because src/ holds only part of the
  sources (no GivenPA.* or CycleSpecsP2N source); the fresh replay above covers the closure instead.

## Restatements (units/)
- Sections 1-3 of veriforch's SPEC_RESTATEMENTS.md equal cirlean's SPEC_RESTATEMENTS.md (diff: a separator only).
- My own comparison of the Lean-printed statements of all 32 unit theorems at c4ef58d (the earlier check's copy) and at
  e6ac99a (my copy): 24 identical, 8 changed (units/changed_units.txt), the same 8 the delivery names:
  - cJSON_Delete_spec: new premise forall N, CJ.forestPrintable N ts (every item block of the freed forest is a struct cJSON);
  - cJSON_cJSON_New_Item_spec: new premise hpun, that loading the allocate hook (a function pointer at the hooks' index 0)
    is not a type-punned access;
  - cJSON_buffer_skip_whitespace_spec, cJSON_parse_string_spec, cJSON_parse_hex4_spec: the input buffer's block type is
    fixed to a uint8 array of xs.length elements (a free type before);
  - cJSON_utf16_literal_to_utf8_spec: input and output buffers fixed to uint8 arrays, the pointer slot to a uint8 pointer;
  - cJSON_print_number_spec, cJSON_print_string_spec: the item block's type is fixed to .record "cJSON" (a free type before).
- CJ.printable (CJPrint -> CJPrintN): its equation lemma eq_1 gains the conjunct rt = .record "cJSON" for items
  (units/cjp_*.out); the 12 units that mention CJ.printable or CJ.forestPrintable keep their statement text and inherit it.
- Discharge: the entry statement is unchanged and the entry theorem, built on the restated units, passes the kernel replay
  with the standard axioms only, so every added premise is discharged inside the composition; for example POSpecS2's
  po_new_spec_n adapts the New_Item contract with hpun for the parse steps, and the harness proof supplies the forest's
  printability to cJSON_Delete.

## Discrepancies and notes
- REPORT.md / SPEC_RESTATEMENTS.md say "13 units" unchanged and "11 units" inheriting, but list 12 and 12 (32 in all; the
  8 restated units agree with my comparison).
- Compute as reported: veriforch's guard.log (runs/postfreeze/r1_next_prep/guard.log) sums 66 runs, 6.663 core-h (equal);
  cirlean's ~14.9 core-h not checked (no log named); model spend $0 as reported, not checkable here.

## Disclosures
- Reads outside my two directories: the package, the frozen pin, cirlean's bundle dir, veriforch's guard.log and the earlier
  check's copy (replay/fh-r1-20261026T2003Z, read-only). No producer tree written; git not used.
- Compute: 293 guarded jobs, 0.214 core-h in all (guard/).
