#!/usr/bin/env python3
"""Import closure of a root module, read from Lean sources: the package's src/ first, then the frozen cirlean pin.
Modules found in neither (Init, Lean, Std) are not followed. Prints one module per line (sorted) and a tally on stderr.
usage: closure_from_src.py PKG_SRC PIN_ROOT ROOT_MODULE
"""
import os, re, sys

IMP = re.compile(r"^\s*(?:(?:public|private)\s+)?(?:meta\s+)?import\s+(.+)$")


def path_of(root, mod):
    p = os.path.join(root, *mod.split(".")) + ".lean"
    return p if os.path.isfile(p) else None


def main():
    src, pin, root_mod = sys.argv[1:4]
    seen, todo, unresolved = set(), [root_mod], set()
    while todo:
        m = todo.pop()
        if m in seen:
            continue
        p = path_of(src, m) or path_of(pin, m)
        if p is None:
            unresolved.add(m)
            continue
        seen.add(m)
        for line in open(p, encoding="utf-8", errors="replace"):
            mt = IMP.match(line)
            if mt:
                for tok in mt.group(1).split():
                    if tok.startswith("--"):
                        break
                    todo.append(tok)
    for m in sorted(seen):
        print(m)
    top = sorted({u.split(".")[0] for u in unresolved})
    print(f"closure {len(seen)}; not followed (no source): {len(unresolved)} modules, top-level {top}", file=sys.stderr)


if __name__ == "__main__":
    main()
