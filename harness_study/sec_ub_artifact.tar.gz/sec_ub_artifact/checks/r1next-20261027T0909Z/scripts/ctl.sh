#!/bin/bash
# check-fork: build the two control modules into my control lib and replay them with my replay LEAN_PATH.
set -u
R=<ROOT>/fv_paper/replay/r1next-20261027T0909Z
C=<ROOT>/fv_paper/evidence/checks/r1next-20261027T0909Z
B=<ROOT>/.elan/toolchains/leanprover--lean4---v4.35.0/bin
LP=$R/ctl/lib:$R/pkg/lib:<ROOT>/cirlean_frozen/next_e6ac99a_20261027/.lake/build/lib/lean
for m in BadCtl GoodCtl; do
  LEAN_NUM_THREADS=1 LEAN_PATH=$LP $B/lean -R $R/ctl/src -o $R/ctl/lib/$m.olean $R/ctl/src/$m.lean > $C/control/$m.compile.out 2>&1
  echo "$m compile rc=$?"
  bash <ROOT>/fv_paper/evidence/tools/leancheck1lp.sh $LP $m $C/control 300
  cut -c1-250 $C/control/$m.tsv
done
