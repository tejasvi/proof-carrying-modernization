import VerifOrch.Cir.CJPrint
set_option format.width 100000
#check @CIR.CJ.printable.eq_1
