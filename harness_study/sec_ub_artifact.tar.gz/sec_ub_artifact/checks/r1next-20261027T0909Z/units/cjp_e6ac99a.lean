import VerifOrch.Cir.CJPrintN
set_option format.width 100000
#check @CIR.CJ.printable.eq_1
