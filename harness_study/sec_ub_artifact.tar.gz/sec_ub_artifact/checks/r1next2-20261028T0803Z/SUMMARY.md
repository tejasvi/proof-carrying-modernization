RESULT: R1 at cirlean next2 424e821 agrees with the delivery: package 493/493 and all 288 listed module hashes verify (45 CIR.* in the frozen pin next2_424e821_20261027 and 243 in lib/); the entry statement and its printed definitions are byte-identical to the c4ef58d and e6ac99a checks'; all 32 unit theorems and FHEntry.entry_main use exactly [propext, Classical.choice, Quot.sound]; kernel replay 288/288 modules rc 0 and leanchecker --fresh on the entry module rc 0 (controls: BadCtl rc 1, GoodCtl rc 0); 31/32 unit statements are byte-identical to e6ac99a's, 1 unit statement (cJSON_cJSON_New_Item_spec) adds the hpunm record-member punning premise, and the entry statement carries no new hypothesis.

# R1 (whole cJSON harness, size < 2^61) at cirlean next2 424e821: evidence check

Checked by fork check-fork, 2026-10-28 08:03Z-08:37Z (date -u). Object: veriforch's sealed package
<ROOT>/veriforch/runs/postfreeze/r1_cjson_next2_424e821/ on the frozen pin <ROOT>/cirlean_frozen/next2_424e821_20261027 (commit
424e8218afa953b7c226560b3d02a29ac025b76d). Earlier checks of the same theorem: checks/fh-r1-20261026T2003Z (c4ef58d) and
checks/r1next-20261027T0909Z (e6ac99a).

## Copies and hashes
- Package SHA256SUMS (4747bb88...): 493/493 OK in the original and in the hard-linked copy replay/r1next2-20261028T0803Z/pkg
  before and after the check (pkg_sumcheck_orig.txt, pkg_sumcheck_before.txt, pkg_sumcheck_after.txt); 0 symlinks; diff -rq
  empty (copy_identity_diff.txt).
- Announced hashes equal (announced_hashes.txt): REPORT.md b79c547b, RESOLUTION.tsv b8eb0c16, SPEC_RESTATEMENTS.md e21d8295,
  entry_diff_c4ef58d_vs_424e821.txt 06a3f4c8, axioms_all_32_units.txt 77dd2288, leanchecker_closure.log 3bc3ef1e,
  LLVMFuzzerTestOneInput.olean 9a145dd5, CheckAll32Axioms.olean ff3c79d9.
- RESOLUTION.tsv: 288 modules, every listed .olean hash OK on disk (resolution_check.txt): 45 CIR.* in the frozen pin
  <ROOT>/cirlean_frozen/next2_424e821_20261027 and 243 in lib/. Against the 285-module e6ac99a closure (closure_diff_vs_e6ac99a.txt),
  CIR adds CIR.Semantics.Program (44 -> 45), and lib/ replaces POSFinal2 with POSFinal4 and adds PORecPun and POSpecS4
  (241 -> 243).
- Cirlean's next2 bundle deliveries (<ROOT>/cirlean_work/deliver/*_next2*, 13 directories): all SHA256SUMS verify, and the .olean
  hashes in RESOLUTION.tsv for CycleSpecsP2N (f6adebad), PORecPun (b16960b7), POSFinal4 (e21d528f), POSpecS4 (d4d13353), and
  ParseArrayStepStrong (1031abca) match cirlean's *_next2_v4 deliveries (cirlean_bundles_check.txt).

## Entry statement and axioms (statement/check_statement.out, fresh process, rc 0)
- LEAN_PATH = the copy's lib + the frozen pin + the toolchain. The full output of check_statement.lean (#check of
  @VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec, #print of VerifOrch.Cir.InitExt, VerifOrch.Cir.ReadableBuf,
  CIR.Returns, CIR.Calls, CIR.Res.holds, Unit.ctx, sym rfl, and #print axioms of all 32 unit theorems + FHEntry.entry_main)
  is byte-identical to the e6ac99a check's output (5,857 bytes; defs_diff.txt empty).
- All 33 theorems (the 32 unit theorems and FHEntry.entry_main) print [propext, Classical.choice, Quot.sound]
  (statement/axioms_joined.txt).

## Unit statement comparison e6ac99a -> 424e821 (units/)
- Printed all 32 unit theorem statements and CIR.CJ.printable in a fresh process (units/print_units_424e821.out) and diffed
  against the e6ac99a check's joined statements (units/diff/joined_e6ac99a_vs_424e821.diff):
  - 31 of the 32 unit theorem statements (including LLVMFuzzerTestOneInput_spec) and CIR.CJ.printable are byte-identical
    between e6ac99a and 424e821;
  - 1 of the 32 unit theorem statements (cJSON_cJSON_New_Item_spec) adds one premise after hpun:
    ctx.punnedMember m (CIR.Ty.func [CIR.Ty.int false 64] CIR.Ty.void.ptr false).ptr (match hp, hh, hpun with | CIR.Ptr.loc b p, hh, hpun => CIR.Ptr.loc b (p ++ [CIR.PathElem.idx 0]) | p, hh, hpun => p) = false,
    discharged inside the composition so the entry statement is unchanged.

## Kernel replay and controls (replay/, control/)
- Per-module replay (evidence/tools/leancheck1lp.sh via pjobs_v3.py N = 2, every job guarded, ulimit -v 32 GiB): 288/288
  modules of RESOLUTION.tsv rc 0 (replay/; module wall times sum 609.6 s; largest Gen.v0_fuzzing_cjson_read_fuzzer.Unit 69.3 s).
- Full-closure fresh replay: leanchecker --fresh VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput rc 0, 375.1 s
  (fresh_entry.out). Two earlier invocations are kept: attempt 1 omitted the toolchain bin from PATH so leanchecker's child
  lean exited 1 (fresh_entry.attempt1_no_path.out); attempt 2 chained two --fresh calls under a single 0.15 core-h guard and
  hit the cap on the second (fresh_entry.attempt2_two_calls_capped.out).
- Controls (scripts/ctl.sh, control/): BadCtl rc 1 (kernel declaration type mismatch); GoodCtl rc 0.

## Compute
- Guarded compute total: 0.552 core-h across 291 guarded runs (guard_totals.txt, guard/).
