#!/bin/bash
set -u
LP_CTL="<ROOT>/fv_paper/replay/r1next2-20261028T0803Z/tmp_ctl/lib:<ROOT>/fv_paper/replay/r1next2-20261028T0803Z/pkg/lib:<ROOT>/cirlean_frozen/next2_424e821_20261027/.lake/build/lib/lean:<ROOT>/.elan/toolchains/leanprover--lean4---v4.35.0/bin/../lib/lean"
for m in BadCtl GoodCtl; do
  LEAN_NUM_THREADS=1 LEAN_PATH="$LP_CTL" "<ROOT>/.elan/toolchains/leanprover--lean4---v4.35.0/bin/lean" -DElab.async=false -R "<ROOT>/fv_paper/replay/r1next2-20261028T0803Z/tmp_ctl/src" -o "<ROOT>/fv_paper/replay/r1next2-20261028T0803Z/tmp_ctl/lib/$m.olean" "<ROOT>/fv_paper/replay/r1next2-20261028T0803Z/tmp_ctl/src/$m.lean" > "<ROOT>/fv_paper/evidence/checks/r1next2-20261028T0803Z/control/$m.compile.out" 2>&1
  echo "$m compile rc=$?"
  bash <ROOT>/fv_paper/evidence/tools/leancheck1lp.sh "$LP_CTL" "$m" "<ROOT>/fv_paper/evidence/checks/r1next2-20261028T0803Z/control" 300
  cat "<ROOT>/fv_paper/evidence/checks/r1next2-20261028T0803Z/control/$m.tsv"
done
