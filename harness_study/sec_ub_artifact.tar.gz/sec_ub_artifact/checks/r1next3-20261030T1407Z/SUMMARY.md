RESULT: R1 at cirlean next3 7c73739 (against CycleSpecsP2N v5) agrees with the delivery: package 499/499 and all 300 listed module hashes verify (54 CIR.* in the frozen pin next3_7c73739_20261030 and 246 in lib/); the entry statement and its printed definitions are byte-identical to the c4ef58d, e6ac99a, and 424e821 checks'; all 32 unit theorems and FHEntry.entry_main use exactly [propext, Classical.choice, Quot.sound]; kernel replay 300/300 modules rc 0 and leanchecker --fresh on the entry module rc 0 (controls: BadCtl rc 1, GoodCtl rc 0); 30/32 unit statements are byte-identical to 424e821's, 2 unit statements change (cJSON_cJSON_New_Item_spec adds the hrel memberRelated premise; cJSON_skip_utf8_bom_spec types the input buffer block as a uint8 array of xs.length elements), and the entry statement carries no new hypothesis.

# R1 (whole cJSON harness, size < 2^61) at cirlean next3 7c73739: evidence check

Checked by fork check-fork, 2026-10-30 14:07Z-14:21Z (date -u). Object: veriforch's sealed package
<ROOT>/veriforch/runs/postfreeze/r1_cjson_next3_7c73739/ on the frozen pin <ROOT>/cirlean_frozen/next3_7c73739_20261030 (commit
7c73739c0cb655d07f4a452cc3317cafb2b1bcb4). Earlier checks of the same theorem: checks/fh-r1-20261026T2003Z (c4ef58d),
checks/r1next-20261027T0909Z (e6ac99a), and checks/r1next2-20261028T0803Z (424e821).

## Copies and hashes
- Package SHA256SUMS (13ef1e65...): 499/499 OK in the original and in the hard-linked copy replay/r1next3-20261030T1407Z/pkg
  before and after the check (pkg_sumcheck_orig.txt, pkg_sumcheck_before.txt, pkg_sumcheck_after.txt); 0 symlinks; diff -rq
  empty (copy_identity_diff.txt).
- Announced hashes equal (announced_hashes.txt): REPORT.md 7d1e56ac, RESOLUTION.tsv 49ab242b, SPEC_RESTATEMENTS.md d2c64a30,
  entry_diff_c4ef58d_vs_7c73739.txt 06a3f4c8, axioms_all_32_units.txt 77dd2288, leanchecker_closure.log 062eb2bd,
  LLVMFuzzerTestOneInput.olean 71e6384d, CheckAll32Axioms.olean ff3c79d9.
- RESOLUTION.tsv: 300 modules, every listed .olean hash OK on disk (resolution_check.txt): 54 CIR.* in the frozen pin
  <ROOT>/cirlean_frozen/next3_7c73739_20261030 (whose MANIFEST_build.sha256 8d2cc1ff verifies 1017/1017 in
  frozen_pin_manifest_check.txt) and 246 in lib/. Against the 288-module 424e821 closure (closure_diff_vs_424e821.txt),
  CIR adds 9 modules (CIR.Frontend.{ByValue,RetSlot,Retval,Varargs} and CIR.Std.{Complex,Hash,Libm,LibmCR,X86}, 45 -> 54),
  and lib/ adds 3 modules (PN18Base, PN18Case0, PN18Case1, 243 -> 246).
- All 12 rebuilt CycleSpecsP2N v5 bundle .olean hashes in RESOLUTION.tsv match checks/fhnext3v5-20261030T1146Z/v5_oleans.sha256
  byte-for-byte (v5_bundles_check.txt).

## Entry statement and axioms (statement/check_statement.out, fresh process, rc 0)
- LEAN_PATH = the copy's lib + the frozen pin + the toolchain. The full output of check_statement.lean (#check of
  @VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec, #print of VerifOrch.Cir.InitExt, VerifOrch.Cir.ReadableBuf,
  CIR.Returns, CIR.Calls, CIR.Res.holds, Unit.ctx, sym rfl, and #print axioms of all 32 unit theorems + FHEntry.entry_main)
  is byte-identical to the 424e821 check's output (defs_diff_vs_424e821.txt).
- All 33 theorems (the 32 unit theorems and FHEntry.entry_main) print [propext, Classical.choice, Quot.sound].

## Unit statement comparison 424e821 -> 7c73739 (units/)
- Printed all 32 unit theorem statements and CIR.CJ.printable in a fresh process (units/print_units_7c73739.out) and diffed
  against the 424e821 check's output (units/diff/units_424e821_vs_7c73739.diff):
  - 30 of the 32 unit theorem statements (including LLVMFuzzerTestOneInput_spec) and CIR.CJ.printable are byte-identical
    between 424e821 and 7c73739;
  - 2 of the 32 unit theorem statements change (both documented in SPEC_RESTATEMENTS.md, whereas REPORT.md §3 mentions only
    cJSON_cJSON_New_Item_spec):
    1. cJSON_cJSON_New_Item_spec adds one premise after hpunm:
       (match hp, hh, hpun, hpunm with | CIR.Ptr.loc b p, hh, hpun, hpunm => Gen.v0_fuzzing_cjson_read_fuzzer.Unit.ctx.memberRelated m b p (CIR.Ty.record "internal_hooks") | x, hh, hpun, hpunm => false) = true;
    2. cJSON_skip_utf8_bom_spec replaces the free block type (tyc : CIR.Ty) of the input buffer block bc with
       (CIR.Ty.int false 8).array xs.length (for strncmp's charStride? check at 7c73739).
    Both are discharged inside the composition so the entry statement carries no new hypothesis.

## Kernel replay and controls (replay/, control/)
- Per-module replay (evidence/tools/leancheck1lp.sh via pjobs_v3.py N = 2, every job guarded, ulimit -v 32 GiB): 300/300
  modules of RESOLUTION.tsv rc 0 (replay/, replay_stats.txt; module wall times sum 618.5 s; largest
  Gen.v0_fuzzing_cjson_read_fuzzer.Unit 59.5 s).
- Full-closure fresh replay: leanchecker --fresh VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput rc 0, 388.3 s
  (fresh_entry.out).
- Controls (scripts/ctl.sh, control/): BadCtl rc 1 (kernel declaration type mismatch); GoodCtl rc 0.

## Compute
- Guarded compute total: 0.226 core-h across 304 guarded runs (guard_totals.txt, guard/).
