#!/bin/bash
set -u
LP_CTL="<ROOT>/fv_paper/replay/r1next3-20261030T1407Z/tmp_ctl/lib:<ROOT>/fv_paper/replay/r1next3-20261030T1407Z/pkg/lib:<ROOT>/cirlean_frozen/next3_7c73739_20261030/.lake/build/lib/lean:<ROOT>/.elan/toolchains/leanprover--lean4---v4.35.0/lib/lean"
for m in BadCtl GoodCtl; do
  LEAN_NUM_THREADS=1 LEAN_PATH="$LP_CTL" "<ROOT>/.elan/toolchains/leanprover--lean4---v4.35.0/bin/lean" -DElab.async=false -R "<ROOT>/fv_paper/replay/r1next3-20261030T1407Z/tmp_ctl/src" -o "<ROOT>/fv_paper/replay/r1next3-20261030T1407Z/tmp_ctl/lib/$m.olean" "<ROOT>/fv_paper/replay/r1next3-20261030T1407Z/tmp_ctl/src/$m.lean" > "<ROOT>/fv_paper/evidence/checks/r1next3-20261030T1407Z/control/$m.compile.out" 2>&1
  echo "$m compile rc=$?"
  bash <ROOT>/fv_paper/evidence/tools/leancheck1lp.sh "$LP_CTL" "$m" "<ROOT>/fv_paper/evidence/checks/r1next3-20261030T1407Z/control" 300
  cat "<ROOT>/fv_paper/evidence/checks/r1next3-20261030T1407Z/control/$m.tsv"
done
