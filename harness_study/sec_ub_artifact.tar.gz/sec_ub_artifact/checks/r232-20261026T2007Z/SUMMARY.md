RESULT: R2-32 agrees with the delivery. VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec on the ILP32 tree uses exactly [propext, Classical.choice, Quot.sound]; the kernel replays all 285 modules of its import closure with rc 0 (283 replayed + 2 import-only); the statement's size bound is ReadableBuf's n < 2^31; the pin's build manifest verifies 113/113. Differences from the delivery's description: (a) besides ctx_ptrBytes (cJSON_print.lean:15) there are two more rfl lemmas of the same form, ctx_ptrBytes_pwo (cJSON_ParseWithOpts.lean:13) and ctx_ptrBytes_pwlo (cJSON_ParseWithLengthOpts.lean:17); (b) PrintObjectStep.lean:1078-1079 renames simp-lemma identifiers to their 32-bit names, and one doc comment (PrintStringPtrSpec.lean:19) differs; (c) CIR.Logic.CJString is compiled in the tree from the pin's source, not taken from the pin's build (my recompile is byte-identical).

# R2-32 check (cJSON 1.7.18 harness tree, ILP32, patched source, size < 2^31): fork check-fork, started 2026-10-26T20:07Z

## Copy
- replay/r232-20261026T2007Z/r2_32 = <ROOT>/fvreview_20261023/r2_32 and replay/r232-20261026T2007Z/cirlean-e00113f =
  <ROOT>/cirlean_frozen/ilp32_e00113f_20261026; diff -rq against both empty (copy_identity/); no symlinks. The pin copy keeps
  the worktree's 79-byte .git pointer file; no git command was run in the copy.

## Hashes (hashes.txt)
- Tree SHA256SUMS 0f0cffe41aeecfc7... (announced), sha256sum -c 703/703 OK; theorem source e6ba8c88..., its .olean
  083b79ee... (announced).
- Pin: <ROOT>/cirlean_work/deliver/ilp32_frozen_manifest_e00113f/SHA256SUMS db99b54b... (announced) covers COMMIT
  (e00113f7d3c740e3b61ca901497a765939a8a627), MANIFEST_build.sha256 and files.list, all OK. MANIFEST_build.sha256 (113 entries,
  paths relative to .lake/build) verifies 113/113 against the frozen pin and against my copy; bin/cir2lean f9888c8b...;
  0 writable files under the frozen pin's .lake/build when checked.
- The tree's out/CIR*: 213 files, 212 byte-identical to the pin's build. out/CIR/Logic/CJString.olean is not part of the
  pin's build (the pin has CIR/Logic/CJString.lean, which CIR.lean does not import). My compile of that source (lean -R
  <pin>, -DautoImplicit=false -DrelaxedAutoImplicit=false, LEAN_PATH = pin build) gives a byte-identical .olean
  (cjstring/, outCIR_vs_pin.txt).

## Axioms (r232_axcheck/axcheck.tsv; axcheck.py --leanpath out:pin:toolchain, fresh process per module)
- 93/93 theorem names of the 32 VO modules that declare theorems: exactly [propext, Classical.choice, Quot.sound],
  including the entry theorem and the three ctx_ptrBytes lemmas. No `axiom` declaration in the tree's sources or in the
  pin's CIR sources. Keyword scan: sorry/native_decide appear only inside doc comments (6 files; keyword_scan.txt).

## Kernel replay (leancheck1lp.sh, LEAN_PATH = out : pin build : toolchain; pjobs_v3 N = 1)
- Import closure of VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput, 285 modules (closure_entry.tsv): CIR 43 + the
  import-only root CIR, Gen 127, VO 34, VerifOrch 4, top-level proof modules 75 + the import-only RoG; all 283 rc 0. With
  every VO module as a root the closure is the same 285 modules (closure_allVO.tsv).

## Statement (statement/check_statement.out, fresh process, rc 0)
- forall data size m, InitExt module m -> 0 <= size /\ size <= 2^32-1 -> ReadableBuf module.initMem.next m data size ->
  Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr data, .int size] m (fun _ _ => True). In this tree ReadableBuf requires
  0 <= n < 2^31 and a live block after the globals holding n unsigned bytes (values 0..255); sym = "LLVMFuzzerTestOneInput"
  by rfl. In words: for every such input buffer of fewer than 2^31 bytes, in every well-formed memory that keeps the
  module's initial blocks, the call of the entry point returns normally; nothing is said about the result.
- ctx_ptrBytes, ctx_ptrBytes_pwo, ctx_ptrBytes_pwlo: each printed as `@[defeq] theorem ... : ctx.mod.ptrBytes = 4 := rfl`;
  an independent `example : Gen.v0_fuzzing_cjson_read_fuzzer.Unit.ctx.mod.ptrBytes = 4 := rfl` is accepted. Their axiom
  lists are the standard three (from the definitions their statements mention); they are theorems, not axioms.

## Proof files against the R2-64 package (width_diff_v2.tsv, width_diff_v2_detail.txt, tools/width_diff_v2.py)
- Method: raw line diff per file pair (R2-64 GivenPA/X <-> tree src/X; VerifOrch, VO, Gen by path); a changed line pair
  counts as width-only when mapping the standalone numbers 64, 63, 2^64-1, 2^64, 2^63-1, 2^63 to their 32-bit counterparts
  and dropping the GivenPA. module prefix turns the old line into the new one.
- Top-level proof modules (76): 10 identical, 64 width-only, 2 other; VerifOrch (5): 2 identical, 3 width-only; VO (34):
  7 identical, 21 width-only, 6 other. Every file pair exists on both sides.
- Remaining lines, by tree file and line: cJSON_print_number_given.lean:512; cJSON_parse_number.lean:176, 298, 310;
  cJSON_parse_string_given.lean:356-358 (added) and 360 (these are the delivery's named adjustments: intMax_u32,
  wrap_u32_self, wrap false 32); the three rfl lemmas above (each with a blank line); PrintObjectStep.lean:1078-1079
  (simp-lemma identifiers with 32-bit names); PrintStringPtrSpec.lean:19 (doc comment).
- Gen (127 files): 76 identical, 37 width-only, 14 other by this line rule. The delivery counts functions (76 identical,
  44 width-only, 4 other of 125); the two counts use different units and the Gen files were not regenerated here, so they
  are not reconciled.

## Not done here
- Regenerating the i686 Gen from cJSON.cir / cjson_read_fuzzer.cir with the pin's cir2lean; re-running the branch's
  i686 difftests.

## Compute and process
- Guarded compute of this check: 0.106 core-h (283 replay jobs 0.100, axiom check 0.006, statement check and the
  CJString compile under 0.001 each).
- Disclosure: the pjobs_v3 scheduler processes ran outside a guard; every job they started ran under coreh_guard_v2.
