import VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput

#check @VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec
#print VerifOrch.Cir.InitExt
#print VerifOrch.Cir.ReadableBuf
#print CIR.Returns
#print Gen.v0_fuzzing_cjson_read_fuzzer.Unit.ctx
example : Gen.v0_fuzzing_cjson_read_fuzzer.Unit.fn_LLVMFuzzerTestOneInput.sym = "LLVMFuzzerTestOneInput" := rfl
#print VO.v0.fuzzing_cjson_read_fuzzer.ctx_ptrBytes
#print VO.v0.fuzzing_cjson_read_fuzzer.ctx_ptrBytes_pwo
#print VO.v0.fuzzing_cjson_read_fuzzer.ctx_ptrBytes_pwlo
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.ctx_ptrBytes
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.ctx_ptrBytes_pwo
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.ctx_ptrBytes_pwlo
example : Gen.v0_fuzzing_cjson_read_fuzzer.Unit.ctx.mod.ptrBytes = 4 := rfl
#print axioms VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput_spec
