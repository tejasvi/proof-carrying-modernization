#!/usr/bin/env python3
"""ax_list (module + namespace-qualified theorem names) for every .lean file under SRC/VO, using the same
theorem regex as evidence/tools/pkg_replay_jobs.py. Usage: mk_axlist.py SRC_ROOT OUT"""
import os, re, sys
src, out = sys.argv[1], sys.argv[2]
def theorems(path):
    txt = open(path, encoding="utf-8", errors="replace").read()
    res, ns = [], []
    for line in txt.splitlines():
        m = re.match(r"^namespace\s+(\S+)", line)
        if m:
            ns.append(m.group(1)); continue
        m = re.match(r"^end\s+(\S+)", line)
        if m and ns and ns[-1] == m.group(1):
            ns.pop(); continue
        m = re.match(r"^(?:@\[[^\]]*\]\s*)?(?:private\s+)?theorem\s+(\S+)", line)
        if m:
            res.append(".".join(ns + [m.group(1)]))
    return res
lines = []
for dp, dn, fn in os.walk(os.path.join(src, "VO")):
    for f in sorted(fn):
        if f.endswith(".lean"):
            p = os.path.join(dp, f)
            mod = os.path.relpath(p, src)[:-5].replace(os.sep, ".")
            ts = theorems(p)
            if ts:
                lines.append(mod + " " + " ".join(ts))
open(out, "w").write("\n".join(sorted(lines)) + "\n")
print(f"{len(lines)} modules, {sum(len(l.split()) - 1 for l in lines)} theorems")
