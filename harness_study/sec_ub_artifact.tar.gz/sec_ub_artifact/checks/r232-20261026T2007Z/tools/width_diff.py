#!/usr/bin/env python3
"""Compare the R2-32 proof sources with the R2-64 package's after a mechanical width normalization.
Usage: width_diff.py R264_PKG R232_SRC OUT_TSV OUT_DETAIL
Pairs: R264/GivenPA/X.lean <-> R232/X.lean (top level), R264/VerifOrch/** <-> R232/VerifOrch/**,
R264/VO/** <-> R232/VO/**, R264/Gen/** <-> R232/Gen/**.
GivenPA. module prefixes are removed on the R2-64 side (the R2-32 tree keeps those modules at its top level).
Normalization (both sides): the decimal constants 2^64-1, 2^64, 2^63-1, 2^63, 2^32-1, 2^32, 2^31-1, 2^31 map to
UMAX/UMOD/SMAX/SMOD by width; the standalone tokens 64/63 (R2-64 side) and 32/31 (R2-32 side) map to W/W1;
'u64'/'U64'/'64bit'-style suffixes likewise. Lines that still differ are listed (difflib), per file."""
import os, re, sys, difflib
r64, r32, out_tsv, out_det = sys.argv[1:5]
C64 = {"18446744073709551615": "UMAX", "18446744073709551616": "UMOD", "9223372036854775807": "SMAX",
       "9223372036854775808": "SMOD"}
C32 = {"4294967295": "UMAX", "4294967296": "UMOD", "2147483647": "SMAX", "2147483648": "SMOD"}
def norm(s, side):
    if side == 64:
        s = s.replace("GivenPA.", "")
    for k, v in (C64 if side == 64 else C32).items():
        s = s.replace(k, v)
    w, w1 = ("64", "63") if side == 64 else ("32", "31")
    s = re.sub(r"(?<![0-9A-Za-z_.])" + w + r"(?![0-9])", "W", s)
    s = re.sub(r"(?<![0-9A-Za-z_.])" + w1 + r"(?![0-9])", "W1", s)
    s = re.sub(r"([uUiI])" + w + r"(?![0-9])", r"\1W", s)
    return s
pairs = []
for f in sorted(os.listdir(os.path.join(r64, "GivenPA"))):
    if f.endswith(".lean"):
        pairs.append((os.path.join(r64, "GivenPA", f), os.path.join(r32, f), "top/" + f))
for sub in ("VerifOrch", "VO", "Gen"):
    for dp, dn, fn in os.walk(os.path.join(r64, sub)):
        for f in fn:
            if f.endswith(".lean"):
                p = os.path.join(dp, f)
                rel = os.path.relpath(p, r64)
                pairs.append((p, os.path.join(r32, rel), rel))
rows, det = [], []
for a, b, rel in sorted(pairs, key=lambda x: x[2]):
    if not os.path.exists(b):
        rows.append((rel, "missing_in_r2_32", 0)); continue
    ta, tb = open(a, encoding="utf-8").read(), open(b, encoding="utf-8").read()
    if ta == tb:
        rows.append((rel, "identical", 0)); continue
    la = norm(ta, 64).splitlines(); lb = norm(tb, 32).splitlines()
    if la == lb:
        rows.append((rel, "width_only", 0)); continue
    d = [l for l in difflib.unified_diff(la, lb, lineterm="", n=0) if not l.startswith(("---", "+++"))]
    nchg = sum(1 for l in d if l[:1] in "+-")
    rows.append((rel, "other", nchg))
    det.append(f"=== {rel} ({nchg} changed normalized lines)")
    det.extend(d[:60])
extra = []
for dp, dn, fn in os.walk(r32):
    for f in fn:
        if f.endswith(".lean"):
            rel = os.path.relpath(os.path.join(dp, f), r32)
            key = rel if rel.split(os.sep)[0] in ("VerifOrch", "VO", "Gen") else "top/" + rel
            if not any(r[0] == key for r in rows):
                extra.append(rel)
with open(out_tsv, "w") as fh:
    for r in rows:
        fh.write("\t".join(map(str, r)) + "\n")
    for e in sorted(extra):
        fh.write(f"{e}\tonly_in_r2_32\t0\n")
open(out_det, "w").write("\n".join(det) + "\n")
from collections import Counter
c = Counter((r[0].split("/")[0], r[1]) for r in rows)
print(dict(sorted(c.items())), "only_in_r2_32:", len(extra))
