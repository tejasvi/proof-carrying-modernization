#!/usr/bin/env python3
"""Raw line diff of R2-32 proof sources against the R2-64 package, classified line pair by line pair.
Usage: width_diff_v2.py R264_PKG R232_SRC OUT_TSV OUT_DETAIL
A changed line pair (old, new), paired in order inside a diff hunk with equal -/+ counts, is 'width' when replacing,
in the old line, every standalone decimal number by MAP (64->32, 63->31, 2^64-1, 2^64, 2^63-1, 2^63 -> their 32-bit
counterparts) and removing the 'GivenPA.' module prefix gives exactly the new line. Everything else is 'other' and
is listed with its R2-32 line number. Gen/ files are counted the same way."""
import os, re, sys, difflib
r64, r32, out_tsv, out_det = sys.argv[1:5]
MAP = {"64": "32", "63": "31", "18446744073709551615": "4294967295", "18446744073709551616": "4294967296",
       "9223372036854775807": "2147483647", "9223372036854775808": "2147483648"}
def subst(s):
    s = s.replace("GivenPA.", "")
    return re.sub(r"(?<![0-9A-Za-z_])\d+(?![0-9])", lambda m: MAP.get(m.group(0), m.group(0)), s)
pairs = []
for f in sorted(os.listdir(os.path.join(r64, "GivenPA"))):
    if f.endswith(".lean"):
        pairs.append((os.path.join(r64, "GivenPA", f), os.path.join(r32, f), f))
for sub in ("VerifOrch", "VO", "Gen"):
    for dp, dn, fn in os.walk(os.path.join(r64, sub)):
        for f in fn:
            if f.endswith(".lean"):
                p = os.path.join(dp, f); rel = os.path.relpath(p, r64)
                pairs.append((p, os.path.join(r32, rel), rel))
rows, det = [], []
for a, b, rel in sorted(pairs, key=lambda x: x[2]):
    if not os.path.exists(b):
        rows.append((rel, "missing_in_r2_32", 0, 0)); continue
    la = open(a, encoding="utf-8").read().splitlines(); lb = open(b, encoding="utf-8").read().splitlines()
    if la == lb:
        rows.append((rel, "identical", 0, 0)); continue
    sm = difflib.SequenceMatcher(None, la, lb, autojunk=False)
    w = o = 0; items = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        if tag == "replace" and (i2 - i1) == (j2 - j1):
            for k in range(i2 - i1):
                if subst(la[i1 + k]) == lb[j1 + k]:
                    w += 1
                else:
                    o += 1; items.append(f"  r2_32:{j1 + k + 1}\n    - {la[i1 + k].strip()[:240]}\n    + {lb[j1 + k].strip()[:240]}")
        else:
            o += max(i2 - i1, j2 - j1)
            for k in range(i1, i2):
                items.append(f"  r2_64:{k + 1} only\n    - {la[k].strip()[:240]}")
            for k in range(j1, j2):
                items.append(f"  r2_32:{k + 1} only\n    + {lb[k].strip()[:240]}")
    rows.append((rel, "width_only" if o == 0 else "other", w, o))
    if o:
        det.append(f"=== {rel}: {w} width pairs, {o} other lines"); det.extend(items)
with open(out_tsv, "w") as fh:
    fh.write("file\tclass\twidth_pairs\tother_lines\n")
    for r in rows:
        fh.write("\t".join(map(str, r)) + "\n")
open(out_det, "w").write("\n".join(det) + "\n")
from collections import Counter
print(dict(sorted(Counter(((r[0].split("/")[0] if "/" in r[0] else "top"), r[1]) for r in rows).items())))
