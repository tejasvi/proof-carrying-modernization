RESULT: R3 agrees with the delivery. VO.v0.tu__ossfuzz_json_fuzzer.LLVMFuzzerTestOneInput_spec (hypothesis size < 2^31) uses exactly [propext, Classical.choice, Quot.sound]; the kernel replays all 193 modules of its import closure with rc 0 (192 replayed + 1 import-only root); the statement is as announced. Notes: (a) the orchestrator snapshot's SHA256SUMS lists itself (its other 75 entries verify); (b) noop_free/noop_realloc (stuck) and noop_malloc (blocked) have no VO module; only their generated definitions are in the closure.

# R3 check (yajl-ruby json_fuzzer, size < 2^31): evidence owner's fork check-fork, started 2026-10-26T20:07Z by date -u

## Copy
- replay/yj-r3-20261026T2007Z/lean_ffab71e = <ROOT>/veriforch/runs/h_yajl_ruby_json_fuzzer_lt2p31/lean_ffab71e (with oleans) and
  replay/yj-r3-20261026T2007Z/cirlean-ffab71e = <ROOT>/veriforch/deps/cirlean-ffab71e; diff -rq against both originals empty
  (copy_identity/); no symlinks in the copies. Records copied to records/ (v0/tu__ossfuzz_json_fuzzer, run guard log,
  runs/theorem_h start record and run log, targets toml and given.json).

## Hashes (announced_check.txt)
- 11/11 announced sha256 values equal: theorem file da17fd82..., verify.json 38e4350d..., assumed.json ca3d163b... (= {}),
  units/LLVMFuzzerTestOneInput.json f05a6e2a..., toml 615ce509..., given.json 3755df17..., start record cda6d698..., run log
  2698cfd4..., orch snapshot SHA256SUMS a2400578..., given copies SHA256SUMS db6fe2fb..., R3_yajl SHA256SUMS bae2922f....
- sha256sum -c: notes/theorem/yajl_phase2_given 74/74 OK; notes/theorem/R3_yajl 14/14 OK; scratch/yj1/orch_snapshot_20261026T100738Z
  75 OK + 1 FAILED, the failing entry being ./SHA256SUMS itself (a manifest that lists itself). scheduler.py 30758b71,
  adapters/cir/adapter.py a8d438df, adapters/cir/build.py ef679367, lean.py 72cf2438, cli.py 43f988f7 = announced.
- Bundles: YajlDP 20, YajlLN 5, YajlSD 9 files equal the frozen given copies after removing the bundle prefix from import
  lines (`import LNBase` -> `import YajlLN.LNBase`), 34/34 (given_bundles_cmp_normalized.txt). The 39 given .tactics bodies
  occur verbatim (modulo indentation) in their VO unit modules, 39/39 (given_tactics_check.txt, tools/tactics_in_units.py).

## Records
- verify.json has 45 units: 42 proved (trust kernel, assumes [], statement_origin: entry mechanical, 41 given),
  yajl_buf$noop_free and yajl_buf$noop_realloc stuck, yajl_buf$noop_malloc blocked; assumed.json {}.

## Axioms (yj_pkg_axcheck/axcheck.tsv; axcheck.py --leanpath, fresh process per module)
- 42/42 VO unit theorems (one `_spec` per unit module, incl. the entry theorem): exactly [propext, Classical.choice,
  Quot.sound]. No `axiom` declaration in the package sources (Gen, VO, VerifOrch, YajlDP, YajlLN, YajlSD) or in the pin's
  CIR sources. Keyword scan (sorry, admit, native_decide, implemented_by, extern): one hit, in a doc comment of
  VerifOrch/Cir/TestEval.lean, which is not in the closure (keyword_scan.txt).

## Kernel replay (leancheck1lp.sh, LEAN_PATH = package build : pin build : toolchain; pjobs_v3 N = 1)
- Entry module VO.v0.tu__ossfuzz_json_fuzzer.LLVMFuzzerTestOneInput, import closure 193 modules (closure_entry.tsv):
  CIR 42 rc 0 + the import-only root CIR, Gen 74, VO 33, VerifOrch 9, YajlDP 20, YajlLN 5, YajlSD 9, all rc 0.
- The nine json_fuzzer callback units (json_fuzzer$yajl_found_*) are proved (std axioms) but not in the entry module's
  closure. Their nine modules were replayed as well, rc 0: with every VO unit module as a
  root the closure has 202 modules, all rc 0 or import-only (closure_allVO.tsv).

## Statement (statement/check_statement.out, fresh process, rc 0)
- forall data size m, InitExt module m -> 0 <= size /\ size <= 2^64-1 -> ReadableBuf module.initMem.next m data size ->
  size < 2^31 -> Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr data, .int size] m (fun _ _ => True);
  fn_LLVMFuzzerTestOneInput.sym = "LLVMFuzzerTestOneInput" by rfl; ctx = Ctx.ofModule module.
- In words: for every well-formed memory that keeps the module's initial blocks unchanged, and every live block after
  the globals that is an array of n unsigned bytes (values 0..255) with n = size < 2^31 (ReadableBuf alone gives
  n < 2^63), the call of the entry point returns normally: Returns is Calls with every exit other than a return mapped
  to False. Nothing is said about the return value.

## noop units
- No VO module exists for yajl_buf$noop_{free,realloc,malloc}; the closure contains only their generated definitions
  (Gen.v0_tu__ossfuzz_json_fuzzer.Unit.F.fn_yajl_buf_noop_{malloc,realloc,free}). No theorem about them is in the closure,
  and the entry theorem has no hypothesis about them.

## Pin
- deps/cirlean-ffab71e: git HEAD ffab71ea54802c61bcfab3d389f12c94bb85b388 (no promisor config; read with
  GIT_ALLOW_PROTOCOL=file); the same path as in the T2 check's replay commands (checks/t2-20261026T0321Z/claimsv3);
  newest file mtime under it 2026-10-25T16:32Z and newest .olean 2026-10-25T16:18Z, i.e. unchanged since before the
  T2 check (pin_vs_t2.txt). The T2 check kept no file manifest of the pin, so the match is by path, HEAD and mtimes.

## Not done here
- Proof-line recount, Gen regeneration from the .cir files, cirpun scan.

## Compute and process
- Guarded compute of this check: 0.125 core-h (copy 0.001; 202 replay jobs and the axiom check 0.124;
  statement check under 0.001). The copied producer guard log of the run of record (records/run_guard.log) sums to
  3.271 core-h, matching the announced 3.27 core-h.
- Disclosure: the pjobs_v3 scheduler processes ran outside a guard; every job they started ran under coreh_guard_v2.
