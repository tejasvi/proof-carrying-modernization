import VO.v0.tu__ossfuzz_json_fuzzer.LLVMFuzzerTestOneInput

#check @VO.v0.tu__ossfuzz_json_fuzzer.LLVMFuzzerTestOneInput_spec
#print VerifOrch.Cir.InitExt
#print VerifOrch.Cir.ReadableBuf
#print CIR.Returns
#print Gen.v0_tu__ossfuzz_json_fuzzer.Unit.ctx
example : Gen.v0_tu__ossfuzz_json_fuzzer.Unit.fn_LLVMFuzzerTestOneInput.sym = "LLVMFuzzerTestOneInput" := rfl
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.LLVMFuzzerTestOneInput_spec
