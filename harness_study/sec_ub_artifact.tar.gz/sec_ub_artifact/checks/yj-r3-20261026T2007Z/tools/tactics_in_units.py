#!/usr/bin/env python3
"""For each GIVEN/<unit>.tactics, check that its non-blank lines occur, in order and contiguously after
stripping common indentation, in PKG/VO/v0/<tu>/<unit>.lean. Prints one row per tactics file and a tally."""
import os, sys
given, vodir = sys.argv[1], sys.argv[2]
ok = bad = 0
for f in sorted(os.listdir(given)):
    if not f.endswith(".tactics"):
        continue
    unit = f[:-len(".tactics")]
    t = [l.strip() for l in open(os.path.join(given, f), encoding="utf-8").read().splitlines() if l.strip()]
    p = os.path.join(vodir, unit + ".lean")
    if not os.path.exists(p):
        print(f"NOFILE\t{unit}"); bad += 1; continue
    u = [l.strip() for l in open(p, encoding="utf-8").read().splitlines() if l.strip()]
    found = any(u[i:i + len(t)] == t for i in range(0, len(u) - len(t) + 1)) if t else True
    print(f"{'OK' if found else 'NOTFOUND'}\t{unit}\t{len(t)} lines")
    ok += found; bad += (not found)
print(f"tally: {ok} found verbatim (modulo indentation), {bad} not")
