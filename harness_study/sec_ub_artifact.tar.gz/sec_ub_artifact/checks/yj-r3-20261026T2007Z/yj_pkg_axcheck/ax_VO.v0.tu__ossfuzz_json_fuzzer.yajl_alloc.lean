import VO.v0.tu__ossfuzz_json_fuzzer.yajl_alloc
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_alloc_spec
