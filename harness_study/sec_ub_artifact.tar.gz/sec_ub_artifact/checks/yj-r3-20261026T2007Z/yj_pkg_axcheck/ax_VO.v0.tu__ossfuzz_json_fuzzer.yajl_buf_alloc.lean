import VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_alloc
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_alloc_spec
