import VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_append
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_append_spec
