import VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_clear
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_clear_spec
