import VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_data
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_data_spec
