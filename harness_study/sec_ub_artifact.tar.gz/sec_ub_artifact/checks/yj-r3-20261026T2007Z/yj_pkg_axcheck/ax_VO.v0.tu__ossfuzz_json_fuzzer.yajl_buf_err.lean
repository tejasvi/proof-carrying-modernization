import VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_err
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_buf_err_spec
