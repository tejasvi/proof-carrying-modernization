import VO.v0.tu__ossfuzz_json_fuzzer.yajl_do_parse
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_do_parse_spec
