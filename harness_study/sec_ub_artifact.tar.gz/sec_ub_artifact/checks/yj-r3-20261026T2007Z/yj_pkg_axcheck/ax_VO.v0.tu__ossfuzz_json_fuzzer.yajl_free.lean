import VO.v0.tu__ossfuzz_json_fuzzer.yajl_free
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_free_spec
