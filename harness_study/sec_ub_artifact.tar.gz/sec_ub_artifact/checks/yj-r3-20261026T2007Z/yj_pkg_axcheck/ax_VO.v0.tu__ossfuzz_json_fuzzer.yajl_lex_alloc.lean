import VO.v0.tu__ossfuzz_json_fuzzer.yajl_lex_alloc
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_lex_alloc_spec
