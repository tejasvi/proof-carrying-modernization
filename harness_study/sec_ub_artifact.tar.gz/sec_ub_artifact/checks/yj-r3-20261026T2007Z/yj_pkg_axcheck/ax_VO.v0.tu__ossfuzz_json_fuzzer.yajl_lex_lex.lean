import VO.v0.tu__ossfuzz_json_fuzzer.yajl_lex_lex
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_lex_lex_spec
