import VO.v0.tu__ossfuzz_json_fuzzer.yajl_parse
#print axioms VO.v0.tu__ossfuzz_json_fuzzer.yajl_parse_spec
