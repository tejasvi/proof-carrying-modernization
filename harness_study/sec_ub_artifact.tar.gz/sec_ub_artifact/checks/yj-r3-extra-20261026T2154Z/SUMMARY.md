RESULT: the three items left open by checks/yj-r3-20261026T2007Z agree with the delivery. ClangIR and Gen regenerate
byte-identically from yajl-ruby 6501652d1135 (version 1.4.3) and OSS-Fuzz bd2ce21991a9's json_fuzzer.c, the two
commits Theorem's repository pins for this harness. Proof lines E 7,196 + M 57 + V 432 = 7,685 reproduced: my whole-file
recount of the 193-module closure, 30,027 lines, equals the producer's table. cirpun: closure 45 (the 45 units), CHAR 0,
AGG 0, ASSUME 0, SIGN 5 and NOOBJ 1 on a branch the harness never takes, FLAG 1103, every one on an object the scan
cannot identify: none names a known object of another width or kind, and for these accesses the scan neither finds
nor rules out a pun. memcpy overlap (added on request): the R3 closure has 2 memcpy sites and the R1 closure 5; each
copies between distinct objects.

# R3 extra checks (yajl-ruby json_fuzzer, size < 2^31): the evidence owner's writer agent, from 2026-10-26T21:54Z
Object and copies as in checks/yj-r3-20261026T2007Z; methods and tools as in checks/fh-r1-20261026T2003Z (memcpy: as in
checks/memcpy-20261025). Every job ran under that check's coreh_guard_v2 wrapper, on one core (taskset -c 381), address
space 64 GiB (*/launch*.sh). SHA256SUMS lists every file of this directory except itself, this SUMMARY.md included; it
was rewritten after the memcpy add-on and this SUMMARY.md, and the two earlier manifests (04bc170fa529..., 55 files;
adc4f9c667f7..., 66 files) are kept in replay/yj-r3-20261026T2007Z/tmp/.

## cirpun (cirpun/)
- cirpun f365f63 (checks/cirpun-20261025/tool, SHA256SUMS 10/10 OK) through evidence/tools/cirpun_claims.py, --root
  LLVMFuzzerTestOneInput, the 7 .cir files in link-group order (the R3 check's records copies; each = the run's file).
- Closure 45, FLAG 1103, CHAR 0, SIGN 5, AGG 0, NOOBJ 1, ASSUME 0. The closure is the set of the 45 unit names of
  verify.json, so it holds the 9 callbacks and the 3 noop functions; a --print-closure rerun gives the same TSV.
- FLAG objects: 679 results of indirect calls the scan cannot resolve; 394 pointers read through unknown pointers; 27
  indirect calls with an unresolved target (12 allocator calls through the yajl_alloc_funcs pointers that yajl_alloc
  copies into the handle with memcpy, yajl.c:93, and that the lexer, buffers and byte stacks hold; 15 callback calls in
  yajl_do_parse); 2 errno reads through __errno_location's result (yajl_parser.c:250, 278); 1 stderr argument
  (yajl_buf.c:51, noop_realloc). By operation: 815 loads, 258 stores, 27 indirect calls, 2 strtod and 1 fprintf
  arguments.
- NOOBJ 1 is strtod's null endptr (yajl_parser.c:276) and SIGN 5 is strtod's char* over unsigned char buffers. They,
  the 2 strtod FLAG rows and the errno read at :278 are in the yajl_double branch, the errno read at :250 in the
  yajl_integer branch; the harness sets yajl_number and leaves both NULL (json_fuzzer.c:75-87), so neither runs.

## Sources and regeneration (regen/; outputs in replay/yj-r3-20261026T2007Z/regen/)
- The 21 files of ext/yajl and lib/yajl/version.rb ('1.4.3') equal git show 6501652d1135 in the local single-commit
  bare clone (no remote; GIT_ALLOW_PROTOCOL=file, --no-optional-locks); none of the commit's ext/yajl files is missing.
  _ossfuzz/json_fuzzer.c equals OSS-Fuzz bd2ce21991a9:projects/yajl-ruby/json_fuzzer.c. Theorem's
  projects/yajl-ruby/project.yaml (5d3996fc...) pins both commits; read as a plain file, since that copy is a partial
  clone (no git command ran in it). compile_commands.json 15f19eb1....
- clang upstream-4955d32b with the entry's flags (-I<root>/ext/yajl) and -fclangir -emit-cir -Xclang
  -fno-clangir-call-conv-lowering, as build.py ef679367 (_build_linked): 7/7 .cir files byte-identical to the run's.
- The pin copy's cir2lean --link Gen.v0_tu__ossfuzz_json_fuzzer.Unit (cwd = the .cir dir, link-group order): 72
  functions (61 with body), 12 records, 130 globals; the Gen tree equals the package's (diff -r empty; 75 files, 74 .lean).

## Proof size (lines/; tools/yj_lines_cmp.py = fh_lines_cmp.py with an owner column, module keys, counted-text sha256)
- notes/theorem/R3_yajl SHA256SUMS 14/14 OK; PROOF_SIZE.md, .tsv and _summary.txt copied to records/.
- My recount of the 193 closure files: 30,027 lines (CIR 11,379, Gen 10,963, VO 1,378, VerifOrch 1,557, YajlDP 1,739,
  YajlLN 336, YajlSD 2,675). The producer's rows: 30,027 = E 7,196 + M 57 + V 432 (= 7,685) + G 10,963 + L 11,379; E by
  engineer worker-yj-1 1,292, worker-yj-1+worker-yj-2 962, worker-yj-2 1,747, worker-yj-3 3,195; V 430 veriforch + 2 mechanical.
- 163 files equal; the other 30 are unit modules that differ by exactly the 888 lines of their 30 tactics files, each
  of which recounts to its row (lines and sha256); counted-text sha256 160/160 equal.
- Author column (tools/yj_role_xcheck.py): 33/33 unit modules agree with given.json's source field and the phase-1
  unit records; the M units are yajl_set_default_alloc_funcs and yajl_encode$hexToDigit (statement and tactic text equal
  to phase-1 LLM proposals).

## memcpy overlap (memcpy/; method and controls of checks/memcpy-20261025)
- evidence/tools/memcpy_claims.py (sha256 as in that check's SHA256SUMS) with the cirpun f365f63 closure. That check's
  controls give its expected rows byte for byte (pos_SetStr 1 site, neg_ToDocument 0; controls.out).
- Jobs: R3 = cirpun/jobs.tsv of this check (closure 45, 2 sites); R1 = cirpun/jobs.tsv of checks/fh-r1-20261026T2003Z
  (closure 32, 5 sites); no unmatched closure names (claims_memcpy.tsv).
- Each site read in the source (sites.tsv), all 7 between distinct objects. R3: yajl.c:93 copies the local struct
  afsBuffer (the harness passes afs = NULL) into the freshly allocated handle; yajl_buf.c:165 copies into the data block
  of a yajl_buf (the decode buffer or the lexer's buffer) from the input text, a token (in the input text or the lexer's
  buffer), a string literal or the local array utf8Buf, or a number token on branches the harness never takes. R1:
  cjson_read_fuzzer.c:62 copies the input into copied = malloc(size); cJSON.c:1237 (print) and :523 (ensure) copy the
  print buffer into a fresh allocation, and only when hooks.reallocate is NULL, while global_hooks starts as {malloc,
  free, realloc} (cJSON.c:178-186); :1435 (print_value, case cJSON_Raw, which the parser never creates) and :974
  (print_string_ptr) copy an item's string block into the print buffer.

## Compute and process
- Guarded jobs (cirpun, closure, regen, lines, roles, memcpy, pointer shas, 4 pdftotext reads of the paper, seals):
  about 3 core-s in all, each log 0.000 core-h. A first pointer-sha run with cap 0.01 core-h was killed at its start (a
  cap below the guard's margin); rerun at 0.05, same output.
- Writes: this directory; replay/yj-r3-20261026T2007Z/regen and tmp (pre-edit copies of the four paper files, the seal
  scripts and listings, the two earlier manifests, the evidence owner's 22:24Z stub of this file).
- Bare: file reads and listings, one sort and cmp of the two 45-name lists, and one call of the guard script with
  --help, which stopped at its argument parsing before running any command. This SUMMARY.md was written with a shell
  heredoc at the evidence owner's request, after the file tool refused it; it replaces the owner's 22:24Z stub.
- Questions for producers: none.
