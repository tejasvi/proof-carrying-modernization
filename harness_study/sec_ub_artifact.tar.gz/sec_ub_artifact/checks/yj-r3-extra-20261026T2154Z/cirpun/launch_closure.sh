#!/bin/bash
# second guarded job, one core: the same scan with --print-closure (closure list on stderr); its TSV is compared with run 1's
C=<ROOT>/fv_paper/evidence/checks/yj-r3-extra-20261026T2154Z
T=<ROOT>/fv_paper/evidence/checks/cirpun-20261025/tool
F=$(awk -F'\t' 'NR==2 {print $5}' "$C/cirpun/jobs.tsv")
<ROOT>/bin/n10 python3 -I <ROOT>/cc50/rung3/shared_tools/coreh_guard_v2_20261023T0655Z/coreh_guard_v2.py "$C/cirpun/closure.guard.log" 0.1 --poll 1 --run -- taskset -c 381 bash -c "ulimit -v 67108864; export TMPDIR=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z/tmp; $T/bin/cirpun --root LLVMFuzzerTestOneInput --print-closure $F > $C/cirpun/closure_run.tsv 2> $C/cirpun/closure_run.err; echo rc=\$? >> $C/cirpun/closure_run.err"
echo "guard rc=$?"
if cmp -s "$C/cirpun/closure_run.tsv" "$C/cirpun/r3__LLVMFuzzerTestOneInput.tsv"; then echo "TSV equal to run 1"; else echo "TSV DIFFERS from run 1"; fi
