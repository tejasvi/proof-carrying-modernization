#!/bin/bash
# cirpun scan of the R3 entry's closure (yajl-ruby json_fuzzer), as in checks/fh-r1-20261026T2003Z/cirpun/: cirpun f365f63
# from checks/cirpun-20261025/tool (its SHA256SUMS checked first), driver evidence/tools/cirpun_claims.py, one job with
# --root LLVMFuzzerTestOneInput over the run's seven .cir files (link-group order). The .cir files are the copies in
# checks/yj-r3-20261026T2007Z/records; each is compared with the run directory's file first.
set -u
C=<ROOT>/fv_paper/evidence/checks/yj-r3-extra-20261026T2154Z
T=<ROOT>/fv_paper/evidence/checks/cirpun-20261025/tool
REC=<ROOT>/fv_paper/evidence/checks/yj-r3-20261026T2007Z/records/v0/tu__ossfuzz_json_fuzzer
RUN=<ROOT>/veriforch/runs/h_yajl_ruby_json_fuzzer_lt2p31/v0/tu__ossfuzz_json_fuzzer
export TMPDIR=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z/tmp
awk -v D="$T" '{p=$2; sub(/^\*/,"",p); sub(/^\.\//,"",p); print $1 "  " D "/" p}' "$T/SHA256SUMS" | sha256sum -c \
  > "$C/cirpun/tool_sums_check.txt" 2>&1
echo "rc=$?" >> "$C/cirpun/tool_sums_check.txt"
for s in json_fuzzer yajl yajl_alloc yajl_buf yajl_encode yajl_lex yajl_parser; do
  if cmp -s "$REC/$s.cir" "$RUN/$s.cir"; then echo "$s.cir same"; else echo "$s.cir DIFFERS"; fi
done > "$C/cirpun/records_vs_run_cir.txt" 2>&1
python3 -I -B <ROOT>/fv_paper/evidence/tools/cirpun_claims.py "$T/bin/cirpun" "$C/cirpun" \
  "$C/cirpun/jobs.tsv" > "$C/cirpun/run.out" 2>&1
echo "rc=$?" >> "$C/cirpun/run.out"
