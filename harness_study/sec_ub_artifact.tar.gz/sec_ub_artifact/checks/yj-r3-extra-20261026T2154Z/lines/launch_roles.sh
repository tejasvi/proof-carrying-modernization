#!/bin/bash
# one guarded job, one core (taskset), address space 64 GiB: author-column cross-check (tools/yj_role_xcheck.py)
C=<ROOT>/fv_paper/evidence/checks/yj-r3-extra-20261026T2154Z
Y3=<ROOT>/fv_paper/evidence/checks/yj-r3-20261026T2007Z
P1=<ROOT>/veriforch/runs/h_yajl_ruby_json_fuzzer/v0/tu__ossfuzz_json_fuzzer/units
<ROOT>/bin/n10 python3 -I <ROOT>/cc50/rung3/shared_tools/coreh_guard_v2_20261023T0655Z/coreh_guard_v2.py "$C/lines/roles.guard.log" 0.05 --poll 1 --run -- taskset -c 381 bash -c "ulimit -v 67108864; export TMPDIR=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z/tmp; python3 -I -B $C/tools/yj_role_xcheck.py $Y3/closure_entry.tsv $Y3/records/h_yajl_ruby_json_fuzzer_lt2p31.given.json $P1 $C/records/PROOF_SIZE.tsv $C/lines/role_xcheck.tsv > $C/lines/role_xcheck.out 2>&1; echo rc=\$? >> $C/lines/role_xcheck.out"
echo "guard rc=$?"
