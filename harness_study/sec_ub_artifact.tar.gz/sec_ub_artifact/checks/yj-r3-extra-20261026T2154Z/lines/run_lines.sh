#!/bin/bash
# Proof-line recount by role for R3, as in checks/fh-r1-20261026T2003Z (lines_cmp.*; tools/fh_lines_cmp.py): whole-file
# recount of every module in the entry's import closure (checks/yj-r3-20261026T2007Z/closure_entry.tsv, 193 modules) from
# the replay copy, compared file by file with the producer's PROOF_SIZE.tsv, whose rows are summed per file and by role.
# Tool: tools/yj_lines_cmp.py (fh_lines_cmp.py adapted to this table's columns and module-name keys). The producer's
# notes are copied to records/ first and checked against notes/theorem/R3_yajl/SHA256SUMS.
set -u
C=<ROOT>/fv_paper/evidence/checks/yj-r3-extra-20261026T2154Z
N=<ROOT>/veriforch/notes/theorem/R3_yajl
R=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z
Y3=<ROOT>/fv_paper/evidence/checks/yj-r3-20261026T2007Z
export TMPDIR=$R/tmp
for f in PROOF_SIZE.md PROOF_SIZE.tsv PROOF_SIZE_summary.txt SHA256SUMS; do
  [ -e "$C/records/$f" ] || cp -p "$N/$f" "$C/records/$f"
done
awk -v D="$N" '{p=$2; sub(/^\*/,"",p); sub(/^\.\//,"",p); print $1 "  " D "/" p}' "$N/SHA256SUMS" | sha256sum -c \
  > "$C/lines/r3_yajl_sums_check.txt" 2>&1
echo "rc=$?" >> "$C/lines/r3_yajl_sums_check.txt"
for f in PROOF_SIZE.md PROOF_SIZE.tsv PROOF_SIZE_summary.txt; do
  if cmp -s "$N/$f" "$C/records/$f"; then echo "$f copy equal"; else echo "$f copy DIFFERS"; fi
done >> "$C/lines/r3_yajl_sums_check.txt"
python3 -I -B "$C/tools/yj_lines_cmp.py" "$Y3/closure_entry.tsv" "$R/lean_ffab71e" "$R/cirlean-ffab71e" \
  "$C/records/PROOF_SIZE.tsv" "$C/lines/lines_cmp.tsv" > "$C/lines/lines_cmp.out" 2>&1
echo "rc=$?" >> "$C/lines/lines_cmp.out"
