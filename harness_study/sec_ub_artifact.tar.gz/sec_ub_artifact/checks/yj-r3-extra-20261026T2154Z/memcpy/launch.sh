#!/bin/bash
# one guarded job, one core (taskset), address space 64 GiB
C=<ROOT>/fv_paper/evidence/checks/yj-r3-extra-20261026T2154Z
<ROOT>/bin/n10 python3 -I <ROOT>/cc50/rung3/shared_tools/coreh_guard_v2_20261023T0655Z/coreh_guard_v2.py "$C/memcpy/memcpy.guard.log" 0.1 --poll 1 --run -- taskset -c 381 bash -c "ulimit -v 67108864; bash $C/memcpy/run_memcpy.sh"
echo "guard rc=$?"
