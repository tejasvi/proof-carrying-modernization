#!/bin/bash
# memcpy-overlap scan of the R3 and R1 entry closures, as in checks/memcpy-20261025: tool evidence/tools/memcpy_claims.py
# (its sha256 checked against that check's SHA256SUMS), the cirpun f365f63 closure, the controls of that check (jobs and
# expected rows: controls_memcpy.tsv), then the two jobs: R3 = this check's cirpun/jobs.tsv, R1 = the fh-r1 check's
# cirpun/jobs.tsv (both the punning scan's job lists).
set -u
C=<ROOT>/fv_paper/evidence/checks/yj-r3-extra-20261026T2154Z
M=<ROOT>/fv_paper/evidence/checks/memcpy-20261025
TOOL=<ROOT>/fv_paper/evidence/tools/memcpy_claims.py
CIRPUN=<ROOT>/fv_paper/evidence/checks/cirpun-20261025/tool/bin/cirpun
export TMPDIR=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z/tmp
{
  awk -v T="$TOOL" '$2 == T {print $1 "  " $2}' "$M/SHA256SUMS" | sha256sum -c
  echo "rc=$?"
  awk -v D="$(dirname $CIRPUN)/.." '$2 == "./bin/cirpun" {print $1 "  " D "/bin/cirpun"}' "$(dirname $CIRPUN)/../SHA256SUMS" | sha256sum -c
  echo "rc=$?"
} > "$C/memcpy/tool_check.txt" 2>&1
python3 -I -B "$TOOL" "$CIRPUN" "$C/memcpy/controls_memcpy.tsv" "$M/jobs_controls.tsv" > "$C/memcpy/controls.out" 2>&1
echo "rc=$?" >> "$C/memcpy/controls.out"
if cmp -s "$C/memcpy/controls_memcpy.tsv" "$M/controls_memcpy.tsv"; then echo "controls equal to checks/memcpy-20261025/controls_memcpy.tsv"; else echo "controls DIFFER"; fi >> "$C/memcpy/controls.out"
python3 -I -B "$TOOL" "$CIRPUN" "$C/memcpy/claims_memcpy.tsv" "$C/cirpun/jobs.tsv" \
  <ROOT>/fv_paper/evidence/checks/fh-r1-20261026T2003Z/cirpun/jobs.tsv > "$C/memcpy/claims.out" 2>&1
echo "rc=$?" >> "$C/memcpy/claims.out"
