#!/bin/bash
# sha256 of the records the paper text cites (one guarded job)
E=<ROOT>/fv_paper/evidence/checks
sha256sum $E/fh-r1-20261026T2003Z/SUMMARY.md $E/yj-r3-20261026T2007Z/SUMMARY.md $E/cost-20261026T2014Z/SUMMARY.md \
  <ROOT>/fv_paper/replay/fh-r1-20261026T2003Z/notes/PROOF_SIZE_FH.md \
  <ROOT>/fv_paper/replay/fh-r1-20261026T2003Z/notes/PROOF_SIZE_FH.tsv
