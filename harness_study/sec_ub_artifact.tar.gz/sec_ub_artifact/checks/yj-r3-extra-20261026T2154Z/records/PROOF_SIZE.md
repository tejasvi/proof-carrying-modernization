# R3 (yajl-ruby json_fuzzer at size < 2^31): proof size by role and all-in cost

Final count, 2026-10-26T12:34Z (worker-yj-1), from the run of record's package
`runs/h_yajl_ruby_json_fuzzer_lt2p31/lean_ffab71e` and its given contracts
`targets/h_yajl_ruby_json_fuzzer_lt2p31.given.json` (3755df17…). Script `scripts/proof_size_h.py` (a yajl version of
notes/stretch_cjson/fh/accounting/proof_size_fh.py: same line rule and roles). Per-file rows: `PROOF_SIZE.tsv` (file,
role, owner, lines, bytes, sha256 of the counted text). Read-only accounting; no Lean run.

Line rule: non-blank lines outside `--` comments and `/- -/` blocks. The closure starts at the entry's unit module
`VO.v0.tu__ossfuzz_json_fuzzer.LLVMFuzzerTestOneInput` and follows imports: 33 of the 42 given units are in it. The 9
`json_fuzzer$yajl_found_*` callbacks are proved as units in the same run but are not in the closure: the entry's proof
handles the callbacks inside worker-yj-3's YajlDP modules (VerifOrch.Cir.YajlDPCb). Modules of the Lean toolchain (Lean,
Std.Data.HashMap, Std.Data.HashSet, Lean.Elab.Tactic.Omega: the `missing modules` line of PROOF_SIZE_summary.txt) are
outside the count.

Roles: E veriforch proof engineers (agents worker-yj-1, worker-yj-2, worker-yj-3), M model (here only text byte-identical, up to
whitespace, to phase 1's model proposals; no model call in phase 2), V veriforch-generated (unit-module skeletons:
imports, options, callee aliases, `#print axioms`; the mechanical entry statement; VerifOrch.Cir.Entry), G generated
program (cir2lean, apart), L cirlean library (not counted). A rendered unit module is split into `#generated` (V),
`#statement` (its author) and an inline tactic body (its author); a body copied from a tactics file is counted once,
in the tactics file's row (every rendered body equals its file).

| role | rows | lines | contents |
|---|---:|---:|---|
| E engineers | 103 | 7,196 | bundles YajlSD 2,675 (string_decode, 9 modules), YajlDP 1,739 (do_parse, 20), YajlLN 336 (lex_number, 5); support modules YajlDPUnits 271, YajlLex 261, YajlDPTac 237, YajlDec 226, YajlLexLL 204, YajlDPShapes 151, YajlStr 98, YajlDPCb 88; tactics files 839 (worker-yj-1 22 files 737, worker-yj-2 4 files 100, worker-yj-3 2 files 2); given statements 60 (worker-yj-1 23 units 46, worker-yj-2 5 units 10, worker-yj-3 2 units 4); inline tactics of the 3 bundle units 11 |
| M model (phase 1) | 4 | 57 | yajl_set_default_alloc_funcs statement 2 + tactics 11; yajl_encode$hexToDigit statement 6 + tactics 38 |
| V veriforch-generated | 35 | 432 | 33 unit-module skeletons 409, the mechanical entry statement 2, VerifOrch.Cir.Entry 21 |
| **proof total E+M+V** | 142 | **7,685** | |
| G generated program (apart) | 74 | 10,963 | `Gen.v0_tu__ossfuzz_json_fuzzer.*` (cir2lean) |
| L cirlean library (not counted) | 43 | 11,379 | CIR.* in the closure |

By engineer (E rows): worker-yj-1 1,292 lines (52 rows: the lex_number bundle's 5 modules, 22 tactics files, 23 statements,
lex_number's inline tactic, and the decode module PU2 = worker-yj-1's SDW1 with 30 side goals); worker-yj-1+worker-yj-2 962 (the decode bundle's Base, Cap and Main: worker-yj-1's SDBase and cut-based script,
extended by worker-yj-2 with the capture/replay tactics); worker-yj-2 1,747 (17 rows: YajlStr, YajlDec, YajlLex, YajlLexLL, 4
tactics files, 5 statements, decode modules PS, PR, PU1); worker-yj-3 3,195 (31 rows: YajlDP bundle and support modules, 2
statements, 2 tactics files, decode modules PW and PU3).

Engineers' own tables (lines with check times): `accounting_w-yj2.tsv`, `accounting_w-yj3.tsv`.

## All-in cost, up to the run of record's end (2026-10-26T12:30:12Z)

| item | amount | source |
|---|---:|---|
| model calls inside veriforch, phase 2 | $0.00 (0 calls) | `--no-llm` in every test and in the run of record; no `llm/usage.jsonl` in the phase-2 run dirs |
| agent tokens, phase-2 agents: worker-h-2 15.08 (whole session), worker-yj-1 240.75, worker-yj-2 147.39, worker-yj-3 164.02; 2,519 calls | $567.24 | `AGENT_COST_YAJL_R3.md` / `.json` (main's agentcost.py, read 12:33:44Z; copies of notes/theorem/AGENT_COST_YAJL_R3.*) |
| agent tokens, w-theorem (343 calls) | $68.51 | same; all 5 agents $635.75 (2,862 calls) |
| core-hours, phase 2 | 43.332 core-h | `coreh.tsv` (guard exit lines; no guard nests inside another) |
| wall, run of record | 2 h 22 min 34 s | 10:07:38Z..12:30:12Z |
| phase 1 (apart) | $61.12 model (204 calls), 8.083 core-h | runs/h_yajl_ruby_json_fuzzer; runs/theorem_h/guard_phase1.log |

Not in the agent figures: main's own session tokens and the 3 compaction calls inside the window (main's JSON
estimates each at $0.19 to $4.84).
