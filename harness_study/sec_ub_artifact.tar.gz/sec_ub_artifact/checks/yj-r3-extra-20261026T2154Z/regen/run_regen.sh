#!/bin/bash
# Regeneration of R3's ClangIR and generated Lean program, as in checks/fh-r1-20261026T2003Z (Sources and build inputs;
# regen/). Target file: checks/yj-r3-20261026T2007Z/records/h_yajl_ruby_json_fuzzer_lt2p31.toml (root, compile_commands,
# link_groups). Each source is compiled as veriforch's adapters/cir/build.py does in _build_linked (orch snapshot
# scratch/yj1/orch_snapshot_20261026T100738Z, build.py ef679367): the pinned clang, the entry's flags from
# compile_commands.json (compdb.entry_flags: here only the -I), -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering,
# the absolute source path; then `cir2lean --link Gen.v0_tu__ossfuzz_json_fuzzer.Unit PKG <the .cir names in link-group
# order>` with cwd = the .cir directory, using the pin copy's cir2lean. Outputs go to the replay copy's regen/.
# Git reads only in the two local single-commit bare clones (no remote configured), with file-only protocols.
set -u
C=<ROOT>/fv_paper/evidence/checks/yj-r3-extra-20261026T2154Z
R=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z
SRC="<ROOT>/veriforch/targets/theorem_src/yajl-ruby@6501652d1135"
CC_DB=<ROOT>/veriforch/targets/h_yajl_ruby_json_fuzzer.compile_commands.json
GY="<ROOT>/veriforch/targets/theorem_upstreams/github.com_brianmario_yajl-ruby@6501652d1135.git"
GO="<ROOT>/veriforch/targets/theorem_upstreams/github.com_google_oss-fuzz@bd2ce21991a9.git"
CY=6501652d113557d976676134056aa983e7863020
CO=bd2ce21991a94a362b92fb1bf25f86d5a1a60842
PROJ=<ROOT>/veriforch/targets/theorem_oss_verify_proofs/projects/yajl-ruby/project.yaml
CLANG=<ROOT>/cirlean_work/toolchain/upstream-4955d32b/bin/clang
C2L=$R/cirlean-ffab71e/.lake/build/bin/cir2lean
REC=<ROOT>/fv_paper/evidence/checks/yj-r3-20261026T2007Z/records/v0/tu__ossfuzz_json_fuzzer
O=$R/regen
export TMPDIR=$R/tmp GIT_ALLOW_PROTOCOL=file GIT_TERMINAL_PROMPT=0 GIT_NO_LAZY_FETCH=1
G() { git --no-optional-locks -c core.fsmonitor=false "$@"; }

# 1. sources: the recorded files against the upstream commits
{
  echo "yajl-ruby clone: commit $(G -C "$GY" cat-file -t "$CY" 2>&1) $CY; shallow: $(cat "$GY/shallow")"
  echo "oss-fuzz clone: commit $(G -C "$GO" cat-file -t "$CO" 2>&1) $CO; shallow: $(cat "$GO/shallow")"
  for f in $(cd "$SRC" && find ext/yajl -type f | LC_ALL=C sort --parallel=1) lib/yajl/version.rb; do
    if G -C "$GY" show "$CY:$f" 2>/dev/null | cmp -s - "$SRC/$f"; then st=equal; else st=DIFFERS; fi
    echo "$st	$(sha256sum "$SRC/$f" | cut -d' ' -f1)	$f"
  done
  for f in $(G -C "$GY" ls-tree -r --name-only "$CY" ext/yajl); do
    [ -e "$SRC/$f" ] || echo "MISSING_LOCALLY	-	$f"
  done
  if G -C "$GO" show "$CO:projects/yajl-ruby/json_fuzzer.c" 2>/dev/null | cmp -s - "$SRC/_ossfuzz/json_fuzzer.c"; then
    st=equal; else st=DIFFERS; fi
  echo "$st	$(sha256sum "$SRC/_ossfuzz/json_fuzzer.c" | cut -d' ' -f1)	_ossfuzz/json_fuzzer.c = oss-fuzz $CO:projects/yajl-ruby/json_fuzzer.c"
  echo "version file: $(cat "$SRC/lib/yajl/version.rb" | tr '\n' ' ')"
  echo "Theorem project.yaml (plain read; that repository copy is a partial clone, no git command run there):"
  echo "  sha256 $(sha256sum "$PROJ" | cut -d' ' -f1)"
  awk '/^oss_fuzz:|^library:|^  path:|^  commit:/' "$PROJ" | sed -e 's/^/  /'
  echo "compile_commands.json sha256 $(sha256sum "$CC_DB" | cut -d' ' -f1)"
} > "$C/regen/sources.txt" 2>&1

# 2. ClangIR: one clang call per source, as build.py; then a byte comparison with the run's .cir
mkdir -p "$O/cir" "$O/pkg/Gen/v0_tu__ossfuzz_json_fuzzer"
STEMS=""
for s in _ossfuzz/json_fuzzer.c ext/yajl/yajl.c ext/yajl/yajl_alloc.c ext/yajl/yajl_buf.c ext/yajl/yajl_encode.c \
         ext/yajl/yajl_lex.c ext/yajl/yajl_parser.c; do
  stem=$(basename "$s" .c)
  STEMS="$STEMS $stem"
  FL=$(jq -r --arg f "$SRC/$s" '.[] | select(.file == $f) | .arguments | map(select(startswith("-I"))) | join(" ")' "$CC_DB")
  echo "+ $CLANG $FL -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering $SRC/$s -o $O/cir/$stem.cir"
  ( cd "$O/cir" && "$CLANG" $FL -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering "$SRC/$s" -o "$O/cir/$stem.cir" )
  echo "rc=$?"
done > "$C/regen/clang.out" 2>&1
for stem in $STEMS; do
  if cmp -s "$O/cir/$stem.cir" "$REC/$stem.cir"; then st=identical; else st=DIFFERS; fi
  echo "$st	$(sha256sum "$O/cir/$stem.cir" | cut -d' ' -f1)	$stem.cir"
done > "$C/regen/cir_cmp.txt" 2>&1

# 3. Gen: cir2lean --link on the regenerated .cir files, then a tree comparison with the package's Gen
NAMES=""
for stem in $STEMS; do NAMES="$NAMES $stem.cir"; done
{
  echo "+ cd $O/cir && $C2L --link Gen.v0_tu__ossfuzz_json_fuzzer.Unit $O/pkg$NAMES"
  ( cd "$O/cir" && "$C2L" --link Gen.v0_tu__ossfuzz_json_fuzzer.Unit "$O/pkg" $NAMES )
  echo "rc=$?"
} > "$C/regen/cir2lean.out" 2>&1
diff -r "$O/pkg/Gen" "$R/lean_ffab71e/Gen" > "$C/regen/regen_vs_pkg_gen.diff.txt" 2>&1
echo "diff rc=$?" > "$C/regen/regen_vs_pkg_gen.rc.txt"
{
  echo "regenerated Gen files: $(find "$O/pkg/Gen" -type f | wc -l)"
  echo "package Gen files: $(find "$R/lean_ffab71e/Gen" -type f | wc -l)"
  echo "regenerated .lean files: $(find "$O/pkg/Gen" -type f -name '*.lean' | wc -l)"
} > "$C/regen/gen_counts.txt" 2>&1
