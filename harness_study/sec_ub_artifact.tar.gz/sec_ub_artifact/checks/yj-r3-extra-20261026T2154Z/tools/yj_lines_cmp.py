#!/usr/bin/env python3
"""Recount Lean lines of every module in a harness closure (whole files; the paper's line rule as in
tools/proof_lines.py: non-blank lines without `--` lines and /- -/ blocks) and compare with a producer's per-row
proof-size TSV. A copy of checks/fh-r1-20261026T2003Z/tools/fh_lines_cmp.py (same line rule, same per-file
comparison), adapted to the yajl producer table (notes/theorem/R3_yajl/PROOF_SIZE.tsv):
- columns file[#part], role, owner, lines, bytes, sha256 (FH: no owner column);
- rows are keyed by module name (FH: by relative path); a tactics-file row is keyed by its absolute path;
- the sha256 column holds the sha256 of the counted text (counted lines joined, each followed by a newline),
  not of the whole file, so that is what is compared for whole-module rows;
- tactics-file rows are recounted from their files, and each unit module that differs is tested against the
  tactics files of its unit (file name = the unit module's last name component).

Usage: yj_lines_cmp.py CLOSURE_TSV PKG_ROOT CIR_ROOT PRODUCER_TSV OUT_TSV
CLOSURE_TSV: closure_verdicts.py output (prefix, module, ...); CIR modules are read from CIR_ROOT, others from PKG_ROOT.
"""
import collections, hashlib, os, sys

def lean_lines(p):
    n, inc = 0, False
    for l in open(p, encoding="utf-8", errors="replace"):
        if inc:
            if "-/" in l:
                inc = False
            continue
        s = l.strip()
        if not s or s.startswith("--"):
            continue
        if s.startswith("/-"):
            if "-/" not in s[2:]:
                inc = True
            continue
        n += 1
    return n

def counted_sha(p):
    out, inc = [], False
    for l in open(p, encoding="utf-8", errors="replace").read().split("\n"):
        if inc:
            if "-/" in l:
                inc = False
            continue
        s = l.strip()
        if not s or s.startswith("--"):
            continue
        if s.startswith("/-"):
            if "-/" not in s[2:]:
                inc = True
            continue
        out.append(l)
    return hashlib.sha256("".join(x + "\n" for x in out).encode()).hexdigest()

def main():
    clo, pkg, cir, ptsv, out = sys.argv[1:6]
    mine = {}
    for line in open(clo):
        f = line.rstrip("\n").split("\t")
        if len(f) < 2:
            continue
        pre, mod = f[0], f[1]
        rel = os.path.join(*mod.split(".")) + ".lean"
        p = os.path.join(cir if pre == "CIR" else pkg, rel)
        mine[mod] = (pre, lean_lines(p), counted_sha(p))
    prod = collections.defaultdict(int)
    prod_roles = collections.defaultdict(int)
    prod_owner = collections.defaultdict(int)
    prod_role_of = collections.defaultdict(set)
    whole_sha = {}
    tac_rows = {}
    for i, line in enumerate(open(ptsv)):
        f = line.rstrip("\n").split("\t")
        if i == 0 or len(f) < 6:
            continue
        file, role, owner, n, sha = f[0], f[1], f[2], int(f[3]), f[5]
        base = file.split("#")[0]
        prod[base] += n
        prod_roles[role] += n
        prod_owner[(role, owner)] += n
        prod_role_of[base].add(role)
        if "#" not in file:
            whole_sha[base] = sha
        if file.endswith(".tactics"):
            tac_rows[file] = (n, sha)
    rows, same, diff, only_mine, only_prod = [], 0, 0, 0, 0
    for k in sorted(set(mine) | set(prod)):
        a = mine.get(k)
        b = prod.get(k)
        if a and b is not None:
            st = "same" if a[1] == b else "differs"
            same += st == "same"; diff += st == "differs"
        elif a:
            st = "closure_only"; only_mine += 1
        else:
            st = "producer_only"; only_prod += 1
        rows.append([k, a[0] if a else "", str(a[1]) if a else "", str(b) if b is not None else "",
                     ",".join(sorted(prod_role_of.get(k, []))), st])
    with open(out, "w") as o:
        o.write("file\tprefix\tmy_lines\tproducer_lines\tproducer_roles\tstatus\n")
        for r in rows:
            o.write("\t".join(r) + "\n")
    tot_mine = sum(v[1] for v in mine.values())
    by_pre = collections.Counter()
    for v in mine.values():
        by_pre[v[0]] += v[1]
    print(f"closure files {len(mine)}, lines {tot_mine}; by prefix " + ", ".join(f"{k} {v}" for k, v in sorted(by_pre.items())))
    print(f"producer rows summed per file: {len(prod)} files, lines {sum(prod.values())}; by role " +
          ", ".join(f"{k} {v}" for k, v in sorted(prod_roles.items())))
    print("producer rows by role and owner: " + ", ".join(f"{r}/{o or '-'} {v}" for (r, o), v in sorted(prod_owner.items())))
    print(f"files: same {same}, differs {diff}, closure_only {only_mine}, producer_only {only_prod}")
    shabad = [k for k, s in whole_sha.items() if k in mine and mine[k][2] != s]
    print(f"whole-module counted-text sha256 rows compared {sum(1 for k in whole_sha if k in mine)}, mismatches {len(shabad)}" +
          (": " + " ".join(shabad[:10]) if shabad else ""))
    # tactics-file rows: recount from the files, then test each differing unit module against its unit's files
    tbad, tsum = [], 0
    by_unit = collections.defaultdict(int)
    for tf, (n, sha) in sorted(tac_rows.items()):
        m = lean_lines(tf)
        if m != n or counted_sha(tf) != sha:
            tbad.append(tf)
        tsum += m
        by_unit[os.path.basename(tf)[:-len(".tactics")]] += m
    print(f"tactics-file rows {len(tac_rows)}, lines recounted {tsum}, rows whose recount or sha differs {len(tbad)}" +
          (": " + " ".join(tbad[:10]) if tbad else ""))
    unexplained = []
    for r in rows:
        if r[5] != "differs":
            continue
        unit = r[0].rsplit(".", 1)[-1]
        if int(r[2]) - int(r[3]) != by_unit.get(unit, -1):
            unexplained.append(r[0])
    nd = sum(1 for r in rows if r[5] == "differs")
    dl = sum(int(r[2]) - int(r[3]) for r in rows if r[5] == "differs")
    print(f"differing modules {nd}, line difference {dl}; differences not equal to their unit's tactics-file lines "
          f"{len(unexplained)}" + (": " + " ".join(unexplained[:10]) if unexplained else ""))
    po_not_tac = [r[0] for r in rows if r[5] == "producer_only" and not r[0].endswith(".tactics")]
    print(f"producer_only rows that are not tactics files {len(po_not_tac)}" + (": " + " ".join(po_not_tac[:10]) if po_not_tac else ""))

main()
