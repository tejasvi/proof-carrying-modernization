#!/usr/bin/env python3
"""Cross-check of the author column of the producer's proof-size table (PROOF_SIZE.tsv) for the unit modules of R3's
closure, from the run's given file and the phase-1 unit records (written for this check, not the producer's script).

For each VO unit module in the closure: the given entry of its unit (module name = the unit name with non-alphanumeric
characters replaced by '_'), the engineer its `source` names (worker-yj-1/worker-yj-2/worker-yj-3), and whether its statement (with its
binders, whitespace-normalised) or its tactic text (stripped) equals an LLM proposal in the phase-1 unit record.
Expected author of the statement row: V for the entry (mechanical), M if the statement equals a phase-1 proposal, else
E with the engineer from `source`. Same for the tactic row (tactics file or inline #tactics), except that the entry's
tactic text is the given one. Prints one row per module and a summary line.

Usage: yj_role_xcheck.py CLOSURE_TSV GIVEN_JSON PHASE1_UNITS_DIR PRODUCER_TSV OUT_TSV
"""
import json, os, re, sys

def ident(s):
    return re.sub(r"[^A-Za-z0-9_]", "_", s)

def norm(s):
    return " ".join((s or "").split())

def main():
    clo, gpath, p1, ptsv, out = sys.argv[1:6]
    given = json.load(open(gpath))
    by_mod = {ident(k): (k, v) for k, v in given.items()}
    mods = [l.split("\t")[1] for l in open(clo) if l.startswith("VO\t")]
    prod = {}
    for i, l in enumerate(open(ptsv)):
        f = l.rstrip("\n").split("\t")
        if i == 0 or len(f) < 6:
            continue
        prod[f[0]] = (f[1], f[2])
    rows, bad = [], 0
    for m in sorted(mods):
        short = m.rsplit(".", 1)[-1]
        unit, e = by_mod.get(short, (None, None))
        if e is None:
            rows.append([m, "-", "NO GIVEN ENTRY", "", "", "", ""]); bad += 1
            continue
        eng = next((w for w in ("worker-yj-1", "worker-yj-2", "worker-yj-3") if w in e.get("source", "")), "?")
        tac = open(e["tactics_file"]).read().strip() if e.get("tactics_file") else (e.get("tactics") or "").strip()
        ss = st = False
        rp = os.path.join(p1, unit + ".json")
        if os.path.exists(rp):
            for h in json.load(open(rp)).get("history") or []:
                pr = h.get("proposal") or {}
                if pr.get("statement_origin", "llm") == "llm" and norm(pr.get("statement")) == norm(e["statement"]) \
                        and norm(pr.get("binders")) == norm(e["binders"]):
                    ss = True
                if tac and (pr.get("tactics") or "").strip() == tac:
                    st = True
        is_entry = short == "LLVMFuzzerTestOneInput"
        exp_s = ("V", "mechanical") if is_entry else (("M", "phase-1 model") if ss else ("E", eng))
        exp_t = ("M", "phase-1 model") if (st and not is_entry) else ("E", eng)
        got_s = prod.get(m + "#statement")
        tkey = e["tactics_file"] if e.get("tactics_file") else m + "#tactics"
        got_t = prod.get(tkey)
        ok = got_s == exp_s and got_t == exp_t
        bad += not ok
        rows.append([m, unit, eng, "/".join(exp_s), "/".join(got_s or ("-", "-")), "/".join(exp_t),
                     "/".join(got_t or ("-", "-")) + ("" if ok else "  MISMATCH")])
    with open(out, "w") as o:
        o.write("module\tunit\tsource_engineer\texpected_statement\tproducer_statement\texpected_tactics\tproducer_tactics\n")
        for r in rows:
            o.write("\t".join(r) + "\n")
    ms = sum(1 for r in rows if r[3].startswith("M/"))
    mt = sum(1 for r in rows if r[5].startswith("M/"))
    print(f"unit modules {len(rows)}, rows agreeing with the producer's author column {len(rows) - bad}, mismatches {bad}; "
          f"statements equal to a phase-1 proposal {ms}, tactic texts equal to a phase-1 proposal {mt}")

main()
