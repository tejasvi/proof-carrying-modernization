RESULT: the patched yajl lexer delivery (<ROOT>/veriforch/scratch/yj1/r3_patched_ln, SHA256SUMS 515890ae...) agrees with its description. YajlLN.ln_spec is the contract of yajl_lex$yajl_lex_number on yajl-ruby 1.4.3 (6501652d) with one line changed inside yajl_lex_number (yajl_lex.c:392). It holds for every jsonTextLen with 0 <= len <= |xs| and len < 2^32, the whole range of that unsigned int parameter (R3's contract has len < 2^31). It and the six other theorems of its five modules use only Lean's standard axioms. The kernel replays, with rc 0, all 121 modules of LNMain's 122-module import closure that are not import-only (the CIR root only imports), on cirlean ffab71e, R3's pin. ClangIR and the generated Lean program regenerate byte-identically. It is a unit theorem: no entry theorem of the delivery or of R3's package uses it, and R3's harness theorem with its 2^31 bound is unchanged.

# Check of the patched yajl lexer unit theorem (fork check-fork, started 2026-10-27T23:52:05Z by date -u)
Supersedes the stopped check-fork (checks/yjpatch-20261027T1820Z and replay/yjpatch-20261027T1820Z, left untouched).
Object: <ROOT>/veriforch/scratch/yj1/r3_patched_ln, theorem YajlLN.ln_spec (pkg/src/LNMain.lean:39); copy
replay/yjpatch2-20261027T2352Z/r3_patched_ln.

## Copy (copy_identity/)
- cp -a under the guard; diff -rq against the original empty; 257 files, no symlinks; the delivered SHA256SUMS (sha256
  515890aeb7c6e63c...) checks 256/256 OK in the copy.

## Pin (pin/)
- <ROOT>/veriforch/deps/cirlean-ffab71e = the R3 check's copy replay/yj-r3-20261026T2007Z/cirlean-ffab71e (diff -rq empty;
  2,314 files, no symlinks), used read-only; HEAD ffab71ea54802c61bcfab3d389f12c94bb85b388 (no promisor config; read with
  GIT_ALLOW_PROTOCOL=file and --no-optional-locks); toolchain v4.35.0.
- With LEAN_PATH = delivery build : pin build : toolchain (pin/leanpath.txt), `import LNMain` and #print axioms load in a
  fresh process, rc 0 (pin/load_test.out).
- The delivery records no build command or lake trace. ffab71e is established as the build of its oleans by three facts:
  (a) the 70 Gen modules whose source equals R3's have .olean files byte-identical to R3's package, which was built on
  ffab71e (vs_r3/gen_olean_cmp.tsv); (b) this pin's cir2lean regenerates the delivered Gen byte for byte; (c) every
  module of the closure replays with rc 0 against this pin.

## Source (source/)
- Upstream 6501652d:ext/yajl/yajl_lex.c, read from the local single-commit bare clone (no remote, no promisor; file-only
  protocol): sha256 0285ff9fd572bbc1...; it equals targets/theorem_src's copy and checks/yajl-bound-20261025/yajl_lex.c.
- Delivered yajl_lex.c sha256 00927f2c4e7f6c77.... The diff has 1 hunk, 1 line removed and 1 line added (392c392); both
  files have 758 lines. The line is inside yajl_lex_number (definition at line 355, body at lines 357-439). Raw diff:
  source/yajl_lex_6501652d_vs_delivered.diff (sha256 c64b5210853fc117...).

## Regeneration (regen/)
- The other 20 files of theorem_src's ext/yajl equal `git show 6501652d`, and _ossfuzz/json_fuzzer.c equals OSS-Fuzz
  bd2ce21991a9:projects/yajl-ruby/json_fuzzer.c (regen/sources.txt).
- A, the producer's paths: the six unchanged sources from theorem_src and yajl_lex.c compiled in place in the delivery
  directory (read only), with -I theorem_src/ext/yajl as in the compile database, clang upstream-4955d32b and -fclangir
  -emit-cir -Xclang -fno-clangir-call-conv-lowering. All 7 .cir files are byte-identical to the delivered cirs/; against
  R3's run, only yajl_lex.cir differs. The pin copy's cir2lean --link (72 functions, 61 with a body, 12 records, 130
  globals) gives a Gen tree equal to the delivered pkg/src/Gen (diff -r empty; 75 files, 74 .lean).
- B, a source tree in the replay dir (theorem_src's files with the delivered yajl_lex.c in place of the original). Its
  .cir and Gen differ from the delivered ones only through embedded source paths (loc entries, and __FILE__ strings with
  their array lengths and hashed names). B2, the same tree compiled with -fmacro-prefix-map to the producer's paths and
  with the loc paths mapped, gives 7/7 .cir byte-identical, in both orders of the two maps.

## Against R3 (vs_r3/; R3 = replay/yj-r3-20261026T2007Z/lean_ffab71e)
- Gen: 5 of 75 files differ. fn_yajl_lex_yajl_lex_number.lean differs in 8 of its 1,013 lines, at 420-422, 521-523 and
  601-602. The other four differ only through the __FILE__ string constant of yajl_lex.c (its path, hence its length and
  hashed name): fn_yajl_lex_lex.lean (2 references), Types.lean (the global), Unit.lean (the globals list) and
  manifest.json (the two functions' hashes and one source column on line 392).
- LN modules against R3's YajlLN bundle (vs_r3/ln_classify_v3.sh, ln_classify_v3.tsv): LNBase is identical; LN0, LN1,
  LN2 and LNMain have the same line counts. Their changed lines: 6 import prefixes (YajlLN.X -> X); 7 bound literals
  only (2^31 -> 2^32, 2147483648 -> 4294967296, h31 -> h32); 4 comments or doc comments; 5 other lines: LN0:35, LN1:34
  and LN2:31 (each closing simp set gains intMin_u and intMax_u32), and LN1:29-30 (the fraction loop's invariant and
  measure take the counter as Nat, cast to Int, instead of Int).
- Size of the five proof modules: 415 lines (LNBase 234, LN0 40, LN1 40, LN2 36, LNMain 65).

## Statement (statement/check_statement.out, fresh process, rc 0)
- #check @YajlLN.ln_spec printed in full, with CIR.Returns, CIR.Frame, CIR.BlockKind and ctx = CIR.Ctx.ofModule module.
  Two rfl checks are accepted: fn_yajl_lex_yajl_lex_number.sym = "yajl_lex$yajl_lex_number" and
  module.globals.length = 130.
- In words: for every memory m holding three distinct live blocks below m.next, each with index at least 130 (so none
  of the module's 130 globals): a yajl_lexer_t record whose bufInUse field is 0; a yajl_handle_t record whose
  bytesConsumed field holds off (neither of these two of kind readonly); and an array xs of unsigned 8-bit values, each
  0..255. Then, for every len with 0 <= len <= |xs| and len < 2^32, and off <= len, the call yajl_lex_number(lexer,
  &xs[0], len, &handle.bytesConsumed) returns normally. CIR.Returns is CIR.Calls with every exit other than a return
  mapped to False; read as in the R1 and R3 checks, the call terminates, reaches no undefined behaviour in cirlean's
  semantics and returns. On return:
  - the result is a token t in {10, 11, 3, 4}: yajl_tok_integer, yajl_tok_double, yajl_tok_eof and yajl_tok_error in
    yajl_lex.h;
  - the offset becomes some off' with off <= off' <= len, and off < off' when t is 10 or 11;
  - the handle record is unchanged except bytesConsumed = off', and the lexer record is unchanged except its error field;
  - no other block below m.next changes (CIR.Frame m m' [hb, lb]).
  The statement says nothing about which token the input calls for, or about the number's value.
- In the .ilean files, the declaration position of every top-level declaration equals its source line, and the direct
  imports equal the sources' imports (statement/ilean_vs_source.txt). The LN modules were not recompiled.

## Axioms and scan (axioms/)
- axcheck.py --leanpath, one fresh process per module: 7/7 std. ln_spec, ln_body, ln_part0/1/2 and LNBase's
  wrap_u8_bounds use [propext, Classical.choice, Quot.sound]; lnEnv_eq uses [Quot.sound].
- Keyword scan (axioms/keyword_scan.txt): the delivered sources (5 LN modules, 74 Gen) have no hit for axiom, sorry,
  admit, native_decide, implemented_by, extern, sorryAx or ofReduceBool. The pin's CIR sources have no axiom
  declaration. Their hits are doc comments, two tactic macros (native_decide; the debug tactics that admit goals) and one
  implemented_by on loopHead, which affects compiled code only. None of them shows up in ln_spec's axioms.

## Kernel replay (replay/)
- Import closure of LNMain: 122 modules: CIR 42 plus the import-only root CIR, Gen 74, and LNBase, LN0, LN1, LN2, LNMain
  (closure_verdicts.tsv). leancheck1lp.sh, one process per module, with the LEAN_PATH above: 121/121 rc 0 (verdicts/);
  closure_verdicts.py rc 0. Module wall times sum to 154.5 s; the largest is Gen...Unit at 42.2 s; LN0 takes 4.0 s, LN2
  6.1 s.

## Scope (scope/scope.txt)
- The delivery holds only the LN modules and the generated program: no VO module, no entry theorem, and no module
  imports LNMain. R3's entry theorem reaches R3's own YajlLN.LNMain (its 2^31 contract) through VO
  yajl_lex_yajl_lex_number, and its statement keeps size < 2^31. So ln_spec is a unit theorem, and no harness-level
  theorem uses it.

## Not done here
- Recompiling the LN modules from source (the delivery's own build took about 1 core-h); cirpun and memcpy scans; author
  attribution of the proof lines; any harness-level composition.

## Compute and process
- Guarded jobs used 0.043 core-h in all (guard_totals.txt): the replay 0.042 (the scheduler and its 121 jobs under one
  guard, at most 2 Lean processes at once), the axiom check 0.001, and the rest 0.000 each. The rest are the copy, the
  pin diff, the load test, the closure probe and the tally (under g1.sh, logs in guard_logs_g1/), the regeneration and
  the statement check.
- Bare (outside a guard):
  - file reads and listings;
  - the diff -rq and sha256sum -c of the copy;
  - git cat-file, show and rev-parse in the two bare clones and the pin copy;
  - single-file diff, cmp and sha256sum;
  - jq and awk extractions;
  - the LN classifier runs, the Gen .olean cmp loop and the .ilean comparison;
  - the keyword and scope greps.
- The first LN classifier (v1) split its input wrongly and was overwritten by v2. v2's exponent mapping was too narrow;
  it is kept as vs_r3/ln_classify_v2_superseded.*. v3 is the record.
- Writes: this directory and replay/yjpatch2-20261027T2352Z (the copy, regeneration outputs, the source tree, work files
  and PROGRESS_chk.md). For the background replay launch, the tool created its own output file under its /tmp task
  directory; the launch's output went to replay/launch_replay.out, and no command of this check wrote to /tmp or /dev/shm.
- Messages: none.
