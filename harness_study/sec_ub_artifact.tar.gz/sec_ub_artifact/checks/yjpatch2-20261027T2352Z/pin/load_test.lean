import LNMain
#print axioms YajlLN.ln_spec
