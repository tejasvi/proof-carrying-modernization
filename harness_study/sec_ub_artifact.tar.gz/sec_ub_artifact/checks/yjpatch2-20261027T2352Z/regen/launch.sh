#!/bin/bash
# one guarded job (coreh_guard_v2, cap 0.05 core-h), niceness 10, address space 32 GiB
C=<ROOT>/fv_paper/evidence/checks/yjpatch2-20261027T2352Z
R=<ROOT>/fv_paper/replay/yjpatch2-20261027T2352Z
mkdir -p "$R/tmp" && cd "$R" && TMPDIR=$R/tmp <ROOT>/bin/n10 python3 -I <ROOT>/cc50/rung3/shared_tools/coreh_guard_v2_20261023T0655Z/coreh_guard_v2.py "$C/regen/regen.guard.log" 0.05 --poll 1 --run -- bash -c "ulimit -v 33554432; bash $C/regen/run_regen.sh"
echo "guard rc=$?"
