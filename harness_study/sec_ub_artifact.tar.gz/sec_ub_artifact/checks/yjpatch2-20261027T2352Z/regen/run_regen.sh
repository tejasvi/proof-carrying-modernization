#!/bin/bash
# check-fork regeneration of the patched yajl_lex delivery's ClangIR and generated Lean (Gen), modelled on
# checks/yj-r3-extra-20261026T2154Z/regen/run_regen.sh (clang upstream-4955d32b; the entry's -I flags from the compile
# database; -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering; cir2lean --link with cwd = the .cir dir, link-group order).
# A: exact producer paths (the six unchanged sources from theorem_src, yajl_lex.c from the delivery dir, read only).
# B: a source tree in the replay dir (theorem_src files with the delivered yajl_lex.c in place of the original);
#    its .cir files embed the replay-tree paths, so they are compared after mapping those paths to the producer's.
# Git reads only in the local single-commit bare clones (file-only protocol, no fetch, --no-optional-locks).
set -u
C=<ROOT>/fv_paper/evidence/checks/yjpatch2-20261027T2352Z
R=<ROOT>/fv_paper/replay/yjpatch2-20261027T2352Z
SRC="<ROOT>/veriforch/targets/theorem_src/yajl-ruby@6501652d1135"
DLV=<ROOT>/veriforch/scratch/yj1/r3_patched_ln
CC_DB=<ROOT>/veriforch/targets/h_yajl_ruby_json_fuzzer.compile_commands.json
GY="<ROOT>/veriforch/targets/theorem_upstreams/github.com_brianmario_yajl-ruby@6501652d1135.git"
GO="<ROOT>/veriforch/targets/theorem_upstreams/github.com_google_oss-fuzz@bd2ce21991a9.git"
CY=6501652d113557d976676134056aa983e7863020
CO=bd2ce21991a94a362b92fb1bf25f86d5a1a60842
CLANG=<ROOT>/cirlean_work/toolchain/upstream-4955d32b/bin/clang
C2L=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z/cirlean-ffab71e/.lake/build/bin/cir2lean
R3CIR=<ROOT>/fv_paper/evidence/checks/yj-r3-20261026T2007Z/records/v0/tu__ossfuzz_json_fuzzer
R3GEN=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z/lean_ffab71e/Gen
DGEN=$R/r3_patched_ln/pkg/src/Gen
DCIR=$R/r3_patched_ln/cirs
export TMPDIR=$R/tmp GIT_ALLOW_PROTOCOL=file GIT_TERMINAL_PROMPT=0 GIT_NO_LAZY_FETCH=1
G() { git --no-optional-locks -c core.fsmonitor=false "$@"; }
STEMS="json_fuzzer yajl yajl_alloc yajl_buf yajl_encode yajl_lex yajl_parser"
relsrc() { case "$1" in json_fuzzer) echo _ossfuzz/json_fuzzer.c;; *) echo "ext/yajl/$1.c";; esac; }
iflags() { jq -r --arg f "$SRC/$1" '.[] | select(.file == $f) | .arguments | map(select(startswith("-I"))) | join(" ")' "$CC_DB"; }

# 0. the six unchanged sources (and the headers) against the upstream commits
{
  echo "yajl-ruby clone: $(G -C "$GY" cat-file -t "$CY" 2>&1) $CY; oss-fuzz clone: $(G -C "$GO" cat-file -t "$CO" 2>&1) $CO"
  for f in $(cd "$SRC" && find ext/yajl -type f | LC_ALL=C sort --parallel=1); do
    if G -C "$GY" show "$CY:$f" 2>/dev/null | cmp -s - "$SRC/$f"; then st=equal; else st=DIFFERS; fi
    echo "$st	$(sha256sum "$SRC/$f" | cut -d' ' -f1)	theorem_src/$f"
  done
  if G -C "$GO" show "$CO:projects/yajl-ruby/json_fuzzer.c" 2>/dev/null | cmp -s - "$SRC/_ossfuzz/json_fuzzer.c"; then st=equal; else st=DIFFERS; fi
  echo "$st	$(sha256sum "$SRC/_ossfuzz/json_fuzzer.c" | cut -d' ' -f1)	theorem_src/_ossfuzz/json_fuzzer.c = oss-fuzz $CO:projects/yajl-ruby/json_fuzzer.c"
  echo "delivered yajl_lex.c (compiled in place, read only): $(sha256sum "$DLV/yajl_lex.c" | cut -d' ' -f1); copy in replay: $(sha256sum "$R/r3_patched_ln/yajl_lex.c" | cut -d' ' -f1)"
  echo "compile database sha256 $(sha256sum "$CC_DB" | cut -d' ' -f1); clang sha256 $(sha256sum "$CLANG" | cut -d' ' -f1); cir2lean (pin copy) sha256 $(sha256sum "$C2L" | cut -d' ' -f1)"
} > "$C/regen/sources.txt" 2>&1

# A. exact producer paths
OA=$R/regen_exact
mkdir -p "$OA/cir" "$OA/pkg"
for stem in $STEMS; do
  rs=$(relsrc $stem); FL=$(iflags "$rs")
  if [ "$stem" = yajl_lex ]; then IN="$DLV/yajl_lex.c"; else IN="$SRC/$rs"; fi
  echo "+ cd $OA/cir && $CLANG $FL -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering $IN -o $OA/cir/$stem.cir"
  ( cd "$OA/cir" && "$CLANG" $FL -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering "$IN" -o "$OA/cir/$stem.cir" )
  echo "rc=$?"
done > "$C/regen/clang_exact.out" 2>&1
for stem in $STEMS; do
  if cmp -s "$OA/cir/$stem.cir" "$DCIR/$stem.cir"; then a=identical; else a=DIFFERS; fi
  if cmp -s "$OA/cir/$stem.cir" "$R3CIR/$stem.cir"; then b=identical; else b=differs; fi
  echo "$stem.cir	regen $(sha256sum "$OA/cir/$stem.cir" | cut -c1-16)	vs delivered: $a	vs R3 run: $b"
done > "$C/regen/cir_cmp_exact.txt" 2>&1
NAMES=""; for stem in $STEMS; do NAMES="$NAMES $stem.cir"; done
{ echo "+ cd $OA/cir && $C2L --link Gen.v0_tu__ossfuzz_json_fuzzer.Unit $OA/pkg$NAMES"
  ( cd "$OA/cir" && "$C2L" --link Gen.v0_tu__ossfuzz_json_fuzzer.Unit "$OA/pkg" $NAMES ); echo "rc=$?"; } > "$C/regen/cir2lean_exact.out" 2>&1
diff -r "$OA/pkg/Gen" "$DGEN" > "$C/regen/gen_exact_vs_delivered.diff.txt" 2>&1; echo "diff rc=$?" > "$C/regen/gen_exact_vs_delivered.rc.txt"

# B. replay source tree
TB=$R/srctree/yajl-ruby@6501652d1135_patched
mkdir -p "$TB/ext" "$TB/_ossfuzz"
cp -rL "$SRC/ext/yajl" "$TB/ext/yajl" && cp -L "$SRC/_ossfuzz/json_fuzzer.c" "$TB/_ossfuzz/json_fuzzer.c" && cp -L "$R/r3_patched_ln/yajl_lex.c" "$TB/ext/yajl/yajl_lex.c"
echo "tree B: $(find "$TB" -type l | wc -l) symlinks; ext/yajl vs theorem_src: $(diff -rq "$SRC/ext/yajl" "$TB/ext/yajl" | tr '\n' ' ')" > "$C/regen/tree_b.txt" 2>&1
OB=$R/regen_tree
mkdir -p "$OB/cir" "$OB/cir_mapped" "$OB/pkg"
for stem in $STEMS; do
  rs=$(relsrc $stem); FL="-I$TB/ext/yajl"
  echo "+ cd $OB/cir && $CLANG $FL -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering $TB/$rs -o $OB/cir/$stem.cir"
  ( cd "$OB/cir" && "$CLANG" $FL -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering "$TB/$rs" -o "$OB/cir/$stem.cir" )
  echo "rc=$?"
done > "$C/regen/clang_tree.out" 2>&1
for stem in $STEMS; do
  # map the replay-tree paths to the producer's: the patched file to the delivery path, the rest to theorem_src
  awk -v a="\"$TB/ext/yajl/yajl_lex.c\"" -v b="\"$DLV/yajl_lex.c\"" -v c="$TB/" -v d="$SRC/" \
    '{ while ((i = index($0, a)) > 0) $0 = substr($0, 1, i-1) b substr($0, i+length(a)); while ((i = index($0, c)) > 0) $0 = substr($0, 1, i-1) d substr($0, i+length(c)); print }' \
    "$OB/cir/$stem.cir" > "$OB/cir_mapped/$stem.cir"
  if cmp -s "$OB/cir_mapped/$stem.cir" "$DCIR/$stem.cir"; then a=identical; else a=DIFFERS; fi
  echo "$stem.cir	tree-B regen with paths mapped vs delivered: $a"
done > "$C/regen/cir_cmp_tree_mapped.txt" 2>&1
{ echo "+ cd $OB/cir && $C2L --link Gen.v0_tu__ossfuzz_json_fuzzer.Unit $OB/pkg$NAMES"
  ( cd "$OB/cir" && "$C2L" --link Gen.v0_tu__ossfuzz_json_fuzzer.Unit "$OB/pkg" $NAMES ); echo "rc=$?"; } > "$C/regen/cir2lean_tree.out" 2>&1
diff -r "$OB/pkg/Gen" "$DGEN" > "$C/regen/gen_tree_vs_delivered.diff.txt" 2>&1; echo "diff rc=$?" > "$C/regen/gen_tree_vs_delivered.rc.txt"

# counts
{ echo "delivered Gen files: $(find "$DGEN" -type f | wc -l) (.lean $(find "$DGEN" -type f -name '*.lean' | wc -l))"
  echo "exact regen Gen files: $(find "$OA/pkg/Gen" -type f | wc -l); tree-B regen Gen files: $(find "$OB/pkg/Gen" -type f | wc -l)"
  echo "R3 package Gen files: $(find "$R3GEN" -type f | wc -l)"; } > "$C/regen/gen_counts.txt" 2>&1
echo done
