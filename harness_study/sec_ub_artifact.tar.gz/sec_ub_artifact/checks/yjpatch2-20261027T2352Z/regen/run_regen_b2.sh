#!/bin/bash
# check-fork, tree B2: the replay source tree of run_regen.sh (tree B) compiled again with -fmacro-prefix-map so that
# __FILE__ strings name the producer's paths (the patched file -> the delivery path, the rest -> theorem_src); loc()
# paths are then mapped as in run_regen.sh. Expect every .cir byte-identical to the delivered one, which shows that tree B
# differs from the delivery only by embedded source paths. Both orders of the two prefix maps are tried and recorded.
set -u
C=<ROOT>/fv_paper/evidence/checks/yjpatch2-20261027T2352Z
R=<ROOT>/fv_paper/replay/yjpatch2-20261027T2352Z
SRC="<ROOT>/veriforch/targets/theorem_src/yajl-ruby@6501652d1135"
DLV=<ROOT>/veriforch/scratch/yj1/r3_patched_ln
CLANG=<ROOT>/cirlean_work/toolchain/upstream-4955d32b/bin/clang
C2L=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z/cirlean-ffab71e/.lake/build/bin/cir2lean
TB=$R/srctree/yajl-ruby@6501652d1135_patched
DCIR=$R/r3_patched_ln/cirs
DGEN=$R/r3_patched_ln/pkg/src/Gen
export TMPDIR=$R/tmp
STEMS="json_fuzzer yajl yajl_alloc yajl_buf yajl_encode yajl_lex yajl_parser"
relsrc() { case "$1" in json_fuzzer) echo _ossfuzz/json_fuzzer.c;; *) echo "ext/yajl/$1.c";; esac; }
for order in 1 2; do
  O=$R/regen_tree_b2_order$order
  mkdir -p "$O/cir" "$O/cir_mapped" "$O/pkg"
  M1="-fmacro-prefix-map=$TB/ext/yajl/yajl_lex.c=$DLV/yajl_lex.c"; M2="-fmacro-prefix-map=$TB/=$SRC/"
  if [ $order = 1 ]; then MAPS="$M1 $M2"; else MAPS="$M2 $M1"; fi
  for stem in $STEMS; do
    rs=$(relsrc $stem)
    echo "+ cd $O/cir && $CLANG -I$TB/ext/yajl $MAPS -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering $TB/$rs -o $O/cir/$stem.cir"
    ( cd "$O/cir" && "$CLANG" -I"$TB/ext/yajl" $MAPS -fclangir -emit-cir -Xclang -fno-clangir-call-conv-lowering "$TB/$rs" -o "$O/cir/$stem.cir" )
    echo "rc=$?"
  done > "$C/regen/clang_tree_b2_order$order.out" 2>&1
  for stem in $STEMS; do
    awk -v a="\"$TB/ext/yajl/yajl_lex.c\"" -v b="\"$DLV/yajl_lex.c\"" -v c="$TB/" -v d="$SRC/" \
      '{ while ((i = index($0, a)) > 0) $0 = substr($0, 1, i-1) b substr($0, i+length(a)); while ((i = index($0, c)) > 0) $0 = substr($0, 1, i-1) d substr($0, i+length(c)); print }' \
      "$O/cir/$stem.cir" > "$O/cir_mapped/$stem.cir"
    if cmp -s "$O/cir_mapped/$stem.cir" "$DCIR/$stem.cir"; then st=identical; else st=DIFFERS; fi
    echo "$stem.cir	tree B2 (order $order), loc paths mapped, vs delivered: $st"
  done > "$C/regen/cir_cmp_tree_b2_order$order.txt" 2>&1
done
echo done
