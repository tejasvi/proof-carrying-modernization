#!/bin/bash
# Kernel replay of the 121 non-import-only modules of LNMain's import closure: one leancheck1lp.sh process per module,
# at most 2 at once (pjobs_v3: N 2, FLOOR 2, MIN_MEM_GB 40), the whole scheduler tree under ONE coreh_guard_v2 (cap
# 0.4 core-h, so the scheduler is metered too), niceness 10, address space 32 GiB per process.
C=<ROOT>/fv_paper/evidence/checks/yjpatch2-20261027T2352Z
R=<ROOT>/fv_paper/replay/yjpatch2-20261027T2352Z
mkdir -p "$R/tmp" "$C/replay/verdicts" && cd "$R" && TMPDIR=$R/tmp <ROOT>/bin/n10 python3 -I <ROOT>/cc50/rung3/shared_tools/coreh_guard_v2_20261023T0655Z/coreh_guard_v2.py "$C/replay/replay.guard.log" 0.4 --poll 2 --run -- bash -c "ulimit -v 33554432; python3 -I <ROOT>/fv_paper/evidence/tools/pjobs_v3.py $C/replay/replay_jobs.txt 2 450 40 2 $C/replay/pjobs.log"
echo "guard rc=$?"
