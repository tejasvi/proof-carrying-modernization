import LNMain

#check @YajlLN.ln_spec
#print CIR.Returns
#print CIR.Frame
#print CIR.Block
#print CIR.BlockKind
#print Gen.v0_tu__ossfuzz_json_fuzzer.Unit.ctx
example : Gen.v0_tu__ossfuzz_json_fuzzer.Unit.fn_yajl_lex_yajl_lex_number.sym = "yajl_lex$yajl_lex_number" := rfl
example : Gen.v0_tu__ossfuzz_json_fuzzer.Unit.module.globals.length = 130 := rfl
#print axioms YajlLN.ln_spec
