#!/bin/bash
# Classify each line pair of R3's YajlLN/<f>.lean vs the delivered <f>.lean (same line counts, so pair by line number).
# Mapping applied to the R3 line (v3): drop the "YajlLN." import prefix; 2147483648 -> 4294967296; 2147483647 -> 4294967295;
# "^ 31" -> "^ 32"; h31 -> h32. A pair equal after the mapping = import-prefix or bound-literal; a pair where either
# line is a comment (starts with --, or opens/continues a /-! or /-- block) = comment; anything else = other.
# (v2: pairs read with two-file awk; v1 used paste with a delimiter paste did not take, and is superseded.)
R=<ROOT>/fv_paper/replay/yjpatch2-20261027T2352Z
R3=<ROOT>/fv_paper/replay/yj-r3-20261026T2007Z/lean_ffab71e
for f in LNBase LN0 LN1 LN2 LNMain; do
  awk -v F="$f" '
    function mapline(s,  t) { t = s; sub(/^import YajlLN\./, "import ", t); gsub(/2147483648/, "4294967296", t);
      gsub(/2147483647/, "4294967295", t); gsub(/\^ 31/, "^ 32", t); gsub(/h31/, "h32", t); return t }
    NR == FNR { old[FNR] = $0; nold = FNR; next }
    { o = old[FNR]; n = $0; inc = incomment
      if (o ~ /^\/-[-!]/ || n ~ /^\/-[-!]/) incomment = 1
      if (o == n) cls = "same"
      else if (mapline(o) == n) cls = (o ~ /^import / ? "import-prefix" : "bound-literal")
      else if (inc || incomment || o ~ /^[ \t]*--/ || n ~ /^[ \t]*--/) cls = "comment"
      else cls = "other"
      if (o ~ /-\/[ \t]*$/ || n ~ /-\/[ \t]*$/) incomment = 0
      if (cls != "same") print F ".lean:" FNR "\t" cls
      nnew = FNR }
    END { if (nold != nnew) print F ".lean\tLINE-COUNT-DIFFERS " nold " vs " nnew }' "$R3/YajlLN/$f.lean" "$R/r3_patched_ln/pkg/src/$f.lean"
done
