# Priority #2 at `cirlean` `next2` (`424e821`) — Whole-Harness `cJSON` (`R1` at `< 2^61`) Re-Verified

## 1. Sealed Package & Top-Level `SHA256SUMS`
- **Package directory**: `<ROOT>/veriforch/runs/postfreeze/r1_cjson_next2_424e821/`
- **Frozen `cirlean` `next2` snapshot**: `<ROOT>/cirlean_frozen/next2_424e821_20261027` (commit `424e8218afa953b7c226560b3d02a29ac025b76d`, toolchain `leanprover/lean4:v4.35.0`)
- **`LEAN_PATH` for standalone kernel replay**:
  ```
  LEAN_PATH=<ROOT>/veriforch/runs/postfreeze/r1_cjson_next2_424e821/lib:<ROOT>/cirlean_frozen/next2_424e821_20261027/.lake/build/lib/lean
  ```
- **Key artifact sha256s**:
  - `RESOLUTION.tsv` (288 non-stdlib `.olean` modules: 45 `CIR` modules in `next2_424e821_20261027` + 243 modules in `lib/`): `b8eb0c161e0484b1fab28192f3e625a47fe5e53b8b9c3c1dcd95755cae42cfb9`
  - `SPEC_RESTATEMENTS.md`: `e21d82953bfcfc4be6f67e13366902f4fa9d8149bb50d7756fc935a17d14f30b`
  - `entry_diff_c4ef58d_vs_424e821.txt`: `06a3f4c863c870a3fbb78f491b643f9f16181b67acded67020728f1bb00c0e6a`
  - `axioms_all_32_units.txt`: `77dd2288b1afa9384385e359c664ca1574d6076de54d770211f553cc3da5328d`
  - `leanchecker_closure.log`: `3bc3ef1e7c9890434289c0fbd9bde4a0f856c2662f0507e5da4029edf3bde9cc`
  - `lib/VO/v0/fuzzing_cjson_read_fuzzer/LLVMFuzzerTestOneInput.olean`: `9a145dd5b0034f66167faa76b693eeb3a6c2740e64231fa703ec4c08edad936c`
  - `lib/CheckAll32Axioms.olean`: `ff3c79d9b35bf3e9e0fe152ab453c8dd4cea96f261750ac855d2bfb59957c634`

---

## 2. Entry-Point Theorem Statement (`424e821` vs `e6ac99a` vs `c4ef58d`)
The entry-point theorem statement `LLVMFuzzerTestOneInput_spec` and the definitions `VerifOrch.Cir.InitExt` and `VerifOrch.Cir.ReadableBuf` in `VerifOrch/Cir/Entry.lean` are **byte-for-byte identical** across `c4ef58d`, `e6ac99a`, and `424e821`:

```lean
@[cir_spec]
theorem LLVMFuzzerTestOneInput_spec (data : Ptr) (size : Int) (m : Mem)
    (hm : VerifOrch.Cir.InitExt module m)
    (hsize : 0 ≤ size ∧ size ≤ 18446744073709551615)
    (hbuf : VerifOrch.Cir.ReadableBuf module.initMem.next m data size)
    (hsmall : size < 2 ^ 61) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr data, .int size] m (fun _ _ => True)
```

---

## 3. Incremental Specification Restatements (`e6ac99a` -> `424e821`)
Full old-vs-new texts and unified diffs are in `SPEC_RESTATEMENTS.md`.
- **31 / 32 unit theorem statements** (including `LLVMFuzzerTestOneInput_spec`) are **byte-for-byte identical** between `e6ac99a` and `424e821`.
- **1 / 32 unit theorem statements** (`cJSON_cJSON_New_Item_spec`, and `h_new` in `CycleSpecsP2N` v4, sha256 `b977d06692043c95067d7c54c043c2a02378f8219a0cd11fb64c9d2959804768`) adds one binder after `hpun`:
  ```lean
  (hpunm : ctx.punnedMember m ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false)
  ```
  Why needed: `cirlean` `next2` (`recpun`, ancestor of `424e821`) checks `Ctx.punnedMember` (`ctx.typeAt blk.ty path` against record declarations) in addition to `Mem.punnedAccess` (`Ty.atPath blk.ty path`) on every scalar load/store (`Ctx.typedLoad`, `Ctx.typedStore`).

---

## 4. Axioms Per Unit (All 32 Units)
Every one of the 32 unit theorems depends only on `[propext, Classical.choice, Quot.sound]` (see `axioms_all_32_units.txt`).

---

## 5. Full Import-Closure Kernel Replay (`leanchecker_closure.log`)
Replayed against `LEAN_PATH=<ROOT>/veriforch/runs/postfreeze/r1_cjson_next2_424e821/lib:<ROOT>/cirlean_frozen/next2_424e821_20261027/.lake/build/lib/lean`:
1. `leanchecker --fresh VO.v0.fuzzing_cjson_read_fuzzer.LLVMFuzzerTestOneInput`: `rc = 0`.
2. `leanchecker --fresh CheckAll32Axioms`: `rc = 0`.
3. Per-module `leanchecker <module>` across all 288 non-stdlib modules in `RESOLUTION.tsv`: `288 / 288` `OK`, `rc = 0`.
