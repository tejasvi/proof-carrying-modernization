# Spec restatements for the full cJSON harness at cirlean next e6ac99a (all approved byte for byte by veriforch, the spec owner)

| module | old (R1 at c4ef58d) | new (at e6ac99a) |
|---|---|---|
| CJPrint | VerifOrch.Cir.CJPrint 8ab370f094fed885… | VerifOrch.Cir.CJPrintN 5858049365263ca1… |
| PrintSpecs | VerifOrch.Cir.PrintSpecs d2324d0a2ff01634… | VerifOrch.Cir.PrintSpecsN v2 fcfef528aee123f6… |
| CycleSpecs | CycleSpecsP2 f3d742fcc53b814d… | CycleSpecsP2N v3 1e2338c68daaf9a1… |

Why (common to all): cirlean 2d65713 makes a type-punned scalar access undefined (a load or store whose type does not match the
scalar element its block's type gives at the path). Every statement that left a block's type free became unprovable: the item
blocks (CJForest's ts[j].rt; print_array/object/value/number, cJSON_Delete), the input buffer of buffer_skip_whitespace and
parse_string, and the hooks of cJSON_New_Item. The harness meets each fixed type: every item comes from cJSON_New_Item
(.record "cJSON"), the input is an unsigned char array, the hooks are loaded from a parse_buffer record.

## 1. CJ.printable: every item's block type is .record "cJSON"
```diff
@@ -9,6 +9,11 @@
   `CJForest` already places these ghost values in memory (the item records and the string blocks), so
   `CJForest m ts ∧ CJ.forestPrintable ts` is what `print_value` and its callers read.
   Proposed for cirlean's CIR/Logic/CJTree.lean (definitions only).
+  CJPrintN (for cirlean `next` e6ac99a; draft by cirlean for veriforch's review): VerifOrch.Cir.CJPrint (sha256
+  8ab370f0…) with one more conjunct in the item case of `CJ.printable`, last: the item's block type is
+  `.record "cJSON"` (`rt`). Under type-punning UB (cirlean 2d65713) a member load from an item block of another
+  type is undefined, so the print specs need it; `cJSON_New_Item` types every item that way. New lemma
+  `CJ.printable_rt`; `CJ.printable_child` reads the fifth conjunct's first part. Nothing else changed.
 -/
 
 namespace CIR
@@ -27,11 +32,13 @@
   | some (_, ty, v) => CStrVal N ty v
 
 mutual
-/-- A tree that `print_value` can read: `valueint` an int32, `valuedouble` a double, C strings. -/
+/-- A tree that `print_value` can read: `valueint` an int32, `valuedouble` a double, C strings, and
+every item's block typed `struct cJSON` (as `cJSON_New_Item` makes it; a type-punned member load is
+undefined, cirlean 2d65713). -/
 def CJ.printable (N : Nat) : CJ → Prop
-  | .item _ _ _ _ vi vd vs st ch =>
+  | .item _ rt _ _ vi vd vs st ch =>
       (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧
-      CStrOpt N vs ∧ CStrOpt N st ∧ CJ.forestPrintable N ch
+      CStrOpt N vs ∧ CStrOpt N st ∧ CJ.forestPrintable N ch ∧ rt = .record "cJSON"
 /-- Every item of a sibling list, and their descendants, is printable. -/
 def CJ.forestPrintable (N : Nat) : List CJ → Prop
   | [] => True
@@ -54,7 +61,10 @@
     | succ j => exact ih h.2 (by simp at hj; omega)
 
 theorem CJ.printable_child {N : Nat} {t : CJ} (h : CJ.printable N t) : CJ.forestPrintable N t.child := by
-  cases t; exact h.2.2.2.2
+  cases t; exact h.2.2.2.2.1
+
+theorem CJ.printable_rt {N : Nat} {t : CJ} (h : CJ.printable N t) : t.rt = .record "cJSON" := by
+  cases t; exact h.2.2.2.2.2
 
 mutual
 /-- The height of a tree: an item is one more than its children's forest height (1 without
```

## 2. PrintSpecs -> PrintSpecsN v2: CJPrintN imported; PrintNumberSpec's item block at .record "cJSON"
```diff
@@ -1,9 +1,14 @@
 import CIR
 import CIR.Logic.CJTree
-import VerifOrch.Cir.CJPrint
+import VerifOrch.Cir.CJPrintN
 import Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 
 /-!
+  PrintSpecsN (for cirlean `next` e6ac99a; draft by cirlean for veriforch's review): this file (v4, sha256
+  d2324d0a…) with `import VerifOrch.Cir.CJPrintN` instead of `VerifOrch.Cir.CJPrint`, i.e. `CJ.printable` also
+  fixes every item's block type to `.record "cJSON"`; no statement in this file changed.
+  PrintSpecsN v2: `PrintNumberSpec` takes the item block at `.record "cJSON"` instead of a free `rt` (its
+  `item->valuedouble` load is a member load, undefined under type-punning UB for another block type); nothing else.
   FH (the full cjson_read_fuzzer, cJSON 1.7.18 @ acc76239, Theorem's build): statements for the print and minify
   side. v2 (FH lead worker-cjson-2), from worker-cjson-0's draft v1 (sha256 5c47e4e7…) by three edits, frozen by sha:
   (1) `PrintNumberSpec` takes the item block at any type `rt` (`CJForest` stores item `j` at `ts[j].rt`, and
@@ -141,12 +146,12 @@
       PBOK m' pb pre kb fmt (ptrBlock buf) m.next ∧
       (r = some (.int 1) → PBDone m m' pb pre kb (ptrBlock buf) off off d fmt))
 
-/-- `cJSON$print_number` on an item record (at any block type `rt`) whose `valueint` is an int32 and `valuedouble`
+/-- `cJSON$print_number` on an item record (a `struct cJSON` block, as CJ.printable now fixes every item) whose `valueint` is an int32 and `valuedouble`
 a double: the number and a NUL at the offset, the offset moved to that NUL. -/
-def PrintNumberSpec : Prop := ∀ (ib : Nat) (ki : BlockKind) (rt : Ty) (fs : List Val) (i : Int) (x : Float) (pb : Nat)
+def PrintNumberSpec : Prop := ∀ (ib : Nat) (ki : BlockKind) (fs : List Val) (i : Int) (x : Float) (pb : Nat)
     (pre : List PathElem) (kb : BlockKind) (buf : Ptr) (len off d : Nat) (fmt : Int) (vs : List Val) (m : Mem),
     m.WF → Module.RoGlobals module m → ib < m.next → ib ≠ pb → ib ≠ ptrBlock buf →
-    m.blocks ib = some ⟨ki, true, rt, .agg fs⟩ → fs.length = 8 →
+    m.blocks ib = some ⟨ki, true, .record "cJSON", .agg fs⟩ → fs.length = 8 →
     fs[5]? = some (.int i) → -2147483648 ≤ i → i ≤ 2147483647 → fs[6]? = some (.float x) →
     pb < m.next → ptrBlock buf < m.next → pb ≠ ptrBlock buf →
     PBObj m pb pre kb buf len off d fmt → PBData m buf len vs → off < len → len < 2147483648 →
```

## 3. CycleSpecsP2 -> CycleSpecsP2N v3: CJPrintN imported; h_bsw and h_ps type the input buffer; h_new takes hpun; h_del, DeleteSpecTheirsP and h_del_of_theirsP take (N : Nat) (hpr : CJ.forestPrintable N ts)
```diff
@@ -1,9 +1,19 @@
 import CIR
 import CIR.Logic.CJTree
-import VerifOrch.Cir.CJPrint
+import VerifOrch.Cir.CJPrintN
 import Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 
 /-!
+  CycleSpecsP2N (for cirlean `next` e6ac99a; draft by cirlean for veriforch's review): CycleSpecsP2 (sha256
+  f3d742fc…) with `import VerifOrch.Cir.CJPrintN` instead of `VerifOrch.Cir.CJPrint`: the r = 1 posts'
+  `CJ.forestPrintable` now also fixes every child item's block type to `.record "cJSON"`. v2: in the
+  contracts `h_bsw` (buffer_skip_whitespace) and `h_ps` (parse_string) the input buffer's block type is
+  `.array (.int false 8) xs.length`, as in the steps' own `hcc`, instead of a free `tyc` (under type-punning UB
+  a byte load from a block of another type is undefined); nothing else changed. v3: the contract `h_new`
+  (cJSON_New_Item) also takes `hpun`, that loading the allocate hook (a function pointer at `hp`'s path ++ [.idx 0])
+  is not a type-punned access, and `h_del` (cJSON_Delete; also `DeleteSpecTheirsP` and `h_del_of_theirsP`) takes
+  `(N : Nat) (hpr : CJ.forestPrintable N ts)`, which gives every item's block type `.record "cJSON"` (cJSON_Delete
+  loads the members of every item); nothing else changed.
   FH (the full cjson_read_fuzzer, cJSON 1.7.18 @ acc76239, Theorem's build): the strengthened statements of
   cirlean's loop steps of the parser cycle, for the full-harness theorem. Derived from cirlean's
   `cycle_specs_20261025/CycleSpecs.lean` (sha256 ee49b7b5…) by exactly these edits, nothing else:
@@ -28,23 +38,23 @@
 /-- `parse_array_step`'s statement, strengthened for printing (FH). -/
 def ParseArrayStepSpecP : Prop := ∀ (k : Nat)
     (h_pv : ∀ (ib b bc base bg : Nat) (kb kc kg : BlockKind) (ga gr v0 v1 v2 v3 v4 v5 v6 v7 : Val) (xs : List Int) (len off depth : Nat) (m : Mem) (hwf : m.WF) (hgn : 10 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [ga, .ptr (.fn "free"), gr]⟩) (hib : ib < m.next) (hitem : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, v2, v3, v4, v5, v6, v7]⟩) (hv2 : v2 = .ptr .null) (hv4 : v4 = .ptr .null) (hv5 : ∃ i : Int, v5 = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) (hv6 : ∃ d : Float, v6 = .float d) (hb : b < m.next) (hkb : kb ≠ .readonly) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hdepth : depth ≤ 1000) (hd1 : ib ≠ b) (hd2 : ib ≠ bc) (hd3 : b ≠ bc) (hd4 : bg ≠ ib) (hd5 : bg ≠ b) (hd6 : bg ≠ bc), 2 * (1001 - depth) + 1 < k → Returns ctx fn_cJSON_parse_value.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' depth' : Nat, off ≤ off' ∧ off' ≤ len ∧ (r = some (.int 1) → depth' = depth) ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth', .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ (ty : Int) (vs : Option (Nat × Ty × Val)) (ch : List CJ) (vi vd : Val), m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, .ptr (listPtr (ch.map CJ.b) 0), .int ty, .ptr (ostr vs), vi, vd, v7]⟩ ∧ bitwise true 32 (· &&& ·) ty 256 = 0 ∧ bitwise true 32 (· &&& ·) ty 512 = 0 ∧ -2147483648 ≤ ty ∧ ty ≤ 2147483647 ∧ (vs.isSome = true → m'.blocks (oblk vs) = some ⟨.heap, true, oty vs, oval vs⟩ ∧ m.next ≤ oblk vs ∧ oblk vs ∉ CJ.forestBlocks ch) ∧ CJForest m' ch ∧ (CJ.forestBlocks ch).Nodup ∧ (∀ x ∈ CJ.forestBlocks ch, m.next ≤ x ∧ x < m'.next) ∧ (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧ CStrOpt xs.length vs ∧ CJ.forestPrintable xs.length ch ∧ CJ.forestHeight ch ≤ 1000 - depth)))
-    (h_bsw : ∀ (b bc base : Nat) (kb kc : BlockKind) (tyc : Ty) (xs : List Int) (len off depth : Nat) (hooks : Val) (m : Mem) (hwf : m.WF) (hkb : kb ≠ .readonly) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, hooks]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, tyc, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc), Returns ctx fn_cJSON_buffer_skip_whitespace.sym [.ptr (.loc b [])] m (fun r m' => r = some (.ptr (.loc b [])) ∧ ∃ off' : Int, m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, hooks]⟩ ∧ off ≤ off' ∧ off' ≤ len ∧ (off < len → off' < len ∧ (∀ j : Nat, off ≤ j → j < off' → ∃ x, xs[base + j]? = some x ∧ x ≤ 32) ∧ (off' + 1 = len ∨ ∃ x, xs[base + off'.toNat]? = some x ∧ 32 < x)) ∧ Frame m m' [b] ∧ m'.WF))
-    (h_del : ∀ (ts : List CJ) (m : Mem) (gb : Nat) (gk : BlockKind) (hma hre : Val) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (hwf : m.WF) (hg : ctx.gaddr "cJSON$global_hooks" = some gb) (hgbn : gb < m.next) (hgb : m.blocks gb = some ⟨gk, true, .record "internal_hooks", .agg [hma, .ptr (.fn "free"), hre]⟩) (hgbf : gb ∉ CJ.forestBlocks ts), Returns ctx "cJSON_Delete" [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF))
-    (h_new : ∀ (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])), Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF))
+    (h_bsw : ∀ (b bc base : Nat) (kb kc : BlockKind) (xs : List Int) (len off depth : Nat) (hooks : Val) (m : Mem) (hwf : m.WF) (hkb : kb ≠ .readonly) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, hooks]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc), Returns ctx fn_cJSON_buffer_skip_whitespace.sym [.ptr (.loc b [])] m (fun r m' => r = some (.ptr (.loc b [])) ∧ ∃ off' : Int, m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, hooks]⟩ ∧ off ≤ off' ∧ off' ≤ len ∧ (off < len → off' < len ∧ (∀ j : Nat, off ≤ j → j < off' → ∃ x, xs[base + j]? = some x ∧ x ≤ 32) ∧ (off' + 1 = len ∨ ∃ x, xs[base + off'.toNat]? = some x ∧ 32 < x)) ∧ Frame m m' [b] ∧ m'.WF))
+    (h_del : ∀ (ts : List CJ) (m : Mem) (gb : Nat) (gk : BlockKind) (hma hre : Val) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hg : ctx.gaddr "cJSON$global_hooks" = some gb) (hgbn : gb < m.next) (hgb : m.blocks gb = some ⟨gk, true, .record "internal_hooks", .agg [hma, .ptr (.fn "free"), hre]⟩) (hgbf : gb ∉ CJ.forestBlocks ts), Returns ctx "cJSON_Delete" [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF))
+    (h_new : ∀ (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false), Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF))
     (ib b bc base bg : Nat) (kb kc kg : BlockKind) (ga gr v0 v1 v2 v3 v4 v5 v6 v7 : Val) (xs : List Int) (len off depth : Nat) (m : Mem) (hwf : m.WF) (hgn : 10 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [ga, .ptr (.fn "free"), gr]⟩) (hib : ib < m.next) (hitem : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, v2, v3, v4, v5, v6, v7]⟩) (hv2 : v2 = .ptr .null) (hv4 : v4 = .ptr .null) (hv5 : ∃ i : Int, v5 = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) (hv6 : ∃ d : Float, v6 = .float d) (hb : b < m.next) (hkb : kb ≠ .readonly) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off < len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hdepth : depth ≤ 1000) (hd1 : ib ≠ b) (hd2 : ib ≠ bc) (hd3 : b ≠ bc) (hd4 : bg ≠ ib) (hd5 : bg ≠ b) (hd6 : bg ≠ bc) (hk : 2 * (1001 - depth) = k), Returns ctx fn_cJSON_parse_array.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' depth' : Nat, off ≤ off' ∧ off' ≤ len ∧ (r = some (.int 1) → depth' = depth) ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth', .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ (ty : Int) (vs : Option (Nat × Ty × Val)) (ch : List CJ) (vi vd : Val), m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, .ptr (listPtr (ch.map CJ.b) 0), .int ty, .ptr (ostr vs), vi, vd, v7]⟩ ∧ bitwise true 32 (· &&& ·) ty 256 = 0 ∧ bitwise true 32 (· &&& ·) ty 512 = 0 ∧ -2147483648 ≤ ty ∧ ty ≤ 2147483647 ∧ (vs.isSome = true → m'.blocks (oblk vs) = some ⟨.heap, true, oty vs, oval vs⟩ ∧ m.next ≤ oblk vs ∧ oblk vs ∉ CJ.forestBlocks ch) ∧ CJForest m' ch ∧ (CJ.forestBlocks ch).Nodup ∧ (∀ x ∈ CJ.forestBlocks ch, m.next ≤ x ∧ x < m'.next) ∧ (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧ CStrOpt xs.length vs ∧ CJ.forestPrintable xs.length ch ∧ CJ.forestHeight ch ≤ 1000 - depth))
 
 /-- `parse_object_step`'s statement, strengthened for printing (FH). -/
 def ParseObjectStepSpecP : Prop := ∀ (k : Nat)
     (h_pv : ∀ (ib b bc base bg : Nat) (kb kc kg : BlockKind) (ga gr v0 v1 v2 v3 v4 v5 v6 v7 : Val) (xs : List Int) (len off depth : Nat) (m : Mem) (hwf : m.WF) (hgn : 10 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [ga, .ptr (.fn "free"), gr]⟩) (hib : ib < m.next) (hitem : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, v2, v3, v4, v5, v6, v7]⟩) (hv2 : v2 = .ptr .null) (hv4 : v4 = .ptr .null) (hv5 : ∃ i : Int, v5 = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) (hv6 : ∃ d : Float, v6 = .float d) (hb : b < m.next) (hkb : kb ≠ .readonly) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hdepth : depth ≤ 1000) (hd1 : ib ≠ b) (hd2 : ib ≠ bc) (hd3 : b ≠ bc) (hd4 : bg ≠ ib) (hd5 : bg ≠ b) (hd6 : bg ≠ bc), 2 * (1001 - depth) + 1 < k → Returns ctx fn_cJSON_parse_value.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' depth' : Nat, off ≤ off' ∧ off' ≤ len ∧ (r = some (.int 1) → depth' = depth) ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth', .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ (ty : Int) (vs : Option (Nat × Ty × Val)) (ch : List CJ) (vi vd : Val), m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, .ptr (listPtr (ch.map CJ.b) 0), .int ty, .ptr (ostr vs), vi, vd, v7]⟩ ∧ bitwise true 32 (· &&& ·) ty 256 = 0 ∧ bitwise true 32 (· &&& ·) ty 512 = 0 ∧ -2147483648 ≤ ty ∧ ty ≤ 2147483647 ∧ (vs.isSome = true → m'.blocks (oblk vs) = some ⟨.heap, true, oty vs, oval vs⟩ ∧ m.next ≤ oblk vs ∧ oblk vs ∉ CJ.forestBlocks ch) ∧ CJForest m' ch ∧ (CJ.forestBlocks ch).Nodup ∧ (∀ x ∈ CJ.forestBlocks ch, m.next ≤ x ∧ x < m'.next) ∧ (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧ CStrOpt xs.length vs ∧ CJ.forestPrintable xs.length ch ∧ CJ.forestHeight ch ≤ 1000 - depth)))
-    (h_bsw : ∀ (b bc base : Nat) (kb kc : BlockKind) (tyc : Ty) (xs : List Int) (len off depth : Nat) (hooks : Val) (m : Mem) (hwf : m.WF) (hkb : kb ≠ .readonly) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, hooks]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, tyc, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc), Returns ctx fn_cJSON_buffer_skip_whitespace.sym [.ptr (.loc b [])] m (fun r m' => r = some (.ptr (.loc b [])) ∧ ∃ off' : Int, m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, hooks]⟩ ∧ off ≤ off' ∧ off' ≤ len ∧ (off < len → off' < len ∧ (∀ j : Nat, off ≤ j → j < off' → ∃ x, xs[base + j]? = some x ∧ x ≤ 32) ∧ (off' + 1 = len ∨ ∃ x, xs[base + off'.toNat]? = some x ∧ 32 < x)) ∧ Frame m m' [b] ∧ m'.WF))
-    (h_del : ∀ (ts : List CJ) (m : Mem) (gb : Nat) (gk : BlockKind) (hma hre : Val) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (hwf : m.WF) (hg : ctx.gaddr "cJSON$global_hooks" = some gb) (hgbn : gb < m.next) (hgb : m.blocks gb = some ⟨gk, true, .record "internal_hooks", .agg [hma, .ptr (.fn "free"), hre]⟩) (hgbf : gb ∉ CJ.forestBlocks ts), Returns ctx "cJSON_Delete" [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF))
-    (h_new : ∀ (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])), Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF))
-    (h_ps : ∀ (ib : Nat) (iv : List Val) (b bc : Nat) (kb kc : BlockKind) (tyc : Ty) (xs : List Int) (base len off depth : Nat) (m : Mem) (hkb : kb ≠ .readonly) (hib : ib < m.next) (hiv : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg iv⟩) (hivl : iv.length = 8) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, tyc, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off < len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc) (hbi : b ≠ ib) (hci : bc ≠ ib) (hwf : m.WF), Returns ctx fn_cJSON_parse_string.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m.next ≤ m'.next ∧ m'.WF ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' : Nat, off < off' ∧ off' ≤ len ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ ob n ys, m.next ≤ ob ∧ ob < m'.next ∧ m'.blocks ob = some ⟨.heap, true, .array (.int false 8) n, .arr ys⟩ ∧ CStrVal xs.length (.array (.int false 8) n) (.arr ys) ∧ m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg ((iv.set 3 (.int 16)).set 4 (.ptr (.loc ob [.idx 0])))⟩)))
+    (h_bsw : ∀ (b bc base : Nat) (kb kc : BlockKind) (xs : List Int) (len off depth : Nat) (hooks : Val) (m : Mem) (hwf : m.WF) (hkb : kb ≠ .readonly) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, hooks]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc), Returns ctx fn_cJSON_buffer_skip_whitespace.sym [.ptr (.loc b [])] m (fun r m' => r = some (.ptr (.loc b [])) ∧ ∃ off' : Int, m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, hooks]⟩ ∧ off ≤ off' ∧ off' ≤ len ∧ (off < len → off' < len ∧ (∀ j : Nat, off ≤ j → j < off' → ∃ x, xs[base + j]? = some x ∧ x ≤ 32) ∧ (off' + 1 = len ∨ ∃ x, xs[base + off'.toNat]? = some x ∧ 32 < x)) ∧ Frame m m' [b] ∧ m'.WF))
+    (h_del : ∀ (ts : List CJ) (m : Mem) (gb : Nat) (gk : BlockKind) (hma hre : Val) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hg : ctx.gaddr "cJSON$global_hooks" = some gb) (hgbn : gb < m.next) (hgb : m.blocks gb = some ⟨gk, true, .record "internal_hooks", .agg [hma, .ptr (.fn "free"), hre]⟩) (hgbf : gb ∉ CJ.forestBlocks ts), Returns ctx "cJSON_Delete" [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF))
+    (h_new : ∀ (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false), Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF))
+    (h_ps : ∀ (ib : Nat) (iv : List Val) (b bc : Nat) (kb kc : BlockKind) (xs : List Int) (base len off depth : Nat) (m : Mem) (hkb : kb ≠ .readonly) (hib : ib < m.next) (hiv : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg iv⟩) (hivl : iv.length = 8) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off < len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc) (hbi : b ≠ ib) (hci : bc ≠ ib) (hwf : m.WF), Returns ctx fn_cJSON_parse_string.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m.next ≤ m'.next ∧ m'.WF ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' : Nat, off < off' ∧ off' ≤ len ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ ob n ys, m.next ≤ ob ∧ ob < m'.next ∧ m'.blocks ob = some ⟨.heap, true, .array (.int false 8) n, .arr ys⟩ ∧ CStrVal xs.length (.array (.int false 8) n) (.arr ys) ∧ m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg ((iv.set 3 (.int 16)).set 4 (.ptr (.loc ob [.idx 0])))⟩)))
     (ib b bc base bg : Nat) (kb kc kg : BlockKind) (ga gr v0 v1 v2 v3 v4 v5 v6 v7 : Val) (xs : List Int) (len off depth : Nat) (m : Mem) (hwf : m.WF) (hgn : 10 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [ga, .ptr (.fn "free"), gr]⟩) (hib : ib < m.next) (hitem : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, v2, v3, v4, v5, v6, v7]⟩) (hv2 : v2 = .ptr .null) (hv4 : v4 = .ptr .null) (hv5 : ∃ i : Int, v5 = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) (hv6 : ∃ d : Float, v6 = .float d) (hb : b < m.next) (hkb : kb ≠ .readonly) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hdepth : depth ≤ 1000) (hd1 : ib ≠ b) (hd2 : ib ≠ bc) (hd3 : b ≠ bc) (hd4 : bg ≠ ib) (hd5 : bg ≠ b) (hd6 : bg ≠ bc) (hk : 2 * (1001 - depth) = k), Returns ctx fn_cJSON_parse_object.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' depth' : Nat, off ≤ off' ∧ off' ≤ len ∧ (r = some (.int 1) → depth' = depth) ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth', .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ (ty : Int) (vs : Option (Nat × Ty × Val)) (ch : List CJ) (vi vd : Val), m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, .ptr (listPtr (ch.map CJ.b) 0), .int ty, .ptr (ostr vs), vi, vd, v7]⟩ ∧ bitwise true 32 (· &&& ·) ty 256 = 0 ∧ bitwise true 32 (· &&& ·) ty 512 = 0 ∧ -2147483648 ≤ ty ∧ ty ≤ 2147483647 ∧ (vs.isSome = true → m'.blocks (oblk vs) = some ⟨.heap, true, oty vs, oval vs⟩ ∧ m.next ≤ oblk vs ∧ oblk vs ∉ CJ.forestBlocks ch) ∧ CJForest m' ch ∧ (CJ.forestBlocks ch).Nodup ∧ (∀ x ∈ CJ.forestBlocks ch, m.next ≤ x ∧ x < m'.next) ∧ (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧ CStrOpt xs.length vs ∧ CJ.forestPrintable xs.length ch ∧ CJ.forestHeight ch ≤ 1000 - depth))
 
 /-- veriforch's cJSON_Delete contract (given list, `CJReal.delete_forest`). -/
-def DeleteSpecTheirsP : Prop := ∀ (bg : Nat) (kg : BlockKind) (a r : Val) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (ts : List CJ) (m : Mem) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (hwf : m.WF) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [a, .ptr (.fn "free"), r]⟩) (hgn : bg ∉ CJ.forestBlocks ts), Returns ctx fn_cJSON_Delete.sym [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF)
+def DeleteSpecTheirsP : Prop := ∀ (bg : Nat) (kg : BlockKind) (a r : Val) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (ts : List CJ) (m : Mem) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [a, .ptr (.fn "free"), r]⟩) (hgn : bg ∉ CJ.forestBlocks ts), Returns ctx fn_cJSON_Delete.sym [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF)
 
 /-- The `h_del` hypothesis of both steps, from veriforch's cJSON_Delete contract. -/
-theorem h_del_of_theirsP (del : DeleteSpecTheirsP) : ∀ (ts : List CJ) (m : Mem) (gb : Nat) (gk : BlockKind) (hma hre : Val) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (hwf : m.WF) (hg : ctx.gaddr "cJSON$global_hooks" = some gb) (hgbn : gb < m.next) (hgb : m.blocks gb = some ⟨gk, true, .record "internal_hooks", .agg [hma, .ptr (.fn "free"), hre]⟩) (hgbf : gb ∉ CJ.forestBlocks ts), Returns ctx "cJSON_Delete" [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF) :=
-  fun ts m gb gk hma hre hf hnd hwf hg hgbn hgb hgbf => del gb gk hma hre hg ts m hf hnd hwf hgbn hgb hgbf
+theorem h_del_of_theirsP (del : DeleteSpecTheirsP) : ∀ (ts : List CJ) (m : Mem) (gb : Nat) (gk : BlockKind) (hma hre : Val) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hg : ctx.gaddr "cJSON$global_hooks" = some gb) (hgbn : gb < m.next) (hgb : m.blocks gb = some ⟨gk, true, .record "internal_hooks", .agg [hma, .ptr (.fn "free"), hre]⟩) (hgbf : gb ∉ CJ.forestBlocks ts), Returns ctx "cJSON_Delete" [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF) :=
+  fun ts m gb gk hma hre hf hnd N hpr hwf hg hgbn hgb hgbf => del gb gk hma hre hg ts m hf hnd N hpr hwf hgbn hgb hgbf
```

---

## 4. Per-Unit Theorem Statement Comparison Across All 32 Units (`c4ef58d` vs `e6ac99a`)

Out of the 32 units in the `fuzzing_cjson_read_fuzzer` closure:
- **13 units have zero statement or definition change** (including the top-level entry point `LLVMFuzzerTestOneInput_spec`):
  1. `LLVMFuzzerTestOneInput_spec` (entry theorem — byte-for-byte identical statement and `VerifOrch.Cir.Entry` definitions)
  2. `cJSON_skip_utf8_bom_spec`
  3. `cJSON_get_decimal_point_spec`
  4. `cJSON_compare_double_spec`
  5. `cJSON_parse_number_spec`
  6. `cJSON_skip_oneline_comment_spec`
  7. `cJSON_skip_multiline_comment_spec`
  8. `cJSON_minify_string_spec`
  9. `cJSON_Minify_spec`
  10. `cJSON_ensure_spec`
  11. `cJSON_update_offset_spec`
  12. `cJSON_print_string_ptr_spec`
- **11 units have zero text change in their `theorem ..._spec` signature**, and inherit `rt = .record "cJSON"` through `VerifOrch.Cir.CJPrintN` (`CJ.printable` / `CJ.forestPrintable`, and `FH.PrintPre` in `VerifOrch.Cir.PrintSpecsN`):
  13. `cJSON_parse_array_spec` (`scc_cJSON_parse_array.lean`)
  14. `cJSON_parse_object_spec` (`scc_cJSON_parse_array.lean`)
  15. `cJSON_parse_value_spec` (`scc_cJSON_parse_array.lean`)
  16. `cJSON_ParseWithLengthOpts_spec`
  17. `cJSON_ParseWithOpts_spec`
  18. `cJSON_print_array_spec` (`scc_cJSON_print_array.lean`)
  19. `cJSON_print_object_spec` (`scc_cJSON_print_array.lean`)
  20. `cJSON_print_value_spec` (`scc_cJSON_print_array.lean`)
  21. `cJSON_print_spec`
  22. `cJSON_Print_spec`
  23. `cJSON_PrintBuffered_spec`
  24. `cJSON_PrintUnformatted_spec`
- **8 units have explicit signature restatements** to specify the concrete block type required by `cirlean` `2d65713` (`punning2`, where `Mem.punnedAccess` checks `blk.ty.atPath path`):
  25. `cJSON_Delete_spec`: adds `(N : Nat) (hpr : CJ.forestPrintable N ts)` so every item block in `ts` has `rt = .record "cJSON"`.
  26. `cJSON_print_number_spec`: replaces free `(rt : Ty)` with `.record "cJSON"` on item block `ib`.
  27. `cJSON_print_string_spec`: replaces free `(rt : Ty)` with `.record "cJSON"` on item block `ib`.
  28. `cJSON_buffer_skip_whitespace_spec`: replaces free `(tyc : Ty)` with `.array (.int false 8) xs.length` on input buffer block `bc`.
  29. `cJSON_parse_string_spec`: replaces free `(tyc : Ty)` with `.array (.int false 8) xs.length` on input buffer block `bc`.
  30. `cJSON_parse_hex4_spec`: replaces free `(ty : Ty)` with `.array (.int false 8) xs.length` on input buffer block `b`.
  31. `cJSON_utf16_literal_to_utf8_spec`: replaces free `(tyc tyo tp : Ty)` with `.array (.int false 8) xs.length` on `bc`, `.array (.int false 8) ys.length` on `bo`, and `.ptr (.int false 8)` on `bp`.
  32. `cJSON_cJSON_New_Item_spec`: adds `(hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false)` for reading the `allocate` function pointer at `.idx 0` of `hooks`.

### Unified Diffs of the 8 Textually Restated Unit Theorem Files (`c4ef58d` vs `e6ac99a`)

#### `cJSON_Delete.lean`
```diff
--- <ROOT>/veriforch/runs/cjson_full/lean_c4ef58d/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_Delete.lean	2026-10-26 03:35:04.449310354 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_Delete.lean	2026-10-27 05:55:56.500314807 +0000
@@ -1,7 +1,8 @@
 import CIR
 import Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 import CIR.Logic.CJTree
-import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_Delete_given
+import VerifOrch.Cir.CJPrintN
+import cJSON_Delete_fuzz_harness
 
 open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 
@@ -10,9 +11,9 @@
 namespace VO.v0.fuzzing_cjson_read_fuzzer
 
 @[cir_spec]
-theorem cJSON_Delete_spec (bg : Nat) (kg : BlockKind) (a r : Val) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (ts : List CJ) (m : Mem) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (hwf : m.WF) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [a, .ptr (.fn "free"), r]⟩) (hgn : bg ∉ CJ.forestBlocks ts) :
+theorem cJSON_Delete_spec (bg : Nat) (kg : BlockKind) (a r : Val) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (ts : List CJ) (m : Mem) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [a, .ptr (.fn "free"), r]⟩) (hgn : bg ∉ CJ.forestBlocks ts) :
     Returns ctx fn_cJSON_Delete.sym [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF) := by
-  exact CJReal.delete_forest bg kg a r hg ts m hf hnd hwf hbg hgv hgn
+  exact CJReal.delete_forest bg kg a r hg ts m hf hnd N hpr hwf hbg hgv hgn
 
 #print axioms cJSON_Delete_spec
 
```

#### `cJSON_print_number.lean`
```diff
--- <ROOT>/veriforch/runs/cjson_full/lean_c4ef58d/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_print_number.lean	2026-10-26 04:13:35.143234778 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_print_number.lean	2026-10-27 05:55:56.521314799 +0000
@@ -1,12 +1,12 @@
 import CIR
 import Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 import CIR.Logic.CJTree
-import VerifOrch.Cir.CJPrint
-import VerifOrch.Cir.PrintSpecs
+import VerifOrch.Cir.CJPrintN
+import VerifOrch.Cir.PrintSpecsN
 import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_get_decimal_point
 import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_compare_double
 import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_ensure
-import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_print_number_given
+import print_number_okN
 
 open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 
@@ -16,9 +16,9 @@
 
 set_option cir.inline false in
 @[cir_spec]
-theorem cJSON_print_number_spec (ib : Nat) (ki : BlockKind) (rt : Ty) (fs : List Val) (i : Int) (x : Float) (pb : Nat) (pre : List PathElem) (kb : BlockKind) (buf : Ptr) (len off d : Nat) (fmt : Int) (vs : List Val) (m : Mem) (h1 : m.WF) (h2 : Module.RoGlobals module m) (h3 : ib < m.next) (h4 : ib ≠ pb) (h5 : ib ≠ FH.ptrBlock buf) (h6 : m.blocks ib = some ⟨ki, true, rt, .agg fs⟩) (h7 : fs.length = 8) (h8 : fs[5]? = some (.int i)) (h9 : -2147483648 ≤ i) (h10 : i ≤ 2147483647) (h11 : fs[6]? = some (.float x)) (h12 : pb < m.next) (h13 : FH.ptrBlock buf < m.next) (h14 : pb ≠ FH.ptrBlock buf) (h15 : FH.PBObj m pb pre kb buf len off d fmt) (h16 : FH.PBData m buf len vs) (h17 : off < len) (h18 : len < 2147483648) :
+theorem cJSON_print_number_spec (ib : Nat) (ki : BlockKind) (fs : List Val) (i : Int) (x : Float) (pb : Nat) (pre : List PathElem) (kb : BlockKind) (buf : Ptr) (len off d : Nat) (fmt : Int) (vs : List Val) (m : Mem) (h1 : m.WF) (h2 : Module.RoGlobals module m) (h3 : ib < m.next) (h4 : ib ≠ pb) (h5 : ib ≠ FH.ptrBlock buf) (h6 : m.blocks ib = some ⟨ki, true, .record "cJSON", .agg fs⟩) (h7 : fs.length = 8) (h8 : fs[5]? = some (.int i)) (h9 : -2147483648 ≤ i) (h10 : i ≤ 2147483647) (h11 : fs[6]? = some (.float x)) (h12 : pb < m.next) (h13 : FH.ptrBlock buf < m.next) (h14 : pb ≠ FH.ptrBlock buf) (h15 : FH.PBObj m pb pre kb buf len off d fmt) (h16 : FH.PBData m buf len vs) (h17 : off < len) (h18 : len < 2147483648) :
     Returns ctx fn_cJSON_print_number.sym [.ptr (.loc ib []), .ptr (.loc pb pre)] m (fun r m' => FH.PBFrame m m' pb (FH.ptrBlock buf) ∧ (r = some (.int 0) ∨ r = some (.int 1)) ∧ FH.PBOK m' pb pre kb fmt (FH.ptrBlock buf) m.next ∧ (r = some (.int 1) → ∃ off', FH.PBDone m m' pb pre kb (FH.ptrBlock buf) off off' d fmt)) := by
-  exact print_number_ok cJSON_ensure_spec cJSON_get_decimal_point_spec cJSON_compare_double_spec ib ki rt fs i x pb pre kb buf len off d fmt vs m h1 h2 h3 h4 h5 h6 h7 h8 h9 h10 h11 h12 h13 h14 h15 h16 h17 h18
+  exact print_number_ok cJSON_ensure_spec cJSON_get_decimal_point_spec cJSON_compare_double_spec ib ki fs i x pb pre kb buf len off d fmt vs m h1 h2 h3 h4 h5 h6 h7 h8 h9 h10 h11 h12 h13 h14 h15 h16 h17 h18
 
 #print axioms cJSON_print_number_spec
 
```

#### `cJSON_print_string.lean`
```diff
--- <ROOT>/veriforch/runs/cjson_full/lean_c4ef58d/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_print_string.lean	2026-10-26 04:13:37.464035139 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_print_string.lean	2026-10-27 05:55:56.519314800 +0000
@@ -1,9 +1,9 @@
 import CIR
 import Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 import CIR.Logic.CJTree
-import VerifOrch.Cir.CJPrint
-import VerifOrch.Cir.PrintSpecs
-import VerifOrch.Cir.PrintLemmas
+import VerifOrch.Cir.CJPrintN
+import VerifOrch.Cir.PrintSpecsN
+import VerifOrch.Cir.PrintLemmasN
 import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_print_string_ptr
 
 open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit
@@ -15,10 +15,10 @@
 set_option cir.inline false in
 set_option maxHeartbeats 400000000 in
 @[cir_spec]
-theorem cJSON_print_string_spec (N ib : Nat) (ki : BlockKind) (rt : Ty) (fs : List Val) (sp : Ptr) (pb : Nat) (pre : List PathElem) (kb : BlockKind) (buf : Ptr) (len off d : Nat) (fmt : Int) (vs : List Val) (m : Mem) (hwf : m.WF) (hro : Module.RoGlobals module m) (hN : N < 2305843009213693952) (hstr : FH.StrArg m N sp pb (FH.ptrBlock buf)) (hib : ib < m.next) (hibpb : ib ≠ pb) (hibb : ib ≠ FH.ptrBlock buf) (hitem : m.blocks ib = some ⟨ki, true, rt, .agg fs⟩) (hfs4 : fs[4]? = some (.ptr sp)) (hpb : pb < m.next) (hbuf : FH.ptrBlock buf < m.next) (hpbbuf : pb ≠ FH.ptrBlock buf) (hobj : FH.PBObj m pb pre kb buf len off d fmt) (hdata : FH.PBData m buf len vs) (hoff : off < len) (hlen : len < 2147483648) :
+theorem cJSON_print_string_spec (N ib : Nat) (ki : BlockKind) (fs : List Val) (sp : Ptr) (pb : Nat) (pre : List PathElem) (kb : BlockKind) (buf : Ptr) (len off d : Nat) (fmt : Int) (vs : List Val) (m : Mem) (hwf : m.WF) (hro : Module.RoGlobals module m) (hN : N < 2305843009213693952) (hstr : FH.StrArg m N sp pb (FH.ptrBlock buf)) (hib : ib < m.next) (hibpb : ib ≠ pb) (hibb : ib ≠ FH.ptrBlock buf) (hitem : m.blocks ib = some ⟨ki, true, .record "cJSON", .agg fs⟩) (hfs4 : fs[4]? = some (.ptr sp)) (hpb : pb < m.next) (hbuf : FH.ptrBlock buf < m.next) (hpbbuf : pb ≠ FH.ptrBlock buf) (hobj : FH.PBObj m pb pre kb buf len off d fmt) (hdata : FH.PBData m buf len vs) (hoff : off < len) (hlen : len < 2147483648) :
     Returns ctx fn_cJSON_print_string.sym [.ptr (.loc ib []), .ptr (.loc pb pre)] m (fun r m' => FH.PBFrame m m' pb (FH.ptrBlock buf) ∧ (r = some (.int 0) ∨ r = some (.int 1)) ∧ FH.PBOK m' pb pre kb fmt (FH.ptrBlock buf) m.next ∧ (r = some (.int 1) → FH.PBDone m m' pb pre kb (FH.ptrBlock buf) off off d fmt)) := by
   have h_cJSON_print_string_ptr := cJSON_print_string_ptr_spec
-  exact FH.print_string_ok h_cJSON_print_string_ptr N ib ki rt fs sp pb pre kb buf len off d fmt vs m hwf hro hN hstr hib hibpb hibb hitem
+  exact FH.print_string_ok h_cJSON_print_string_ptr N ib ki fs sp pb pre kb buf len off d fmt vs m hwf hro hN hstr hib hibpb hibb hitem
     hfs4 hpb hbuf hpbbuf hobj hdata hoff hlen
 
 #print axioms cJSON_print_string_spec
```

#### `cJSON_buffer_skip_whitespace.lean`
```diff
--- <ROOT>/veriforch/runs/cjson_full/lean_c4ef58d/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_buffer_skip_whitespace.lean	2026-10-26 03:25:12.841173817 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_buffer_skip_whitespace.lean	2026-10-27 03:19:57.097215812 +0000
@@ -10,7 +10,7 @@
 set_option cir.loopWF true in
 set_option maxHeartbeats 40000000 in
 @[cir_spec]
-theorem cJSON_buffer_skip_whitespace_spec (b bc base : Nat) (kb kc : BlockKind) (tyc : Ty) (xs : List Int) (len off depth : Nat) (hooks : Val) (m : Mem) (hwf : m.WF) (hkb : kb ≠ .readonly) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, hooks]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, tyc, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc) :
+theorem cJSON_buffer_skip_whitespace_spec (b bc base : Nat) (kb kc : BlockKind) (xs : List Int) (len off depth : Nat) (hooks : Val) (m : Mem) (hwf : m.WF) (hkb : kb ≠ .readonly) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, hooks]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc) :
     Returns ctx fn_cJSON_buffer_skip_whitespace.sym [.ptr (.loc b [])] m (fun r m' => r = some (.ptr (.loc b [])) ∧ ∃ off' : Int, m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, hooks]⟩ ∧ off ≤ off' ∧ off' ≤ len ∧ (off < len → off' < len ∧ (∀ j : Nat, off ≤ j → j < off' → ∃ x, xs[base + j]? = some x ∧ x ≤ 32) ∧ (off' + 1 = len ∨ ∃ x, xs[base + off'.toNat]? = some x ∧ 32 < x)) ∧ Frame m m' [b] ∧ m'.WF) := by
   cir_start
   cir_vcg
```

#### `cJSON_parse_string.lean`
```diff
--- <ROOT>/veriforch/runs/cjson_full/lean_c4ef58d/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_parse_string.lean	2026-10-26 04:36:44.415902393 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_parse_string.lean	2026-10-27 06:14:11.761886184 +0000
@@ -1,9 +1,9 @@
 import CIR
 import Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 import CIR.Logic.CJString
-import VerifOrch.Cir.CJPrint
-import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_utf16_literal_to_utf8
-import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_parse_string_given
+import VerifOrch.Cir.CJPrintN
+import VO.v0.fuzzing_cjson_read_fuzzer.cJSON_parse_hex4
+import PSF2
 
 open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit
 
@@ -13,9 +13,9 @@
 
 set_option cir.inline false in
 @[cir_spec]
-theorem cJSON_parse_string_spec (ib : Nat) (iv : List Val) (b bc : Nat) (kb kc : BlockKind) (tyc : Ty) (xs : List Int) (base len off depth : Nat) (m : Mem) (hkb : kb ≠ .readonly) (hib : ib < m.next) (hiv : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg iv⟩) (hivl : iv.length = 8) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, tyc, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off < len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc) (hbi : b ≠ ib) (hci : bc ≠ ib) (hwf : m.WF) :
+theorem cJSON_parse_string_spec (ib : Nat) (iv : List Val) (b bc : Nat) (kb kc : BlockKind) (xs : List Int) (base len off depth : Nat) (m : Mem) (hkb : kb ≠ .readonly) (hib : ib < m.next) (hiv : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg iv⟩) (hivl : iv.length = 8) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off < len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc) (hbi : b ≠ ib) (hci : bc ≠ ib) (hwf : m.WF) :
     Returns ctx fn_cJSON_parse_string.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m.next ≤ m'.next ∧ m'.WF ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' : Nat, off < off' ∧ off' ≤ len ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ ob n ys, m.next ≤ ob ∧ ob < m'.next ∧ m'.blocks ob = some ⟨.heap, true, .array (.int false 8) n, .arr ys⟩ ∧ CStrVal xs.length (.array (.int false 8) n) (.arr ys) ∧ m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg ((iv.set 3 (.int 16)).set 4 (.ptr (.loc ob [.idx 0])))⟩)) := by
-  exact parse_string_strong cJSON_parse_hex4_spec ib iv b bc kb kc tyc xs base len off depth m hkb hib hiv hivl hb hbb hc hcc hlen hoff h63 hxs hbc hbi hci hwf
+  exact parse_string_strong cJSON_parse_hex4_spec ib iv b bc kb kc xs base len off depth m hkb hib hiv hivl hb hbb hc hcc hlen hoff h63 hxs hbc hbi hci hwf
 
 #print axioms cJSON_parse_string_spec
 
```

#### `cJSON_parse_hex4.lean`
```diff
--- <ROOT>/veriforch/runs/cjson_full/lean_c4ef58d/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_parse_hex4.lean	2026-10-26 03:25:32.680451038 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_parse_hex4.lean	2026-10-27 03:19:57.100679036 +0000
@@ -10,7 +10,7 @@
 set_option maxHeartbeats 200000000 in
 set_option cir.loopWF true in
 @[cir_spec]
-theorem cJSON_parse_hex4_spec (b i0 : Nat) (xs : List Int) (k : BlockKind) (ty : Ty) (m : Mem) (hwf : m.WF) (hb : b < m.next) (ha : m.blocks b = some ⟨k, true, ty, .arr (xs.map .int)⟩) (hn : i0 + 4 ≤ xs.length) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) :
+theorem cJSON_parse_hex4_spec (b i0 : Nat) (xs : List Int) (k : BlockKind) (m : Mem) (hwf : m.WF) (hb : b < m.next) (ha : m.blocks b = some ⟨k, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hn : i0 + 4 ≤ xs.length) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) :
     Returns ctx fn_cJSON_parse_hex4.sym [.ptr (.loc b [.idx i0])] m (fun r m' => (∃ h : Nat, r = some (.int h) ∧ h < 65536) ∧ Frame m m' [] ∧ m'.WF) := by
   cir_start
   cir_vcg
```

#### `cJSON_utf16_literal_to_utf8.lean`
```diff
--- <ROOT>/veriforch/runs/cjson_full/lean_c4ef58d/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_utf16_literal_to_utf8.lean	2026-10-26 03:48:32.512907542 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_utf16_literal_to_utf8.lean	2026-10-27 03:19:57.104206065 +0000
@@ -11,14 +11,14 @@
 set_option cir.inline false in
 set_option maxHeartbeats 40000000 in
 @[cir_spec]
-theorem cJSON_utf16_literal_to_utf8_spec (bc bo bp i e o : Nat) (xs : List Int) (ys : List Val) (kc ko kp : BlockKind) (tyc tyo tp : Ty) (m : Mem) (hwf : m.WF) (hbc : bc < m.next) (hc : m.blocks bc = some ⟨kc, true, tyc, .arr (xs.map .int)⟩) (hie : i ≤ e) (hex : e ≤ xs.length) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbo : bo < m.next) (ho : m.blocks bo = some ⟨ko, true, tyo, .arr ys⟩) (hko : ko ≠ .readonly) (hoy : e < i + 6 ∨ o + 4 ≤ ys.length) (hy63 : ys.length < 2 ^ 63) (hbp : bp < m.next) (hp : m.blocks bp = some ⟨kp, true, tp, .ptr (.loc bo [.idx o])⟩) (hkp : kp ≠ .readonly) (hd1 : bc ≠ bo) (hd2 : bp ≠ bo) (hd3 : bp ≠ bc) :
-    Returns ctx fn_cJSON_utf16_literal_to_utf8.sym [.ptr (.loc bc [.idx i]), .ptr (.loc bc [.idx e]), .ptr (.loc bp [])] m (fun r m' => ∃ o' : Nat, m'.blocks bp = some ⟨kp, true, tp, .ptr (.loc bo [.idx o'])⟩ ∧ ∃ sl : Int, r = some (.int sl) ∧ (sl = 0 ∨ sl = 6 ∨ sl = 12) ∧ (sl ≠ 0 → (i : Int) + sl ≤ e) ∧ (sl = 0 → o' = o) ∧ (sl ≠ 0 → o < o') ∧ o' ≤ o + 4 ∧ (sl = 6 → o' ≤ o + 3) ∧ (sl = 12 → ∃ k : Nat, xs[k]? = some 92 ∧ k = i + 6) ∧ (∃ ys' : List Val, m'.blocks bo = some ⟨ko, true, tyo, .arr ys'⟩ ∧ ys'.length = ys.length) ∧ Frame m m' [bo, bp] ∧ m'.WF) := by
+theorem cJSON_utf16_literal_to_utf8_spec (bc bo bp i e o : Nat) (xs : List Int) (ys : List Val) (kc ko kp : BlockKind) (m : Mem) (hwf : m.WF) (hbc : bc < m.next) (hc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hie : i ≤ e) (hex : e ≤ xs.length) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbo : bo < m.next) (ho : m.blocks bo = some ⟨ko, true, .array (.int false 8) ys.length, .arr ys⟩) (hko : ko ≠ .readonly) (hoy : e < i + 6 ∨ o + 4 ≤ ys.length) (hy63 : ys.length < 2 ^ 63) (hbp : bp < m.next) (hp : m.blocks bp = some ⟨kp, true, .ptr (.int false 8), .ptr (.loc bo [.idx o])⟩) (hkp : kp ≠ .readonly) (hd1 : bc ≠ bo) (hd2 : bp ≠ bo) (hd3 : bp ≠ bc) :
+    Returns ctx fn_cJSON_utf16_literal_to_utf8.sym [.ptr (.loc bc [.idx i]), .ptr (.loc bc [.idx e]), .ptr (.loc bp [])] m (fun r m' => ∃ o' : Nat, m'.blocks bp = some ⟨kp, true, .ptr (.int false 8), .ptr (.loc bo [.idx o'])⟩ ∧ ∃ sl : Int, r = some (.int sl) ∧ (sl = 0 ∨ sl = 6 ∨ sl = 12) ∧ (sl ≠ 0 → (i : Int) + sl ≤ e) ∧ (sl = 0 → o' = o) ∧ (sl ≠ 0 → o < o') ∧ o' ≤ o + 4 ∧ (sl = 6 → o' ≤ o + 3) ∧ (sl = 12 → ∃ k : Nat, xs[k]? = some 92 ∧ k = i + 6) ∧ (∃ ys' : List Val, m'.blocks bo = some ⟨ko, true, .array (.int false 8) ys.length, .arr ys'⟩ ∧ ys'.length = ys.length) ∧ Frame m m' [bo, bp] ∧ m'.WF) := by
   cir_start
   cir_vcg
   all_goals (try ((repeat (first | (refine Mem.WF_killRange ?_) | (refine Mem.WF_upd ?_ (by (try cir_strip_mdata); omega) _))); first | assumption | exact Mem.WF_mono hwf (by omega) | cir_wf))
   all_goals (try (cir_loop (fun (utf8_position codepoint : Nat) (mem : Mem) => utf8_position ≤ 3 ∧ o + 4 ≤ ys.length ∧
-        mem.blocks bp = some ⟨kp, true, tp, .ptr (.loc bo [.idx o])⟩ ∧
-        (∃ ys' : List Val, mem.blocks bo = some ⟨ko, true, tyo, .arr ys'⟩ ∧ ys'.length = ys.length) ∧
+        mem.blocks bp = some ⟨kp, true, .ptr (.int false 8), .ptr (.loc bo [.idx o])⟩ ∧
+        (∃ ys' : List Val, mem.blocks bo = some ⟨ko, true, .array (.int false 8) ys.length, .arr ys'⟩ ∧ ys'.length = ys.length) ∧
         Frame m mem [bo] ∧ mem.WF ∧ m.next + 11 ≤ mem.next)
       (fun (utf8_position codepoint : Nat) (mem : Mem) => utf8_position)))
   all_goals cir_vcg
```

#### `cJSON_cJSON_New_Item.lean`
```diff
--- <ROOT>/veriforch/runs/cjson_full/lean_c4ef58d/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_cJSON_New_Item.lean	2026-10-26 03:25:08.316308200 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_cJSON_New_Item.lean	2026-10-27 03:31:16.343748282 +0000
@@ -8,10 +8,11 @@
 namespace VO.v0.fuzzing_cjson_read_fuzzer
 
 @[cir_spec]
-theorem cJSON_cJSON_New_Item_spec (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) :
+theorem cJSON_cJSON_New_Item_spec (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false) :
     Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF) := by
   obtain ⟨b, path, rfl⟩ : ∃ b path, hp = Ptr.loc b path := by
     cases hp <;> first | exact ⟨_, _, rfl⟩ | (simp [Mem.read?] at hh; done) | (exfalso; simp_all [Mem.read?]; done) | (exfalso; revert hh; simp [Mem.read?]; done)
+  simp only [Mem.punnedAccess] at hpun
   have hex : ∃ kh ty v, m.blocks b = some ⟨kh, true, ty, v⟩ ∧ v.get? path = some (.agg [.ptr (.fn "malloc"), f1, f2]) := by
     rcases h : m.blocks b with _ | ⟨kh, al, ty, v⟩
     · exfalso
@@ -43,7 +44,7 @@
       all_goals first
         | (simp [Val.get?] at h; done)
         | (revert h; simp [Val.get?]; done)
-        | (simp only [Val.get?, Option.bind_eq_bind] at h ⊢; exact hbind _ _ _ (fun w hw => ih w hw) h)
+        | (simp only [Val.get?] at h ⊢; exact hbind _ _ _ (fun w hw => ih w hw) h)
         | (simp [Val.get?] at h ⊢; obtain ⟨a, h1, h2⟩ := h; exact ⟨a, h1, ih a h2⟩)
         | (simp [Val.get?] at h ⊢; obtain ⟨a, h2⟩ := h; exact ⟨a, ih _ h2⟩)
         | (simp [Val.get?] at h ⊢; obtain ⟨g, a, h1, h2⟩ := h; exact ⟨g, a, h1, ih a h2⟩)
@@ -53,6 +54,8 @@
         | (simp [Val.get?] at h ⊢; grind)
         | grind [Val.get?]
   obtain ⟨kh, ty, v, cirH_blk, hgetp⟩ := hex
+  rw [cirH_blk] at hpun
+  simp only [Ty.isScalar, Bool.true_and] at hpun
   have cirH_get : v.get? (path ++ [.idx 0]) = some (.ptr (.fn "malloc")) := key v path hgetp
   have cirH_lt : b < m.next := by
     by_cases hc : b < m.next
```

---

## 5. Incremental Restatement from `cirlean` `next` (`e6ac99a`) to `cirlean` `next2` (`424e821`)

- **31 / 32 unit theorem statements** (including `LLVMFuzzerTestOneInput_spec`, `VerifOrch.Cir.Entry`, `VerifOrch.Cir.CJPrintN`, and `VerifOrch.Cir.PrintSpecsN` v2) have **0 lines of statement diff** between `e6ac99a` and `424e821`.
- **1 / 32 unit theorem statements** (`cJSON_cJSON_New_Item_spec`, and the corresponding `h_new` binder in `CycleSpecsP2N` v4, sha256 `b977d06692043c95067d7c54c043c2a02378f8219a0cd11fb64c9d2959804768`) adds one binder after `hpun`:
  ```lean
  (hpunm : ctx.punnedMember m ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false)
  ```
  **Why needed**: `cirlean` `next2` (`recpun`, ancestor of `424e821`) checks `Ctx.punnedMember` (`ctx.typeAt blk.ty path` against record declarations) in addition to `Mem.punnedAccess` (`Ty.atPath blk.ty path`) on every scalar load/store (`Ctx.typedLoad`, `Ctx.typedStore`). Because `cJSON_New_Item` takes an unconstrained pointer `hp : Ptr` to an `internal_hooks` aggregate without fixing the enclosing block's type, `hpunm` states that the record-member punning check at `hp ++ [.idx 0]` is `false`. All callers of `cJSON_New_Item` pass a `parse_buffer` or `internal_hooks` block where `ctx.punnedMember ... = false` reduces by computation.

### Unified Diff: `CycleSpecsP2N` v3 (`e6ac99a`) vs `CycleSpecsP2N` v4 (`424e821`)
```diff
--- <ROOT>/veriforch/notes/stretch_cjson/fh/CycleSpecsP2N_v3.lean	2026-10-27 03:29:33.341297853 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next2_prep/src/CycleSpecsP2N.lean	2026-10-28 01:05:09.134434682 +0000
@@ -40,7 +40,7 @@
     (h_pv : ∀ (ib b bc base bg : Nat) (kb kc kg : BlockKind) (ga gr v0 v1 v2 v3 v4 v5 v6 v7 : Val) (xs : List Int) (len off depth : Nat) (m : Mem) (hwf : m.WF) (hgn : 10 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [ga, .ptr (.fn "free"), gr]⟩) (hib : ib < m.next) (hitem : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, v2, v3, v4, v5, v6, v7]⟩) (hv2 : v2 = .ptr .null) (hv4 : v4 = .ptr .null) (hv5 : ∃ i : Int, v5 = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) (hv6 : ∃ d : Float, v6 = .float d) (hb : b < m.next) (hkb : kb ≠ .readonly) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hdepth : depth ≤ 1000) (hd1 : ib ≠ b) (hd2 : ib ≠ bc) (hd3 : b ≠ bc) (hd4 : bg ≠ ib) (hd5 : bg ≠ b) (hd6 : bg ≠ bc), 2 * (1001 - depth) + 1 < k → Returns ctx fn_cJSON_parse_value.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' depth' : Nat, off ≤ off' ∧ off' ≤ len ∧ (r = some (.int 1) → depth' = depth) ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth', .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ (ty : Int) (vs : Option (Nat × Ty × Val)) (ch : List CJ) (vi vd : Val), m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, .ptr (listPtr (ch.map CJ.b) 0), .int ty, .ptr (ostr vs), vi, vd, v7]⟩ ∧ bitwise true 32 (· &&& ·) ty 256 = 0 ∧ bitwise true 32 (· &&& ·) ty 512 = 0 ∧ -2147483648 ≤ ty ∧ ty ≤ 2147483647 ∧ (vs.isSome = true → m'.blocks (oblk vs) = some ⟨.heap, true, oty vs, oval vs⟩ ∧ m.next ≤ oblk vs ∧ oblk vs ∉ CJ.forestBlocks ch) ∧ CJForest m' ch ∧ (CJ.forestBlocks ch).Nodup ∧ (∀ x ∈ CJ.forestBlocks ch, m.next ≤ x ∧ x < m'.next) ∧ (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧ CStrOpt xs.length vs ∧ CJ.forestPrintable xs.length ch ∧ CJ.forestHeight ch ≤ 1000 - depth)))
     (h_bsw : ∀ (b bc base : Nat) (kb kc : BlockKind) (xs : List Int) (len off depth : Nat) (hooks : Val) (m : Mem) (hwf : m.WF) (hkb : kb ≠ .readonly) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, hooks]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc), Returns ctx fn_cJSON_buffer_skip_whitespace.sym [.ptr (.loc b [])] m (fun r m' => r = some (.ptr (.loc b [])) ∧ ∃ off' : Int, m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, hooks]⟩ ∧ off ≤ off' ∧ off' ≤ len ∧ (off < len → off' < len ∧ (∀ j : Nat, off ≤ j → j < off' → ∃ x, xs[base + j]? = some x ∧ x ≤ 32) ∧ (off' + 1 = len ∨ ∃ x, xs[base + off'.toNat]? = some x ∧ 32 < x)) ∧ Frame m m' [b] ∧ m'.WF))
     (h_del : ∀ (ts : List CJ) (m : Mem) (gb : Nat) (gk : BlockKind) (hma hre : Val) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hg : ctx.gaddr "cJSON$global_hooks" = some gb) (hgbn : gb < m.next) (hgb : m.blocks gb = some ⟨gk, true, .record "internal_hooks", .agg [hma, .ptr (.fn "free"), hre]⟩) (hgbf : gb ∉ CJ.forestBlocks ts), Returns ctx "cJSON_Delete" [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF))
-    (h_new : ∀ (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false), Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF))
+    (h_new : ∀ (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false) (hpunm : ctx.punnedMember m ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false), Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF))
     (ib b bc base bg : Nat) (kb kc kg : BlockKind) (ga gr v0 v1 v2 v3 v4 v5 v6 v7 : Val) (xs : List Int) (len off depth : Nat) (m : Mem) (hwf : m.WF) (hgn : 10 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [ga, .ptr (.fn "free"), gr]⟩) (hib : ib < m.next) (hitem : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, v2, v3, v4, v5, v6, v7]⟩) (hv2 : v2 = .ptr .null) (hv4 : v4 = .ptr .null) (hv5 : ∃ i : Int, v5 = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) (hv6 : ∃ d : Float, v6 = .float d) (hb : b < m.next) (hkb : kb ≠ .readonly) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off < len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hdepth : depth ≤ 1000) (hd1 : ib ≠ b) (hd2 : ib ≠ bc) (hd3 : b ≠ bc) (hd4 : bg ≠ ib) (hd5 : bg ≠ b) (hd6 : bg ≠ bc) (hk : 2 * (1001 - depth) = k), Returns ctx fn_cJSON_parse_array.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' depth' : Nat, off ≤ off' ∧ off' ≤ len ∧ (r = some (.int 1) → depth' = depth) ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth', .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ (ty : Int) (vs : Option (Nat × Ty × Val)) (ch : List CJ) (vi vd : Val), m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, .ptr (listPtr (ch.map CJ.b) 0), .int ty, .ptr (ostr vs), vi, vd, v7]⟩ ∧ bitwise true 32 (· &&& ·) ty 256 = 0 ∧ bitwise true 32 (· &&& ·) ty 512 = 0 ∧ -2147483648 ≤ ty ∧ ty ≤ 2147483647 ∧ (vs.isSome = true → m'.blocks (oblk vs) = some ⟨.heap, true, oty vs, oval vs⟩ ∧ m.next ≤ oblk vs ∧ oblk vs ∉ CJ.forestBlocks ch) ∧ CJForest m' ch ∧ (CJ.forestBlocks ch).Nodup ∧ (∀ x ∈ CJ.forestBlocks ch, m.next ≤ x ∧ x < m'.next) ∧ (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧ CStrOpt xs.length vs ∧ CJ.forestPrintable xs.length ch ∧ CJ.forestHeight ch ≤ 1000 - depth))
 
 /-- `parse_object_step`'s statement, strengthened for printing (FH). -/
@@ -48,7 +48,7 @@
     (h_pv : ∀ (ib b bc base bg : Nat) (kb kc kg : BlockKind) (ga gr v0 v1 v2 v3 v4 v5 v6 v7 : Val) (xs : List Int) (len off depth : Nat) (m : Mem) (hwf : m.WF) (hgn : 10 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [ga, .ptr (.fn "free"), gr]⟩) (hib : ib < m.next) (hitem : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, v2, v3, v4, v5, v6, v7]⟩) (hv2 : v2 = .ptr .null) (hv4 : v4 = .ptr .null) (hv5 : ∃ i : Int, v5 = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) (hv6 : ∃ d : Float, v6 = .float d) (hb : b < m.next) (hkb : kb ≠ .readonly) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hdepth : depth ≤ 1000) (hd1 : ib ≠ b) (hd2 : ib ≠ bc) (hd3 : b ≠ bc) (hd4 : bg ≠ ib) (hd5 : bg ≠ b) (hd6 : bg ≠ bc), 2 * (1001 - depth) + 1 < k → Returns ctx fn_cJSON_parse_value.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' depth' : Nat, off ≤ off' ∧ off' ≤ len ∧ (r = some (.int 1) → depth' = depth) ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth', .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ (ty : Int) (vs : Option (Nat × Ty × Val)) (ch : List CJ) (vi vd : Val), m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, .ptr (listPtr (ch.map CJ.b) 0), .int ty, .ptr (ostr vs), vi, vd, v7]⟩ ∧ bitwise true 32 (· &&& ·) ty 256 = 0 ∧ bitwise true 32 (· &&& ·) ty 512 = 0 ∧ -2147483648 ≤ ty ∧ ty ≤ 2147483647 ∧ (vs.isSome = true → m'.blocks (oblk vs) = some ⟨.heap, true, oty vs, oval vs⟩ ∧ m.next ≤ oblk vs ∧ oblk vs ∉ CJ.forestBlocks ch) ∧ CJForest m' ch ∧ (CJ.forestBlocks ch).Nodup ∧ (∀ x ∈ CJ.forestBlocks ch, m.next ≤ x ∧ x < m'.next) ∧ (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧ CStrOpt xs.length vs ∧ CJ.forestPrintable xs.length ch ∧ CJ.forestHeight ch ≤ 1000 - depth)))
     (h_bsw : ∀ (b bc base : Nat) (kb kc : BlockKind) (xs : List Int) (len off depth : Nat) (hooks : Val) (m : Mem) (hwf : m.WF) (hkb : kb ≠ .readonly) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, hooks]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc), Returns ctx fn_cJSON_buffer_skip_whitespace.sym [.ptr (.loc b [])] m (fun r m' => r = some (.ptr (.loc b [])) ∧ ∃ off' : Int, m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, hooks]⟩ ∧ off ≤ off' ∧ off' ≤ len ∧ (off < len → off' < len ∧ (∀ j : Nat, off ≤ j → j < off' → ∃ x, xs[base + j]? = some x ∧ x ≤ 32) ∧ (off' + 1 = len ∨ ∃ x, xs[base + off'.toNat]? = some x ∧ 32 < x)) ∧ Frame m m' [b] ∧ m'.WF))
     (h_del : ∀ (ts : List CJ) (m : Mem) (gb : Nat) (gk : BlockKind) (hma hre : Val) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hg : ctx.gaddr "cJSON$global_hooks" = some gb) (hgbn : gb < m.next) (hgb : m.blocks gb = some ⟨gk, true, .record "internal_hooks", .agg [hma, .ptr (.fn "free"), hre]⟩) (hgbf : gb ∉ CJ.forestBlocks ts), Returns ctx "cJSON_Delete" [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF))
-    (h_new : ∀ (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false), Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF))
+    (h_new : ∀ (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false) (hpunm : ctx.punnedMember m ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false), Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF))
     (h_ps : ∀ (ib : Nat) (iv : List Val) (b bc : Nat) (kb kc : BlockKind) (xs : List Int) (base len off depth : Nat) (m : Mem) (hkb : kb ≠ .readonly) (hib : ib < m.next) (hiv : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg iv⟩) (hivl : iv.length = 8) (hb : b < m.next) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off < len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hbc : b ≠ bc) (hbi : b ≠ ib) (hci : bc ≠ ib) (hwf : m.WF), Returns ctx fn_cJSON_parse_string.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m.next ≤ m'.next ∧ m'.WF ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' : Nat, off < off' ∧ off' ≤ len ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ ob n ys, m.next ≤ ob ∧ ob < m'.next ∧ m'.blocks ob = some ⟨.heap, true, .array (.int false 8) n, .arr ys⟩ ∧ CStrVal xs.length (.array (.int false 8) n) (.arr ys) ∧ m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg ((iv.set 3 (.int 16)).set 4 (.ptr (.loc ob [.idx 0])))⟩)))
     (ib b bc base bg : Nat) (kb kc kg : BlockKind) (ga gr v0 v1 v2 v3 v4 v5 v6 v7 : Val) (xs : List Int) (len off depth : Nat) (m : Mem) (hwf : m.WF) (hgn : 10 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [ga, .ptr (.fn "free"), gr]⟩) (hib : ib < m.next) (hitem : m.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, v2, v3, v4, v5, v6, v7]⟩) (hv2 : v2 = .ptr .null) (hv4 : v4 = .ptr .null) (hv5 : ∃ i : Int, v5 = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) (hv6 : ∃ d : Float, v6 = .float d) (hb : b < m.next) (hkb : kb ≠ .readonly) (hbb : m.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off, .int depth, .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hlen : base + len ≤ xs.length) (hoff : off ≤ len) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hdepth : depth ≤ 1000) (hd1 : ib ≠ b) (hd2 : ib ≠ bc) (hd3 : b ≠ bc) (hd4 : bg ≠ ib) (hd5 : bg ≠ b) (hd6 : bg ≠ bc) (hk : 2 * (1001 - depth) = k), Returns ctx fn_cJSON_parse_object.sym [.ptr (.loc ib []), .ptr (.loc b [])] m (fun r m' => (r = some (.int 0) ∨ r = some (.int 1)) ∧ m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ ib → b' ≠ b → m'.blocks b' = m.blocks b') ∧ (∃ off' depth' : Nat, off ≤ off' ∧ off' ≤ len ∧ (r = some (.int 1) → depth' = depth) ∧ m'.blocks b = some ⟨kb, true, .record "parse_buffer", .agg [.ptr (.loc bc [.idx base]), .int len, .int off', .int depth', .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩) ∧ (r = some (.int 0) → m'.blocks ib = m.blocks ib) ∧ (r = some (.int 1) → ∃ (ty : Int) (vs : Option (Nat × Ty × Val)) (ch : List CJ) (vi vd : Val), m'.blocks ib = some ⟨.heap, true, .record "cJSON", .agg [v0, v1, .ptr (listPtr (ch.map CJ.b) 0), .int ty, .ptr (ostr vs), vi, vd, v7]⟩ ∧ bitwise true 32 (· &&& ·) ty 256 = 0 ∧ bitwise true 32 (· &&& ·) ty 512 = 0 ∧ -2147483648 ≤ ty ∧ ty ≤ 2147483647 ∧ (vs.isSome = true → m'.blocks (oblk vs) = some ⟨.heap, true, oty vs, oval vs⟩ ∧ m.next ≤ oblk vs ∧ oblk vs ∉ CJ.forestBlocks ch) ∧ CJForest m' ch ∧ (CJ.forestBlocks ch).Nodup ∧ (∀ x ∈ CJ.forestBlocks ch, m.next ≤ x ∧ x < m'.next) ∧ (∃ i : Int, vi = .int i ∧ -2147483648 ≤ i ∧ i ≤ 2147483647) ∧ (∃ d : Float, vd = .float d) ∧ CStrOpt xs.length vs ∧ CJ.forestPrintable xs.length ch ∧ CJ.forestHeight ch ≤ 1000 - depth))
 
```

### Unified Diff: `cJSON_cJSON_New_Item.lean` (`e6ac99a` vs `424e821`)
```diff
--- <ROOT>/veriforch/runs/postfreeze/r1_cjson_e6ac99a/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_cJSON_New_Item.lean	2026-10-27 08:43:45.095744773 +0000
+++ <ROOT>/veriforch/runs/postfreeze/r1_next2_prep/src/VO/v0/fuzzing_cjson_read_fuzzer/cJSON_cJSON_New_Item.lean	2026-10-28 01:05:09.138434681 +0000
@@ -8,11 +8,12 @@
 namespace VO.v0.fuzzing_cjson_read_fuzzer
 
 @[cir_spec]
-theorem cJSON_cJSON_New_Item_spec (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false) :
+theorem cJSON_cJSON_New_Item_spec (hp : Ptr) (f1 f2 : Val) (m : Mem) (hwf : m.WF) (hh : m.read? hp = some (.agg [.ptr (.fn "malloc"), f1, f2])) (hpun : m.punnedAccess ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false) (hpunm : ctx.punnedMember m ((Ty.func [Ty.int false 64] Ty.void.ptr false).ptr) (match hp with | .loc b p => .loc b (p ++ [.idx 0]) | p => p) = false) :
     Returns ctx fn_cJSON_cJSON_New_Item.sym [.ptr hp] m (fun r m' => (r = some (.ptr .null) ∨ ∃ nb, r = some (.ptr (.loc nb [])) ∧ m.next ≤ nb ∧ m'.blocks nb = some ⟨.heap, true, .record "cJSON", .agg [.ptr .null, .ptr .null, .ptr .null, .int 0, .ptr .null, .int 0, .float 0, .ptr .null]⟩) ∧ Frame m m' [] ∧ m'.WF) := by
   obtain ⟨b, path, rfl⟩ : ∃ b path, hp = Ptr.loc b path := by
     cases hp <;> first | exact ⟨_, _, rfl⟩ | (simp [Mem.read?] at hh; done) | (exfalso; simp_all [Mem.read?]; done) | (exfalso; revert hh; simp [Mem.read?]; done)
   simp only [Mem.punnedAccess] at hpun
+  simp only [Ctx.punnedMember] at hpunm
   have hex : ∃ kh ty v, m.blocks b = some ⟨kh, true, ty, v⟩ ∧ v.get? path = some (.agg [.ptr (.fn "malloc"), f1, f2]) := by
     rcases h : m.blocks b with _ | ⟨kh, al, ty, v⟩
     · exfalso
@@ -54,33 +55,17 @@
         | (simp [Val.get?] at h ⊢; grind)
         | grind [Val.get?]
   obtain ⟨kh, ty, v, cirH_blk, hgetp⟩ := hex
-  rw [cirH_blk] at hpun
-  simp only [Ty.isScalar, Bool.true_and] at hpun
+  rw [cirH_blk] at hpun hpunm
+  simp only [Ty.isScalar, Bool.true_and] at hpun hpunm
   have cirH_get : v.get? (path ++ [.idx 0]) = some (.ptr (.fn "malloc")) := key v path hgetp
-  have cirH_lt : b < m.next := by
-    by_cases hc : b < m.next
-    · exact hc
-    · exfalso
-      first
-      | (have h0 := hwf b (by omega); simp_all; done)
-      | (have h0 := hwf.1 b (by omega); simp_all; done)
-      | (unfold Mem.WF at hwf; have h0 := hwf b (by omega); simp_all; done)
-      | (simp only [Mem.WF] at hwf; grind)
-      | grind [Mem.WF]
-  clear hh key hbind
   cir_start
   cir_vcg
-  all_goals (try (first
-    | (left; rfl)
-    | (right; refine ⟨_, rfl, ?_, ?_⟩ <;> first | omega | rfl | (simp [upd_apply]; done) | cir_simp_frame | simp_all)
-    | omega
-    | cir_wf
-    | (refine Mem.WF_of_frame hwf (by simp only; omega) (fun b' hb' => ?_)
-       first
-       | ((have cirH_hb : m.next + 4 ≤ b' := by simpa using hb'); cir_simp_frame)
-       | ((have cirH_hb : m.next + 3 ≤ b' := by simpa using hb'); cir_simp_frame)
-       | cir_simp_frame)
-    | simp_all))
+  all_goals (try cir_wf)
+  all_goals (try (exfalso; rw [hpun] at *; contradiction))
+  all_goals (try (exfalso; rw [hpunm] at *; contradiction))
+  all_goals (try (
+    refine Or.inr ⟨m.next + 2, rfl, by omega, ?_⟩
+    first | (simp [killRange, upd]; done) | (ext; simp [killRange, upd]) | grind))
 
 #print axioms cJSON_cJSON_New_Item_spec
 
```
