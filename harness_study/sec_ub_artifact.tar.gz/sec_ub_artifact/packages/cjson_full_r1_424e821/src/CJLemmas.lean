import CIR.Logic.CJTree
import CIR.Semantics.Init

/-!
  Lemmas for cJSON's `parse_array` loop on the ghost item trees of
  `CIR.Logic.CJTree`: appending an item that owns children and strings
  (`CJForest.snoc_tree`, `CJ.forestBlocks_snoc_nodup`), writing the first
  item's `prev` member at the end of the loop (`CJ.setPrev`,
  `CJForest.set_head_prev`), and read-only globals under a memory that agrees
  on the global blocks (`Module.RoGlobals.of_agree`).
-/

namespace CIR

/-! ### 1. Appending an item with its own children and strings -/

/-- Appending an item that owns children and strings to a sibling list in memory (as
`CJForest.snoc`): the new item's record, strings and children lie in `m'`. -/
theorem CJForest.snoc_tree {m m' : Mem} {ts : List CJ} {t : CJ} (hf : CJForest m ts)
    (hnd : (CJ.forestBlocks ts).Nodup)
    (hsame : ∀ b ∈ CJ.forestBlocks ts, (∀ h : 0 < ts.length, b ≠ ts[ts.length - 1].b) →
      m'.blocks b = m.blocks b)
    (hlast : ∀ h : 0 < ts.length, m'.blocks ts[ts.length - 1].b =
      some ⟨.heap, true, ts[ts.length - 1].rt,
        cjRec (ts.map CJ.b ++ [t.b]) (ts.length - 1) ts[ts.length - 1]⟩)
    (hnew : m'.blocks t.b = some ⟨.heap, true, t.rt, cjRec (ts.map CJ.b ++ [t.b]) ts.length t⟩)
    (hr : bitwise true 32 (· &&& ·) t.type 256 = 0) (hc : bitwise true 32 (· &&& ·) t.type 512 = 0)
    (ht : -2147483648 ≤ t.type ∧ t.type ≤ 2147483647)
    (hv : t.vs.isSome = true → m'.blocks (oblk t.vs) = some ⟨.heap, true, oty t.vs, oval t.vs⟩)
    (hs : t.st.isSome = true → m'.blocks (oblk t.st) = some ⟨.heap, true, oty t.st, oval t.st⟩)
    (hk : CJForest m' t.child) :
    CJForest m' (ts ++ [t]) := by
  -- the other blocks of item `j`: unchanged unless it is the last root
  have other : ∀ j (hj : j < ts.length) b, b ∈ ts[j].blocks → (j ≠ ts.length - 1 ∨ b ≠ ts[j].b) →
      m'.blocks b = m.blocks b := fun j hj b hb hne =>
    hsame b (CJ.mem_forestBlocks hj hb) fun h =>
      CJ.ne_root_of_mem hnd hj (by omega) hb hne
  cases hf with
  | mk _ hb hr0 hc0 ht0 hv0 hs0 hk0 =>
  have hmap : (ts ++ [t]).map CJ.b = ts.map CJ.b ++ [t.b] := by simp
  refine CJForest.mk _ ?_ ?_ ?_ ?_ ?_ ?_ ?_
  · intro j hj
    simp only [List.length_append, List.length_singleton] at hj
    rw [hmap]
    by_cases hj1 : j < ts.length
    · simp only [List.getElem_append_left hj1]
      by_cases hj2 : j = ts.length - 1
      · subst hj2; exact hlast (by omega)
      · rw [other j hj1 _ (CJ.root_mem_blocks _) (Or.inl hj2), hb j hj1]
        have hfj : cjFields (ts.map CJ.b ++ [t.b]) j ts[j] = cjFields (ts.map CJ.b) j ts[j] :=
          cjFields_append ts[j] (by simp; omega)
        simp only [cjRec, hfj]
    · have hj3 : j = ts.length := by omega
      subst hj3
      simpa using hnew
  · intro j hj
    simp only [List.length_append, List.length_singleton] at hj
    by_cases hj1 : j < ts.length
    · simpa [List.getElem_append_left hj1] using hr0 j hj1
    · have hj3 : j = ts.length := by omega
      subst hj3; simpa using hr
  · intro j hj
    simp only [List.length_append, List.length_singleton] at hj
    by_cases hj1 : j < ts.length
    · simpa [List.getElem_append_left hj1] using hc0 j hj1
    · have hj3 : j = ts.length := by omega
      subst hj3; simpa using hc
  · intro j hj
    simp only [List.length_append, List.length_singleton] at hj
    by_cases hj1 : j < ts.length
    · simpa [List.getElem_append_left hj1] using ht0 j hj1
    · have hj3 : j = ts.length := by omega
      subst hj3; simpa using ht
  · intro j hj hsome
    simp only [List.length_append, List.length_singleton] at hj
    by_cases hj1 : j < ts.length
    · simp only [List.getElem_append_left hj1] at hsome ⊢
      have hm := CJ.vs_mem_blocks hsome
      rw [other j hj1 _ hm (Or.inr (fun e => (CJ.own_ne (CJ.item_nodup hnd hj1)).1 hsome e.symm))]
      exact hv0 j hj1 hsome
    · have hj3 : j = ts.length := by omega
      subst hj3
      simp only [List.getElem_append_right (Nat.le_refl _), Nat.sub_self, List.getElem_cons_zero]
        at hsome ⊢
      exact hv hsome
  · intro j hj hsome
    simp only [List.length_append, List.length_singleton] at hj
    by_cases hj1 : j < ts.length
    · simp only [List.getElem_append_left hj1] at hsome ⊢
      have hm := CJ.st_mem_blocks hsome
      rw [other j hj1 _ hm (Or.inr (fun e => (CJ.own_ne (CJ.item_nodup hnd hj1)).2.1 hsome e.symm))]
      exact hs0 j hj1 hsome
    · have hj3 : j = ts.length := by omega
      subst hj3
      simp only [List.getElem_append_right (Nat.le_refl _), Nat.sub_self, List.getElem_cons_zero]
        at hsome ⊢
      exact hs hsome
  · intro j hj
    simp only [List.length_append, List.length_singleton] at hj
    by_cases hj1 : j < ts.length
    · simp only [List.getElem_append_left hj1]
      refine CJForest.frame (hk0 j hj1) (fun b hb' => other j hj1 b (CJ.child_mem_blocks hb') (Or.inr ?_))
      intro e; subst e
      exact CJ.root_not_mem_child hnd j hj1 hb'
    · have hj3 : j = ts.length := by omega
      subst hj3
      simp only [List.getElem_append_right (Nat.le_refl _), Nat.sub_self, List.getElem_cons_zero]
      exact hk

/-! ### 2. No duplicate blocks after the append -/

/-- The blocks of a sibling list stay distinct when an item with distinct blocks, none
of them the list's, is appended. -/
theorem CJ.forestBlocks_snoc_nodup {ts : List CJ} {t : CJ} (hnd : (CJ.forestBlocks ts).Nodup)
    (ht : t.blocks.Nodup) (hdisj : ∀ b ∈ t.blocks, b ∉ CJ.forestBlocks ts) :
    (CJ.forestBlocks (ts ++ [t])).Nodup := by
  rw [CJ.forestBlocks_append]
  simp only [CJ.forestBlocks, List.append_nil]
  refine List.nodup_append.mpr ⟨hnd, ht, ?_⟩
  intro a ha b hb e
  subst e
  exact hdisj a hb ha

/-! ### 3. Writing the first item's `prev` member -/

/-- Item `t` with member `prev` set to `p` (cJSON's `head->prev = last`). -/
def CJ.setPrev (p : Val) : CJ → CJ
  | .item b rt _ ty vi vd vs st ch => .item b rt p ty vi vd vs st ch

@[simp] theorem CJ.setPrev_b (p : Val) (t : CJ) : (t.setPrev p).b = t.b := by
  cases t; simp [CJ.setPrev, CJ.b]
@[simp] theorem CJ.setPrev_rt (p : Val) (t : CJ) : (t.setPrev p).rt = t.rt := by
  cases t; simp [CJ.setPrev, CJ.rt]
@[simp] theorem CJ.setPrev_prev (p : Val) (t : CJ) : (t.setPrev p).prev = p := by
  cases t; simp [CJ.setPrev, CJ.prev]
@[simp] theorem CJ.setPrev_type (p : Val) (t : CJ) : (t.setPrev p).type = t.type := by
  cases t; simp [CJ.setPrev, CJ.type]
@[simp] theorem CJ.setPrev_vi (p : Val) (t : CJ) : (t.setPrev p).vi = t.vi := by
  cases t; simp [CJ.setPrev, CJ.vi]
@[simp] theorem CJ.setPrev_vd (p : Val) (t : CJ) : (t.setPrev p).vd = t.vd := by
  cases t; simp [CJ.setPrev, CJ.vd]
@[simp] theorem CJ.setPrev_vs (p : Val) (t : CJ) : (t.setPrev p).vs = t.vs := by
  cases t; simp [CJ.setPrev, CJ.vs]
@[simp] theorem CJ.setPrev_st (p : Val) (t : CJ) : (t.setPrev p).st = t.st := by
  cases t; simp [CJ.setPrev, CJ.st]
@[simp] theorem CJ.setPrev_child (p : Val) (t : CJ) : (t.setPrev p).child = t.child := by
  cases t; simp [CJ.setPrev, CJ.child]
@[simp] theorem CJ.setPrev_blocks (p : Val) (t : CJ) : (t.setPrev p).blocks = t.blocks := by
  cases t; simp [CJ.setPrev, CJ.blocks]

/-- The record of an item whose `prev` was set: member 1 written. -/
theorem cjFields_setPrev (roots : List Nat) (j : Nat) (t : CJ) (p : Val) :
    cjFields roots j (t.setPrev p) = (cjFields roots j t).set 1 p := by
  simp [cjFields]

theorem CJ.forestBlocks_set_head_prev {ts : List CJ} (h0 : 0 < ts.length) (p : Val) :
    CJ.forestBlocks (ts.set 0 (ts[0].setPrev p)) = CJ.forestBlocks ts := by
  cases ts with
  | nil => simp at h0
  | cons t ts => simp [CJ.forestBlocks]

theorem CJ.map_b_set_head_prev {ts : List CJ} (h0 : 0 < ts.length) (p : Val) :
    (ts.set 0 (ts[0].setPrev p)).map CJ.b = ts.map CJ.b := by
  cases ts with
  | nil => simp at h0
  | cons t ts => simp

/-- Writing the first item's `prev` member (cJSON's `head->prev = last` at the end of
`parse_array`): the head's record has member 1 written, the other blocks did not change. -/
theorem CJForest.set_head_prev {m m' : Mem} {ts : List CJ} (hf : CJForest m ts)
    (hnd : (CJ.forestBlocks ts).Nodup) (h0 : 0 < ts.length) (p : Val)
    (hsame : ∀ b ∈ CJ.forestBlocks ts, b ≠ ts[0].b → m'.blocks b = m.blocks b)
    (hhead : m'.blocks ts[0].b = some ⟨.heap, true, ts[0].rt,
      .agg ((cjFields (ts.map CJ.b) 0 ts[0]).set 1 p)⟩) :
    CJForest m' (ts.set 0 (ts[0].setPrev p)) := by
  -- the blocks of item `j` other than the head's root did not change
  have other : ∀ j (hj : j < ts.length) b, b ∈ ts[j].blocks → (j ≠ 0 ∨ b ≠ ts[j].b) →
      m'.blocks b = m.blocks b := fun j hj b hb hne =>
    hsame b (CJ.mem_forestBlocks hj hb) (CJ.ne_root_of_mem hnd hj h0 hb hne)
  have hmap := CJ.map_b_set_head_prev h0 p
  cases hf with
  | mk _ hb hr0 hc0 ht0 hv0 hs0 hk0 =>
  refine CJForest.mk _ ?_ ?_ ?_ ?_ ?_ ?_ ?_
  · intro j hj
    rw [hmap]
    have hj' : j < ts.length := by simpa using hj
    by_cases hj0 : j = 0
    · subst hj0
      simp only [List.getElem_set_self, CJ.setPrev_b, CJ.setPrev_rt, cjRec, cjFields_setPrev]
      exact hhead
    · simp only [List.getElem_set_ne (Ne.symm hj0)]
      rw [other j hj' _ (CJ.root_mem_blocks _) (Or.inl hj0)]
      exact hb j hj'
  · intro j hj
    have hj' : j < ts.length := by simpa using hj
    by_cases hj0 : j = 0
    · subst hj0; simpa using hr0 0 hj'
    · simpa [List.getElem_set_ne (Ne.symm hj0)] using hr0 j hj'
  · intro j hj
    have hj' : j < ts.length := by simpa using hj
    by_cases hj0 : j = 0
    · subst hj0; simpa using hc0 0 hj'
    · simpa [List.getElem_set_ne (Ne.symm hj0)] using hc0 j hj'
  · intro j hj
    have hj' : j < ts.length := by simpa using hj
    by_cases hj0 : j = 0
    · subst hj0; simpa using ht0 0 hj'
    · simpa [List.getElem_set_ne (Ne.symm hj0)] using ht0 j hj'
  · intro j hj hsome
    have hj' : j < ts.length := by simpa using hj
    by_cases hj0 : j = 0
    · subst hj0
      simp only [List.getElem_set_self, CJ.setPrev_vs] at hsome ⊢
      rw [other 0 hj' _ (CJ.vs_mem_blocks hsome)
        (Or.inr (fun e => (CJ.own_ne (CJ.item_nodup hnd hj')).1 hsome e.symm))]
      exact hv0 0 hj' hsome
    · simp only [List.getElem_set_ne (Ne.symm hj0)] at hsome ⊢
      rw [other j hj' _ (CJ.vs_mem_blocks hsome) (Or.inl hj0)]
      exact hv0 j hj' hsome
  · intro j hj hsome
    have hj' : j < ts.length := by simpa using hj
    by_cases hj0 : j = 0
    · subst hj0
      simp only [List.getElem_set_self, CJ.setPrev_st] at hsome ⊢
      rw [other 0 hj' _ (CJ.st_mem_blocks hsome)
        (Or.inr (fun e => (CJ.own_ne (CJ.item_nodup hnd hj')).2.1 hsome e.symm))]
      exact hs0 0 hj' hsome
    · simp only [List.getElem_set_ne (Ne.symm hj0)] at hsome ⊢
      rw [other j hj' _ (CJ.st_mem_blocks hsome) (Or.inl hj0)]
      exact hs0 j hj' hsome
  · intro j hj
    have hj' : j < ts.length := by simpa using hj
    by_cases hj0 : j = 0
    · subst hj0
      simp only [List.getElem_set_self, CJ.setPrev_child]
      refine CJForest.frame (hk0 0 hj') (fun b hb' => other 0 hj' b (CJ.child_mem_blocks hb') (Or.inr ?_))
      intro e; subst e
      exact CJ.root_not_mem_child hnd 0 hj' hb'
    · simp only [List.getElem_set_ne (Ne.symm hj0)]
      exact CJForest.frame (hk0 j hj') (fun b hb' => other j hj' b (CJ.child_mem_blocks hb') (Or.inl hj0))

/-! ### 4. Read-only globals under a memory that agrees on the global blocks -/

/-- The constant globals keep their initial values in a memory that agrees on the
globals' blocks. -/
theorem Module.RoGlobals.of_agree {M : Module} {m m' : Mem} (h : M.RoGlobals m)
    (hag : ∀ i, i < M.globals.length → m'.blocks i = m.blocks i) : M.RoGlobals m' := by
  intro i g hg hc
  have hi : i < M.globals.length := (List.getElem?_eq_some_iff.mp hg).1
  rw [hag i hi]
  exact h i g hg hc

end CIR

#print axioms CIR.CJForest.snoc_tree
#print axioms CIR.CJ.forestBlocks_snoc_nodup
#print axioms CIR.CJ.setPrev_b
#print axioms CIR.CJ.setPrev_rt
#print axioms CIR.CJ.setPrev_prev
#print axioms CIR.CJ.setPrev_type
#print axioms CIR.CJ.setPrev_vi
#print axioms CIR.CJ.setPrev_vd
#print axioms CIR.CJ.setPrev_vs
#print axioms CIR.CJ.setPrev_st
#print axioms CIR.CJ.setPrev_child
#print axioms CIR.CJ.setPrev_blocks
#print axioms CIR.cjFields_setPrev
#print axioms CIR.CJ.forestBlocks_set_head_prev
#print axioms CIR.CJ.map_b_set_head_prev
#print axioms CIR.CJForest.set_head_prev
#print axioms CIR.Module.RoGlobals.of_agree
