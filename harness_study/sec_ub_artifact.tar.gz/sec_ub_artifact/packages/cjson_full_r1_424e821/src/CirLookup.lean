import CIR
import Std.Data.HashMap

/-!
# Deterministic lookups in symbolic memories

`lookupProof bs x` proves `bs x = some blk` for a memory term `bs` built from

* `killRange lo hi F` (scope exits; a partial application),
* `upd F k v` (writes),
* `Mem.blocks m`, where `m` is a structure literal `{ blocks := B, next := N }`
  or a free memory (a callee's output memory, a loop state), described by the
  hypotheses in the context:
  - block facts `m.blocks x = some blk`;
  - item facts `∀ j (h : j < ts.length), m.blocks ts[j].b = …`;
  - frames `∀ b, prem₁ → … → m'.blocks b = RHS b` (callee frames, loop frames,
    `MemAgree m' m P`, `Frame m m' L`), whose right side is looked up in turn;
  - definitions `σ = { mem := …, … }`.

Each layer is decided by one lemma: `killRange_keep` (a block that is not a
stack block survives a scope exit), `killRange_of_lt`, `killRange_of_ge`,
`upd_same`, `upd_ne`. Side conditions are decided syntactically
(`decideNatKeySyn`) or by `omega` over the arithmetic hypotheses, called as a
`MetaM` function, so that a failure is an exception (never a logged error plus
`sorry`). Hypotheses are tried in a fixed order (block facts, item facts,
frames), with backtracking, so that a loop frame cannot hide an item fact.

Tactics:
* `cir_lookup_eq` closes `M x = some ⟨?k, true, ?ty, ?v⟩`; the metavariables
  are assigned from the lookup, also when they are goals of their own (the
  ghosts of a callee's precondition are synthetic opaque);
* `cir_lookup_contra` closes any goal from a failed liveness check
  `(match M x with | some blk => if blk.alive = true then some blk else none
  | none => none).isSome = false` (or a variant: `isNone`, `= true`, `¬`,
  `= none`), or from block ids proved equal (`a = c`) whose lookups give blocks
  of different kinds (a stack slot and a heap item);
* simprocs `lookupBlockKR`, `lookupBlockMem`, `lookupBlockUpd` rewrite a lookup
  to its block (end of the file).

Set `CIR_LOOKUP_TRACE=1` (and `CIR_LIVE_LOG`) for a trace of every step.
-/

namespace CIR.Lookup

/-- A block that is not a stack block survives a scope exit. -/
theorem killRange_keep {lo hi : Nat} {bs : Nat → Option MemBlock} {b : Nat} {blk : MemBlock}
    (h : bs b = some blk) (hk : blk.kind ≠ .stack) : killRange lo hi bs b = some blk := by
  rw [killRange_apply]; split <;> simp [h, hk]

theorem not_mem_cons_of {a b : Nat} {l : List Nat} (h1 : a ≠ b) (h2 : ¬ a ∈ l) : ¬ a ∈ b :: l := by
  simp only [List.mem_cons, not_or]; exact ⟨h1, h2⟩

theorem not_mem_nil_of (a : Nat) : ¬ a ∈ ([] : List Nat) := by simp

theorem some_ne_none {α : Type} (a : α) : some a ≠ none := by intro h; cases h

theorem upd_eq_of_eq {α β : Type} [DecidableEq α] (f : α → β) {a x : α} (b : β) (h : x = a) :
    upd f a b x = b := by subst h; simp [upd]

open Lean Meta Elab Tactic

/-- A line in the live log (`CIR_LIVE_LOG`). -/
def elog (s : String) : IO Unit := do
  let some path ← IO.getEnv "CIR_LIVE_LOG" | return
  let h ← IO.FS.Handle.mk path .append
  h.putStrLn s
  h.flush

/-- A hypothesis whose conclusion (under `nq` binders) is `key arg = rhs`, with
`key : Nat → Option MemBlock` closed. `ty` is the type with `MemAgree` and
`Frame` unfolded; `pf` proves it. -/
structure Fact where
  pf  : Expr
  ty  : Expr
  key : Expr
  arg : Expr
  nq  : Nat

structure Env where
  facts : Array Fact
  /-- `(a, v, h)` with `h : a = v`, `a` a free variable, `v` a constructor application. -/
  defs  : Array (Expr × Expr × Expr)
  omegaCache : IO.Ref (Std.HashMap Expr (Option Expr))
  /-- omega calls, omega milliseconds -/
  stats : IO.Ref (Nat × Nat)
  trace : Bool

def Env.log (env : Env) (msg : Unit → MetaM String) : MetaM Unit := do
  if env.trace then elog (← msg ())

def isOptBlock (t : Expr) : Bool :=
  t.isAppOfArity ``Option 1 && (t.getArg! 0).isConstOf ``CIR.MemBlock

def isNatOrInt (t : Expr) : Bool := t.isConstOf ``Nat || t.isConstOf ``Int

def isArithAtom (e : Expr) : Bool :=
  let e := e.consumeMData
  (e.isAppOfArity ``LT.lt 4 || e.isAppOfArity ``LE.le 4 || e.isAppOfArity ``GT.gt 4 ||
    e.isAppOfArity ``GE.ge 4 || e.isAppOfArity ``Eq 3 || e.isAppOfArity ``Ne 3) &&
    isNatOrInt (e.getArg! 0).consumeMData

/-- A conjunction of (negated) comparisons of natural numbers or integers: the
hypotheses given to `omega` (implications and disjunctions are left out, so a
failing call stays cheap). -/
partial def isArith (e : Expr) : Bool :=
  let e := e.consumeMData
  if e.isAppOfArity ``And 2 then isArith (e.getArg! 0) && isArith (e.getArg! 1)
  else if e.isAppOfArity ``Not 1 then isArithAtom (e.getArg! 0)
  else isArithAtom e

/-- The binders and the conclusion of a type (syntactically, no unfolding). -/
def conclOf (ty : Expr) : Nat × Expr := Id.run do
  let mut t := ty
  let mut n := 0
  while t.isForall do
    t := t.bindingBody!
    n := n + 1
  return (n, t.consumeMData)

/-- The facts and definitions of the local context. -/
def collectEnv (trace : Bool) : MetaM Env := do
  let mut facts : Array Fact := #[]
  let mut defs : Array (Expr × Expr × Expr) := #[]
  for d in ← getLCtx do
    if d.isImplementationDetail then continue
    let ty := (← instantiateMVars d.type).consumeMData
    -- `a = C …` with `a` a free variable and `C` a constructor
    if let some (_, a, v) := ty.eq? then
      let v := v.consumeMData
      if a.consumeMData.isFVar then
        if let some c := v.getAppFn.constName? then
          if let some (.ctorInfo _) := (← getEnv).find? c then
            defs := defs.push (a.consumeMData, v, d.toExpr)
    let (pf, ty) ← do
      if ty.isAppOfArity ``CIR.MemAgree 3 then
        match ← unfoldDefinition? ty with
        | some t => pure (d.toExpr, t.headBeta)
        | none => pure (d.toExpr, ty)
      else if ty.isAppOfArity ``CIR.Frame 3 then
        match ← unfoldDefinition? ty with
        | some t =>
          let t := t.headBeta.consumeMData
          if t.isAppOfArity ``And 2 then
            pure (mkApp3 (mkConst ``And.right) (t.getArg! 0) (t.getArg! 1) d.toExpr, t.getArg! 1)
          else pure (d.toExpr, ty)
        | none => pure (d.toExpr, ty)
      else pure (d.toExpr, ty)
    let (n, c) := conclOf ty
    let some (α, lhs, _) := c.eq? | continue
    unless isOptBlock α.consumeMData do continue
    let lhs := lhs.consumeMData
    unless lhs.isApp do continue
    let key := lhs.appFn!.consumeMData
    if key.hasLooseBVars then continue
    facts := facts.push { pf, ty, key, arg := lhs.appArg!.consumeMData, nq := n }
  return { facts, defs, omegaCache := ← IO.mkRef {}, stats := ← IO.mkRef (0, 0), trace }

/-- The arithmetic hypotheses of the local context. -/
def omegaFacts : MetaM (List Expr) := do
  let mut out := []
  for d in ← getLCtx do
    if d.isImplementationDetail then continue
    if isArith (← instantiateMVars d.type) then out := d.toExpr :: out
  return out

/-- `omega` on `p` (the arithmetic hypotheses only); throws on failure. -/
def runOmega (p : Expr) : MetaM Expr := do
  let g ← mkFreshExprSyntheticOpaqueMVar p
  match ← g.mvarId!.falseOrByContra with
  | some g' => g'.withContext do Lean.Elab.Tactic.Omega.omega (← omegaFacts) g' {}
  | none => pure ()
  instantiateMVars g

/-- A proof of the arithmetic proposition `p` by `omega` (over the arithmetic
hypotheses), or `none`. Results are cached. -/
def omegaProof? (env : Env) (p : Expr) : MetaM (Option Expr) := do
  let p ← instantiateMVars p
  if let some r := (← env.omegaCache.get)[p]? then return r
  let t0 ← IO.monoMsNow
  let s ← saveState
  let mut r : Option Expr := none
  try
    r := some (← runOmega p)
  catch _ =>
    s.restore
  let dt := (← IO.monoMsNow) - t0
  env.stats.modify fun (n, ms) => (n + 1, ms + dt)
  env.omegaCache.modify (·.insert p r)
  env.log fun _ => do return s!"    omega {if r.isSome then "ok" else "FAIL"} {dt}ms: {← ppExpr p}"
  return r

def omegaProof (env : Env) (p : Expr) : MetaM Expr := do
  match ← omegaProof? env p with
  | some pf => return pf
  | none => throwError "cir_lookup: omega failed on {p}"

/-- A proof of `x ≠ k` for block ids. -/
def neProof (env : Env) (x k : Expr) : MetaM Expr := do
  match ← CIR.Tactic.decideNatKeySyn x k with
  | some (.inr h) => return h
  | some (.inl _) => throwError "cir_lookup: the keys {x} and {k} are equal"
  | none => omegaProof env (← mkAppM ``Ne #[x, k])

/-- `¬ x ∈ l` for a list `l` that is not a literal, from a hypothesis
`∀ y, y ∈ l → Q y` with `Q` arithmetic (e.g. the blocks of a list of items lie
in `[m.next, σ.mem.next)`) and `omega` on `Q x`. -/
def notMemByBounds (env : Env) (x l : Expr) : MetaM Expr := do
  let q ← try mkAppM ``Membership.mem #[l, x] catch _ => mkAppM ``Membership.mem #[x, l]
  for d in ← getLCtx do
    if d.isImplementationDetail then continue
    let ty := (← instantiateMVars d.type).consumeMData
    let .forallE _ dom body _ := ty | continue
    unless dom.consumeMData.isConstOf ``Nat do continue
    let .forallE _ hm _ _ := body | continue
    let hm := hm.consumeMData
    unless hm.isAppOfArity ``Membership.mem 5 do continue
    let a3 := hm.getArg! 3
    let a4 := hm.getArg! 4
    let coll := if a4 == .bvar 0 then a3 else a4
    if coll.hasLooseBVars then continue
    unless coll == l || (← withReducible (isDefEq coll l)) do continue
    let s ← saveState
    try
      let pf ← withLocalDeclD `cirHm q fun hmem => do
        let inst := mkApp2 d.toExpr x hmem
        let qx ← instantiateForall ty #[x, hmem]
        unless isArith qx do throwError "not arithmetic: {qx}"
        let pfF ← withLocalDeclD `cirHq qx fun hq => do
          mkLambdaFVars #[hq] (← runOmega (mkConst ``False))
        mkLambdaFVars #[hmem] (mkApp pfF inst).headBeta
      env.log fun _ => do return s!"    not in {← ppExpr l} by {d.userName}"
      return pf
    catch _ => s.restore
  throwError "cir_lookup: cannot prove {x} ∉ {l}"

/-- A proof of `¬ x ∈ l` for a list literal `l` of block ids. -/
partial def notMemProof (env : Env) (x l : Expr) : MetaM Expr := do
  let l := l.consumeMData
  if l.isAppOfArity ``List.nil 1 then return mkApp (mkConst ``CIR.Lookup.not_mem_nil_of) x
  if l.isAppOfArity ``List.cons 3 then
    let b := l.getArg! 1
    let t := l.getArg! 2
    let h1 ← neProof env x b
    let h2 ← notMemProof env x t
    return mkAppN (mkConst ``CIR.Lookup.not_mem_cons_of) #[x, b, t, h1, h2]
  notMemByBounds env x l

/-- A proof of a side condition: an assumption, a conjunction, list
non-membership, or linear arithmetic. -/
partial def proveSide (env : Env) (p : Expr) : MetaM Expr := do
  let p := (← instantiateMVars p).consumeMData.headBeta
  for d in ← getLCtx do
    if !d.isImplementationDetail && d.type == p then return d.toExpr
  if p.isConstOf ``True then return mkConst ``True.intro
  if p.isAppOfArity ``And 2 then
    let a := p.getArg! 0
    let b := p.getArg! 1
    return mkApp4 (mkConst ``And.intro) a b (← proveSide env a) (← proveSide env b)
  if p.isAppOfArity ``Not 1 then
    let q := (p.getArg! 0).consumeMData
    if q.isAppOfArity ``Membership.mem 5 then
      let a3 := q.getArg! 3
      let a4 := q.getArg! 4
      -- `Membership.mem coll a` (Lean ≥ 4.12); the list is the collection
      let isList (e : Expr) : MetaM Bool := do
        return (← whnfR (← inferType e)).isAppOf ``List
      if ← isList a3 then return ← notMemProof env a4 a3
      return ← notMemProof env a3 a4
  if isArith p then return ← omegaProof env p
  throwError "cir_lookup: cannot prove the side condition {p}"

inductive KeyCmp where
  | same
  | eqPf (h : Expr)
  | ne (h : Expr)

/-- Compare the looked-up key `x` with the key `k` of a write. -/
def keyCmp (env : Env) (x k : Expr) : MetaM KeyCmp := do
  if x == k then return .same
  match ← CIR.Tactic.decideNatKeySyn x k with
  | some (.inl _) => return .same
  | some (.inr h) => return .ne h
  | none =>
    if ← withReducible (isDefEq x k) then return .same
    if let some h ← omegaProof? env (← mkAppM ``Ne #[x, k]) then return .ne h
    if let some h ← omegaProof? env (← mkEq x k) then return .eqPf h
    throwError "cir_lookup: cannot compare the keys {x} and {k}"

/-- `v` as `some _` (or throw: the block is absent). -/
def someVal (v : Expr) : MetaM Expr := do
  let v := v.consumeMData
  if v.isAppOfArity ``Option.some 2 then return v
  let v' ← whnfR v
  if v'.isAppOfArity ``Option.some 2 then return v'
  throwError "cir_lookup: no block ({v})"

/-- A proof of `blk.kind ≠ .stack` when the kind is a constructor other than `stack`. -/
def notStackProof? (blk : Expr) : MetaM (Option Expr) := do
  let blk := blk.consumeMData
  unless blk.isAppOfArity ``CIR.MemBlock.mk 4 do return none
  let k := (blk.getArg! 0).consumeMData
  unless k.isConst do return none
  if k.isConstOf ``CIR.BlockKind.stack then return none
  let p ← mkAppM ``Ne #[mkApp (mkConst ``CIR.MemBlock.kind) blk, mkConst ``CIR.BlockKind.stack]
  return some (← mkDecideProof p)

/-- `State.mem (State.mk m …)` and the like, reduced to a structure literal `Mem.mk B N`. -/
def reduceToMk (m : Expr) : MetaM Expr := do
  let m' ← whnfR m
  if m'.isAppOfArity ``CIR.Mem.mk 2 then return m'
  let m'' ← withDefault (whnf m)
  if m''.isAppOfArity ``CIR.Mem.mk 2 then return m''
  return m

mutual

/-- A proof of `bs x = v` with `v = some blk`, and `v`. -/
partial def lookupCore (env : Env) (bs x : Expr) (depth : Nat) (path : List (Expr × Expr)) :
    MetaM (Expr × Expr) := do
  if depth > 64 then throwError "cir_lookup: too deep"
  let bs := (← instantiateMVars bs).consumeMData
  let x := (← instantiateMVars x).consumeMData
  if path.any (fun (b', x') => b' == bs && x' == x) then throwError "cir_lookup: cycle"
  let path := (bs, x) :: path
  env.log fun _ => do return s!"  {"".pushn ' ' depth}lookup {(toString (← ppExpr bs)).take 160} @ {← ppExpr x}"
  -- a scope exit
  if bs.isAppOfArity ``CIR.killRange 3 then
    let lo := bs.getArg! 0
    let hi := bs.getArg! 1
    let F := bs.getArg! 2
    let (p, v) ← lookupCore env F x (depth + 1) path
    let blk := v.appArg!
    if let some hk ← notStackProof? blk then
      return (mkAppN (mkConst ``CIR.Lookup.killRange_keep) #[lo, hi, F, x, blk, p, hk], v)
    if let some h ← omegaProof? env (← mkAppM ``LT.lt #[x, lo]) then
      return (← mkEqTrans (mkAppN (mkConst ``CIR.killRange_of_lt) #[lo, hi, F, x, h]) p, v)
    if let some h ← omegaProof? env (← mkAppM ``LE.le #[hi, x]) then
      return (← mkEqTrans (mkAppN (mkConst ``CIR.killRange_of_ge) #[lo, hi, F, x, h]) p, v)
    throwError "cir_lookup: scope exit [{lo}, {hi}) at {x} not decided (block kind {blk})"
  -- a write
  if bs.isAppOfArity ``CIR.upd 6 then
    let lv := bs.getAppFn.constLevels!
    let α := bs.getArg! 0
    let β := bs.getArg! 1
    let inst := bs.getArg! 2
    let F := bs.getArg! 3
    let k := bs.getArg! 4
    let w := bs.getArg! 5
    match ← keyCmp env x k with
    | .same =>
      let v ← someVal w
      let pf := mkAppN (mkConst ``CIR.upd_same lv) #[α, β, inst, F, k, w]
      return (← mkExpectedTypeHint pf (← mkEq (mkApp bs x) v), v)
    | .eqPf h =>
      let v ← someVal w
      let pf := mkAppN (mkConst ``CIR.Lookup.upd_eq_of_eq lv) #[α, β, inst, F, k, x, w, h]
      return (← mkExpectedTypeHint pf (← mkEq (mkApp bs x) v), v)
    | .ne h =>
      let (p, v) ← lookupCore env F x (depth + 1) path
      return (← mkEqTrans (mkAppN (mkConst ``CIR.upd_ne lv) #[α, β, inst, F, k, w, x, h]) p, v)
  -- a structure literal
  let mArg? : Option Expr :=
    if bs.isAppOfArity ``CIR.Mem.blocks 1 then some (bs.getArg! 0).consumeMData
    else match bs with
      | .proj ``CIR.Mem 0 m => some m.consumeMData
      | _ => none
  if let some m := mArg? then
    let m' ← if m.isAppOfArity ``CIR.Mem.mk 2 then pure m else reduceToMk m
    if m'.isAppOfArity ``CIR.Mem.mk 2 then
      let (p, v) ← lookupCore env (m'.getArg! 0) x (depth + 1) path
      return (← mkExpectedTypeHint p (← mkEq (mkApp bs x) v), v)
  if bs.isLambda then
    let e := (mkApp bs x).headBeta
    if e.isApp then
      let (p, v) ← lookupCore env e.appFn! e.appArg! (depth + 1) path
      return (← mkExpectedTypeHint p (← mkEq (mkApp bs x) v), v)
  -- a free memory: facts, then definitions
  if let some r ← factLookup env bs x depth path then return r
  for (a, val, h) in env.defs do
    unless bs.containsFVar a.fvarId! do continue
    let e := mkApp bs x
    let motive := mkLambda `s .default (← inferType a) (e.abstract #[a])
    let e' := e.replaceFVar a val
    let pf1 ← mkExpectedTypeHint (← mkCongrArg motive h) (← mkEq e e')
    let s ← saveState
    try
      let (p, v) ← lookupCore env e'.appFn! e'.appArg! (depth + 1) path
      return (← mkEqTrans pf1 p, v)
    catch ex =>
      env.log fun _ => do return s!"  {"".pushn ' ' depth}def {← ppExpr a} failed: {← ex.toMessageData.toString}"
      s.restore
  throwError "cir_lookup: no fact gives {bs} {x}"

/-- The facts about `bs`, in order: block facts, item facts, frames. -/
partial def factLookup (env : Env) (bs x : Expr) (depth : Nat) (path : List (Expr × Expr)) :
    MetaM (Option (Expr × Expr)) := do
  let sameKey (f : Fact) : MetaM Bool := do
    if f.key == bs then return true
    if f.key.getAppFn != bs.getAppFn then return false
    withReducible (isDefEq f.key bs)
  -- the right side of a fact: a block, or a memory term to look up
  let finish (pf rhs : Expr) : MetaM (Expr × Expr) := do
    let rhs := (← instantiateMVars rhs).consumeMData
    let pf ← mkExpectedTypeHint pf (← mkEq (mkApp bs x) rhs)
    if rhs.isAppOfArity ``Option.some 2 then return (pf, rhs)
    unless rhs.isApp do throwError "cir_lookup: fact gives {rhs}"
    let (p2, v) ← lookupCore env rhs.appFn! rhs.appArg! (depth + 1) path
    return (← mkEqTrans pf p2, v)
  -- block facts
  for f in env.facts do
    if f.nq != 0 then continue
    unless ← sameKey f do continue
    unless f.arg == x || (← withReducible (isDefEq f.arg x)) do continue
    let some (_, _, rhs) := f.ty.consumeMData.eq? | continue
    let s ← saveState
    try
      let r ← finish f.pf rhs
      env.log fun _ => do return s!"  {"".pushn ' ' depth}fact {← ppExpr f.pf}"
      return some r
    catch _ => s.restore
  -- item facts (argument not a bound variable), then frames
  for pass in [0, 1] do
    for f in env.facts do
      if f.nq == 0 then continue
      if (pass == 0) == f.arg.isBVar then continue
      unless ← sameKey f do continue
      let s ← saveState
      try
        let (xs, _, body) ← forallMetaTelescope f.ty
        let some (_, lhs, rhs) := body.consumeMData.eq? | throwError "not an equation"
        unless ← withReducible (isDefEq lhs.consumeMData.appArg! x) do throwError "key does not unify"
        for mv in xs do
          unless (← instantiateMVars mv).isMVar do continue
          let ty ← instantiateMVars (← inferType mv)
          unless ← isProp ty do throwError "unassigned variable {mv}"
          mv.mvarId!.assign (← proveSide env ty)
        let pf ← instantiateMVars (mkAppN f.pf xs)
        let r ← finish pf rhs
        env.log fun _ => do return s!"  {"".pushn ' ' depth}{if pass == 0 then "item" else "frame"} {← ppExpr f.pf}"
        return some r
      catch ex =>
        env.log fun _ => do return s!"  {"".pushn ' ' depth}skip {← ppExpr f.pf}: {(← ex.toMessageData.toString).take 200}"
        s.restore
  return none

end

/-- The environment for the main goal. -/
def mkEnv : MetaM Env := do
  collectEnv (← IO.getEnv "CIR_LOOKUP_TRACE").isSome

/-- A proof of `bs x = some blk` (`blk` as concrete as the facts give). -/
partial def lookupProof (bs x : Expr) : TacticM Expr := withMainContext do
  let env ← mkEnv
  return (← lookupCore env bs x 0 []).1

/-- The first lookup `bs x` (a scope exit, a write or `Mem.blocks _` applied to
a block id) in `e`. -/
def findLookup? (e : Expr) : Option Expr :=
  e.find? fun t =>
    t.isAppOfArity ``CIR.killRange 4 || t.isAppOfArity ``CIR.Mem.blocks 2 ||
      (t.isAppOfArity ``CIR.upd 7 && (t.getArg! 0).isConstOf ``Nat && isOptBlock (t.getArg! 1))

/-- A proof of `q` by evaluation (checked before it is used). -/
def decideTrue (q : Expr) : MetaM Expr := do
  let d ← mkDecide q
  let r ← withDefault (whnf d)
  unless r.isConstOf ``Bool.true do throwError "cir_lookup: {q} does not evaluate to true"
  mkDecideProof q

/-- `False` from `hB : B₁ = B₂` for blocks of different kinds (or liveness). -/
def blockContra (hB : Expr) : MetaM Expr := do
  for field in [``CIR.MemBlock.kind, ``CIR.MemBlock.alive] do
    let s ← saveState
    try
      let h ← mkCongrArg (mkConst field) hB
      let hn ← decideTrue (mkNot (← inferType h))
      return mkApp hn h
    catch _ => s.restore
  throwError "cir_lookup: the blocks agree in kind and liveness"

/-- A proof of `False` from the context. -/
def contraProof (env : Env) : MetaM Expr := do
  -- 1. a failed liveness check (a `Bool` fact about a lookup)
  for d in ← getLCtx do
    if d.isImplementationDetail then continue
    let ty := (← instantiateMVars d.type).consumeMData
    let core := if ty.isAppOfArity ``Not 1 then (ty.getArg! 0).consumeMData else ty
    let isNone := core.isAppOfArity ``Eq 3 && (core.getArg! 2).consumeMData.isAppOfArity ``Option.none 1
    unless core.isAppOfArity ``Eq 3 && ((core.getArg! 0).isConstOf ``Bool || isNone) do continue
    let some L := findLookup? ty | continue
    let s ← saveState
    try
      env.log fun _ => do return s!"contra: check {d.userName}"
      let (p, v) ← lookupCore env L.appFn! L.appArg! 0 []
      let abst ← kabstract ty L
      let motive := mkLambda `z .default (← inferType L) abst
      let ty' := abst.instantiate1 v
      let h' ← mkExpectedTypeHint (← mkEqMP (← mkCongrArg motive p) d.toExpr) ty'
      if isNone && !ty.isAppOfArity ``Not 1 then
        -- `X' = none` where `X'` evaluates to `some a`
        let lhs' ← withDefault (whnf (ty'.getArg! 1))
        unless lhs'.isAppOfArity ``Option.some 2 do throwError "not a block: {lhs'}"
        let h'' ← mkExpectedTypeHint h' (← mkEq lhs' (ty'.getArg! 2))
        return mkApp (mkApp2 (mkConst ``CIR.Lookup.some_ne_none) (lhs'.getArg! 0) lhs'.appArg!) h''
      if ty'.isAppOfArity ``Not 1 then
        return mkApp h' (← decideTrue (ty'.getArg! 0))
      return mkApp (← decideTrue (mkNot ty')) h'
    catch ex =>
      env.log fun _ => do return s!"contra: {d.userName} failed: {← ex.toMessageData.toString}"
      s.restore
  -- 2. block ids proved equal, whose blocks differ
  for d in ← getLCtx do
    if d.isImplementationDetail then continue
    let ty := (← instantiateMVars d.type).consumeMData
    let some (α, a, c) := ty.eq? | continue
    unless α.consumeMData.isConstOf ``Nat do continue
    let a := a.consumeMData
    let c := c.consumeMData
    -- the memories with a block fact at `a` or `c`
    let mut keys : Array Expr := #[]
    for f in env.facts do
      if f.nq != 0 then continue
      if f.arg == a || f.arg == c then
        unless keys.contains f.key do keys := keys.push f.key
    for f in env.facts do
      if f.nq == 0 || f.arg.isBVar || keys.contains f.key then continue
      let s ← saveState
      let (_, _, body) ← forallMetaTelescope f.ty
      let ok ← match body.consumeMData.eq? with
        | some (_, lhs, _) => do
          let t := lhs.consumeMData.appArg!
          pure ((← withReducible (isDefEq t a)) || (← withReducible (isDefEq t c)))
        | none => pure false
      s.restore
      if ok then keys := keys.push f.key
    for K in keys do
      let s ← saveState
      try
        env.log fun _ => do return s!"contra: {d.userName} on {← ppExpr K}"
        let (p1, _) ← lookupCore env K a 0 []
        let (p2, _) ← lookupCore env K c 0 []
        let h12 ← mkEqTrans (← mkEqSymm p1) (← mkEqTrans (← mkCongrArg K d.toExpr) p2)
        return ← blockContra (← mkAppM ``Option.some.inj #[h12])
      catch ex =>
        env.log fun _ => do return s!"contra: {d.userName} failed: {← ex.toMessageData.toString}"
        s.restore
  throwError "cir_lookup_contra: no contradiction found"

def logStats (env : Env) (what : String) (t0 : Nat) : MetaM Unit := do
  let (n, ms) ← env.stats.get
  if env.trace then
    elog s!"{what}: {(← IO.monoMsNow) - t0} ms, {n} omega calls ({ms} ms)"

/-- Close the goal from a failed liveness check or from equal block ids with
blocks of different kinds. -/
elab "cir_lookup_contra" : tactic => withMainContext do
  let t0 ← IO.monoMsNow
  let g ← getMainGoal
  let env ← mkEnv
  let pf ← contraProof env
  logStats env "cir_lookup_contra" t0
  g.assign (← mkFalseElim (← g.getType) pf)
  replaceMainGoal []

/-- Close `M x = some blk` (`blk` may contain metavariables, assigned from the lookup). -/
elab "cir_lookup_eq" : tactic => withMainContext do
  let t0 ← IO.monoMsNow
  let g ← getMainGoal
  let t := (← instantiateMVars (← g.getType)).consumeMData
  let some (_, lhs, _) := t.eq? | throwError "cir_lookup_eq: the goal is not an equation"
  let lhs := lhs.consumeMData
  unless lhs.isApp do throwError "cir_lookup_eq: the left side is not a lookup"
  let env ← mkEnv
  let (p, _) ← lookupCore env lhs.appFn! lhs.appArg! 0 []
  let pty ← inferType p
  -- the ghosts are goals of their own (synthetic opaque metavariables)
  unless ← withAssignableSyntheticOpaque (isDefEq pty t) do
    throwError "cir_lookup_eq: the lookup gives {pty}"
  logStats env "cir_lookup_eq" t0
  g.assign p
  replaceMainGoal []

/-! ### As a simproc

`lookupBlock*` replace a lookup `bs x` (a scope exit, a write or `Mem.blocks m`
applied to a block id) by its block when `lookupCore` proves it, and leave the
term alone otherwise. A liveness check `match bs x with …` then reduces by the
default simp set (matcher, `ite`, `Option.isSome_some`):
`simp only [lookupBlockKR, lookupBlockMem, lookupBlockUpd] at h; simp at h`
closes FA16's g0. The environment is collected per call (a scan of the local
context).

For the VCG (sketch): move this file into `CIR/Tactic` (imported by `VCG.lean`)
and add the three simprocs to `execNames` after `reduceUpd`/`reduceKillRange`
(the syntactic fast paths); in `cirHypsFV`, stop passing frames as rewrite
rules (hypotheses whose conclusion is `m.blocks b = …` with `b` a bound
variable, and `MemAgree`), since the simproc reads them from the context in a
fixed order; keep `killRange_apply`/`upd_apply` in the fallback set only. To
avoid one context scan per lookup, build the `Env` once per `cir_step` and keep
it in an `IO.Ref` keyed by the goal. -/

def lookupStep (e : Expr) : SimpM Simp.Step := do
  let e := e.consumeMData
  let isLookup := e.isAppOfArity ``CIR.killRange 4 || e.isAppOfArity ``CIR.Mem.blocks 2 ||
    (e.isAppOfArity ``CIR.upd 7 && (e.getArg! 0).isConstOf ``Nat && isOptBlock (e.getArg! 1))
  unless isLookup do return .continue
  let r? ← (do
      let env ← mkEnv
      observing? (lookupCore env e.appFn! e.appArg! 0 []) : MetaM (Option (Expr × Expr)))
  match r? with
  | some (p, v) => return .done { expr := v, proof? := some p }
  | none => return .continue

simproc_decl lookupBlockKR (killRange _ _ _ _) := lookupStep
simproc_decl lookupBlockMem (Mem.blocks _ _) := lookupStep
simproc_decl lookupBlockUpd (upd _ _ _ _) := lookupStep

end CIR.Lookup
