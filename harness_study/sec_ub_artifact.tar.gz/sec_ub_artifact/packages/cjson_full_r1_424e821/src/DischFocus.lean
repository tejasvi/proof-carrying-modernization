import CIR

/-! optim (2026-10-25): `omega_focus`: `omega` on the arithmetic hypotheses connected to the
goal. In the body goals of parse_array, `omega` fails on valid goals (an omega-internal atom
`Exists.choose _fvar…` makes its proof term ill-typed) and is slow with hundreds of
hypotheses; on the hypotheses that matter it works.

Steps: reduce projections of structure literals in the goal (`{ blocks := …, next := n }.next`),
keep the arithmetic hypotheses (in)equalities over `Int`/`Nat` with `¬ ∧ ∨ → ↔`) that share a
free variable with the goal, transitively, clear every other proposition, then `omega`. -/

namespace CIR.DischFocus
open Lean Meta Elab Tactic

/-- An (in)equality over `Int` or `Nat`, or a combination of such by `¬ ∧ ∨ → ↔`. -/
partial def isArith (t : Expr) : MetaM Bool := do
  let t := (← instantiateMVars t).consumeMData
  let intNat (ty : Expr) : MetaM Bool := do
    let ty ← whnfR ty
    return ty.isConstOf ``Int || ty.isConstOf ``Nat
  match t.getAppFnArgs with
  | (``Eq, #[ty, _, _]) => intNat ty
  | (``Ne, #[ty, _, _]) => intNat ty
  | (``LE.le, #[ty, _, _, _]) => intNat ty
  | (``LT.lt, #[ty, _, _, _]) => intNat ty
  | (``GE.ge, #[ty, _, _, _]) => intNat ty
  | (``GT.gt, #[ty, _, _, _]) => intNat ty
  | (``Dvd.dvd, #[ty, _, _, _]) => intNat ty
  | (``Not, #[p]) => isArith p
  | (``And, #[p, q]) => return (← isArith p) && (← isArith q)
  | (``Or, #[p, q]) => return (← isArith p) && (← isArith q)
  | (``Iff, #[p, q]) => return (← isArith p) && (← isArith q)
  | (``True, #[]) => return true
  | (``False, #[]) => return true
  | _ =>
    if t.isArrow then return (← isArith t.bindingDomain!) && (← isArith t.bindingBody!)
    else return false

/-- Clear the propositions that are not arithmetic facts connected to the goal. -/
def focusArith : TacticM Unit := do
  let g ← getMainGoal
  let g' ← g.withContext do
    let tgt ← instantiateMVars (← g.getType)
    let mut fvs : Std.HashSet FVarId := {}
    for f in (collectFVars {} tgt).fvarIds do fvs := fvs.insert f
    let lctx ← getLCtx
    let mut arith : Array (FVarId × Array FVarId) := #[]
    for d in lctx do
      if d.isImplementationDetail then continue
      if ← isProp d.type then
        if ← isArith d.type then
          arith := arith.push (d.fvarId, (collectFVars {} (← instantiateMVars d.type)).fvarIds)
    let mut keep : Std.HashSet FVarId := {}
    let mut changed := true
    while changed do
      changed := false
      for (h, xs) in arith do
        if keep.contains h then continue
        if xs.any (fvs.contains ·) then
          keep := keep.insert h
          for x in xs do fvs := fvs.insert x
          changed := true
    let mut drop : Array FVarId := #[]
    for d in lctx do
      if d.isImplementationDetail || keep.contains d.fvarId then continue
      if ← isProp d.type then drop := drop.push d.fvarId
    g.tryClearMany drop
  replaceMainGoal [g']

elab "cir_omega_focus" : tactic => do
  try evalTactic (← `(tactic| dsimp only)) catch _ => pure ()
  try evalTactic (← `(tactic| cir_strip_mdata)) catch _ => pure ()
  focusArith
  evalTactic (← `(tactic| omega))

end CIR.DischFocus

/-! The VCG's side-condition discharger with `cir_omega_focus` first: in
contexts with a hypothesis `A ∨ ∃ x, P x` plain `omega` builds an ill-typed
term and fails, so lookups through callee frames stopped. (Macro rules of
the same tactic are tried most recent first; on failure the original
`cir_disch` runs.) -/
macro_rules | `(tactic| cir_disch) => `(tactic| first | assumption | cir_omega_focus)
