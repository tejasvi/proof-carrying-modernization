import CIR
import VerifOrch.Cir.PrintSpecsN
import Strict

/-!
  `FH.EnsureSpec` and `FH.UpdateOffsetSpec` (veriforch's `VerifOrch.Cir.PrintSpecs`, PrintSpecs v4, sha256
  d2324d0a…, on cirlean pin c4ef58d; both statements are textually those of v2): cJSON's `ensure` (reaching
  `realloc` through the hooks' function pointer, an indirect call) and `update_offset` (`strlen` at the
  offset).

  Each postcondition without `m'.WF` (`EnsPost`, `UpdPost`) is proved by symbolic execution, case by case:
  the printbuffer record at `.loc pb []` or `.loc pb [.idx 0]`, and for `ensure` the buffer (the 1-byte object
  of `malloc(1)` or a byte array). `m'.WF` then comes from `Returns.wf` (`returns_of_wf`). The VCG leaves the
  postcondition at each exit; `ens_fail_*` (buffer unchanged, `NULL`), `ens_succ_old` (the old array has room),
  `ens_succ_new` (`realloc` to `INT_MAX` or `2 * needed` bytes, witnesses found by `ens_wit`) and `uo_close`
  (the offset moved to the string's NUL) close them. Two callee contracts are taken as local hypotheses:
  `realloc_obj_spec` (the 1-byte object; see there) and `strlen_spec` (the string at the offset).
-/

open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit

namespace FHW

/-- `EnsureSpec`'s postcondition without `m'.WF` (that comes from `Returns.wf`). -/
def EnsPost (pb : Nat) (pre : List PathElem) (kb : BlockKind) (buf : Ptr) (off d : Nat) (fmt : Int)
    (needed : Nat) (m : Mem) (r : Option Val) (m' : Mem) : Prop :=
  (m.next ≤ m'.next ∧ ∀ b, b < m.next → b ≠ pb → b ≠ FH.ptrBlock buf → m'.blocks b = m.blocks b) ∧
  ((r = some (.ptr .null) ∧ FH.PBOK m' pb pre kb fmt (FH.ptrBlock buf) m.next) ∨
   (∃ bb' len' vs', r = some (.ptr (.loc bb' [.idx off])) ∧
      FH.PBObj m' pb pre kb (.loc bb' [.idx 0]) len' off d fmt ∧
      m'.blocks bb' = some ⟨.heap, true, .array (.int false 8) len', .arr vs'⟩ ∧ vs'.length = len' ∧
      (∀ v ∈ vs', FH.OutByte v) ∧ off + needed + 1 ≤ len' ∧ len' < 2147483648 ∧
      (bb' = FH.ptrBlock buf ∨ m.next ≤ bb')))

/-- A postcondition whose part without `m'.WF` holds: `Returns.wf` adds the rest. -/
theorem returns_of_wf {ctx : Ctx} {sym : String} {args : List Val} {m : Mem}
    {post Q : Option Val → Mem → Prop} (h : Returns ctx sym args m post) (hwf : m.WF)
    (hq : ∀ v m', post v m' → m'.WF → Q v m') : Returns ctx sym args m Q := by
  have h2 := Returns.wf h hwf
  unfold Returns Calls at h2 ⊢
  refine Res.holds_mono h2 ?_
  rintro ⟨e, m'⟩ hh
  cases e with
  | ret v => exact hq v m' hh.1 hh.2
  | _ => exact hh

theorem outByte_take_replicate {vs : List Val} (hvs : ∀ v ∈ vs, FH.OutByte v) (a b : Nat) :
    ∀ v ∈ vs.take a ++ List.replicate b Val.undef, FH.OutByte v := by
  intro v hv
  rcases List.mem_append.mp hv with h | h
  · exact hvs v (List.mem_of_mem_take h)
  · rw [List.eq_of_mem_replicate h]
    exact Or.inl rfl

set_option maxHeartbeats 20000000 in
set_option cir.inline true in
/-- `realloc` of the 1-byte object of `malloc(1)` (typed `unsigned char`) to `n ≥ 1` bytes, with the new
contents abstract: the 1-byte-object case of `ensure` uses it as the callee's contract, so that its symbolic
execution never meets `List.replicate 2147483646 _` (the kernel cannot check the model's unfolding there). -/
theorem realloc_obj_spec (bb : Nat) (v : Val) (n : Int) (m : Mem) (hbn : bb < m.next)
    (hbb : m.blocks bb = some ⟨.heap, true, .int false 8, v⟩) (hv : FH.OutByte v) (hn : 1 ≤ n) :
    Returns ctx "realloc" [.ptr (.loc bb []), .int n] m (fun r m' =>
      ∃ L : List Val, r = some (.ptr (.loc m.next [.idx 0])) ∧ m'.next = m.next + 1 ∧
        m'.blocks m.next = some ⟨.heap, true, .array (.int false 8) n.toNat, .arr L⟩ ∧
        L.length = n.toNat ∧ (∀ x ∈ L, FH.OutByte x) ∧
        m'.blocks bb = some ⟨.heap, false, .int false 8, v⟩ ∧
        ∀ b, b ≠ m.next → b ≠ bb → m'.blocks b = m.blocks b) := by
  have hvs : ∀ x ∈ [v], FH.OutByte x := by simpa using hv
  cir_start
  cir_run
  all_goals (try (strict (simp only [bne_self_eq_false, Nat.mod_one, Bool.false_eq_true] at *)))
  all_goals (try (strict (simp only [Nat.div_one])))
  all_goals (try (strict (simp only [List.length_append, List.length_take, List.length_replicate,
    List.length_cons, List.length_nil]; omega)))
  all_goals (try (strict exact outByte_take_replicate hvs _ _ _ ‹_›))

open Lean Meta Elab Tactic in
/-- In a success goal `∃ bb' len' vs', …` after a `realloc`, the witnesses: the key, length and contents of
the live heap byte array that the memory term stores. -/
elab "ens_wit" : tactic => do
  let g ← getMainGoal
  g.withContext do
    let t ← instantiateMVars (← g.getType)
    let isBlk (b : Expr) : Option (Expr × Expr) := Id.run do
      let b := b.consumeMData
      unless b.isAppOfArity ``Option.some 2 do return none
      let blk := (b.getArg! 1).consumeMData
      unless blk.isAppOfArity ``CIR.MemBlock.mk 4 do return none
      unless (blk.getArg! 0).isConstOf ``CIR.BlockKind.heap && (blk.getArg! 1).isConstOf ``Bool.true do
        return none
      let ty := (blk.getArg! 2).consumeMData
      let v := (blk.getArg! 3).consumeMData
      unless ty.isAppOfArity ``CIR.Ty.array 2 && v.isAppOfArity ``CIR.Val.arr 1 do return none
      return some (ty.getArg! 1, v.getArg! 0)
    -- a block the memory term stores (the inlined model), else a callee's postcondition fact
    -- `mem.blocks k = some ⟨.heap, true, .array _ n, .arr l⟩`
    let fromGoal := (t.find? fun e =>
        e.getAppFn.isConstOf ``CIR.upd && e.getAppNumArgs ≥ 6 && (isBlk (e.getArg! 5)).isSome).bind
      fun e => (isBlk (e.getArg! 5)).map fun (n, l) => (e.getArg! 4, n, l)
    let mut found := fromGoal
    if found.isNone then
      for d in ← getLCtx do
        if d.isImplementationDetail then continue
        let ty ← instantiateMVars d.type
        let some (_, lhs, rhs) := ty.eq? | continue
        unless lhs.isAppOfArity ``CIR.Mem.blocks 2 do continue
        if let some (n, l) := isBlk rhs then found := some (lhs.getArg! 1, n, l)
    let some (k, n, l) := found | throwError "ens_wit: no live heap array"
    let kS ← Term.exprToSyntax k
    let nS ← Term.exprToSyntax n
    let lS ← Term.exprToSyntax l
    evalTactic (← `(tactic| refine ⟨$kS, $nS, $lS, ?_⟩))

/-- Equations between equal terms or arithmetic (the printbuffer's fields; no default `simp`: it would
unfold `List.replicate` of a literal length). -/
macro "ens_eqs" : tactic => `(tactic| (
  try simp only [Val.arr.injEq, Val.agg.injEq, List.cons.injEq, Val.int.injEq, Val.ptr.injEq,
    Ptr.loc.injEq, PathElem.idx.injEq, MemBlock.mk.injEq, Option.some.injEq, eq_self_iff_true,
    and_self, and_true, true_and]
  repeat' (apply And.intro)
  all_goals (first | with_reducible rfl | (cir_strip_mdata; omega))))

/-- The printbuffer's part of a postcondition: one disjunct of `PBObj` (by the record's path), its fields. -/
macro "ens_pbo" : tactic => `(tactic| first
  | (simp only [eq_self_iff_true, and_self, and_true, true_and, or_false, false_or, true_or, or_true]; done)
  | (refine Or.inl ?_; ens_eqs)
  | (refine Or.inr ?_; ens_eqs))

set_option hygiene false in
/-- One conjunct of a success postcondition. (`rfl` and `assumption` only up to reducible unfolding: at
default transparency they would evaluate `List.replicate` of the literal length `2147483646`.) -/
macro "ens_leaf" : tactic => `(tactic| first
  | with_reducible rfl
  | with_reducible assumption
  | (cir_strip_mdata; omega)
  | (refine Or.inr ?_; cir_strip_mdata; omega)
  | exact outByte_take_replicate hvs _ _
  | (simp only [List.length_append, List.length_take, List.length_replicate, List.length_cons,
      List.length_nil, hvl]; cir_strip_mdata; omega)
  | (cir_exec_pure_main; done)
  | ens_pbo
  | (simp only [Int.zero_add, Int.toNat_natCast, PathElem.idx.injEq]; done)
  | (cir_exec_pure_fallback; done))

set_option hygiene false in
/-- A fail exit of the byte-array case: `NULL`, the printbuffer and its buffer unchanged. -/
macro "ens_fail_arr" : tactic => `(tactic| strict
  refine Or.inl ⟨.loc bb [.idx 0], len, off, d, ⟨hkb, ?ens_pbo⟩,
    Or.inr ⟨vs, Or.inr ⟨bb, rfl, ?ens_lk, hvl, hvs⟩, Or.inl rfl⟩⟩
  case ens_pbo => ens_pbo
  case ens_lk => first | cir_exec_pure_main | cir_exec_pure_fallback)

set_option hygiene false in
/-- A fail exit of the 1-byte-object case. -/
macro "ens_fail_obj" : tactic => `(tactic| strict
  refine Or.inl ⟨.loc bb [], 1, off, d, ⟨hkb, ?ens_pbo⟩,
    Or.inr ⟨[v], Or.inl ⟨bb, v, rfl, rfl, rfl, ?ens_lk, hv⟩, Or.inl rfl⟩⟩
  case ens_pbo => ens_pbo
  case ens_lk => first | cir_exec_pure_main | cir_exec_pure_fallback)

set_option hygiene false in
/-- The success exit without reallocation (byte-array case): the old buffer has room. -/
macro "ens_succ_old" : tactic => `(tactic| strict
  refine Or.inr ⟨bb, len, vs, ⟨rfl, ?ens_i⟩, ⟨hkb, ?ens_pbo⟩, ?ens_lk, hvl, hvs, ?ens_a, hlen,
    Or.inl rfl⟩
  case ens_i => simp only [Int.zero_add, Int.toNat_natCast]
  case ens_pbo => ens_pbo
  case ens_a => (cir_strip_mdata; omega)
  case ens_lk => first | cir_exec_pure_main | cir_exec_pure_fallback)

/-- The success exits after `realloc`: the fresh byte array. -/
macro "ens_succ_new" : tactic => `(tactic| strict
  refine Or.inr ?_
  ens_wit
  repeat' (apply And.intro)
  all_goals ens_leaf)

/-- The exits the VCG leaves: arithmetic side conditions and contradictory paths, then the postconditions. -/
macro "ens_close" : tactic => `(tactic| (
  all_goals (try cir_subst_nat)
  all_goals (try (strict with_reducible assumption))
  all_goals (try (strict (cir_strip_mdata; omega)))
  all_goals (try (strict (simp only [List.length_append, List.length_take, List.length_replicate,
    List.length_cons, List.length_nil] at *; cir_strip_mdata; omega)))
  all_goals (try (strict (simp only [Nat.mod_one, bne_self_eq_false, Bool.false_eq_true] at *)))
  all_goals (try ens_fail_arr)
  all_goals (try ens_fail_obj)
  all_goals (try ens_succ_old)
  all_goals (try ens_succ_new)))

section cases

variable (pb : Nat) (kb : BlockKind) (bb off d : Nat) (fmt : Int) (needed : Nat) (m : Mem)

set_option maxHeartbeats 20000000 in
set_option cir.inline true in
theorem ens_arr0 (len : Nat) (vs : List Val) (hwf : m.WF) (hpb : pb < m.next) (hbb : bb < m.next)
    (hne : pb ≠ bb) (hkb : kb ≠ .readonly)
    (hpbm : m.blocks pb = some ⟨kb, true, .record "printbuffer",
      .agg [.ptr (.loc bb [.idx 0]), .int len, .int off, .int d, .int 0, .int fmt,
        .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩)
    (hbbm : m.blocks bb = some ⟨.heap, true, .array (.int false 8) len, .arr vs⟩)
    (hvl : vs.length = len) (hvs : ∀ v ∈ vs, FH.OutByte v) (hoff : off < len) (hlen : len < 2147483648)
    (hneed64 : needed < 18446744073709551616) :
    Returns ctx fn_cJSON_ensure.sym [.ptr (.loc pb []), .int needed] m
      (EnsPost pb [] kb (.loc bb [.idx 0]) off d fmt needed m) := by
  delta EnsPost
  simp only [FH.PBOK, FH.PBObj, FH.PBData, FH.pbRec, FH.hooksVal, FH.ptrBlock]
  cir_start
  cir_run
  ens_close

set_option maxHeartbeats 20000000 in
set_option cir.inline true in
theorem ens_arr1 (len : Nat) (vs : List Val) (hwf : m.WF) (hpb : pb < m.next) (hbb : bb < m.next)
    (hne : pb ≠ bb) (hkb : kb ≠ .readonly)
    (hpbm : m.blocks pb = some ⟨kb, true, .array (.record "printbuffer") 1,
      .arr [.agg [.ptr (.loc bb [.idx 0]), .int len, .int off, .int d, .int 0, .int fmt,
        .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]]⟩)
    (hbbm : m.blocks bb = some ⟨.heap, true, .array (.int false 8) len, .arr vs⟩)
    (hvl : vs.length = len) (hvs : ∀ v ∈ vs, FH.OutByte v) (hoff : off < len) (hlen : len < 2147483648)
    (hneed64 : needed < 18446744073709551616) :
    Returns ctx fn_cJSON_ensure.sym [.ptr (.loc pb [.idx 0]), .int needed] m
      (EnsPost pb [.idx 0] kb (.loc bb [.idx 0]) off d fmt needed m) := by
  delta EnsPost
  simp only [FH.PBOK, FH.PBObj, FH.PBData, FH.pbRec, FH.hooksVal, FH.ptrBlock]
  cir_start
  cir_run
  ens_close

set_option maxHeartbeats 20000000 in
set_option cir.inline true in
theorem ens_obj0 (v : Val) (hwf : m.WF) (hpb : pb < m.next) (hbb : bb < m.next)
    (hne : pb ≠ bb) (hkb : kb ≠ .readonly)
    (hpbm : m.blocks pb = some ⟨kb, true, .record "printbuffer",
      .agg [.ptr (.loc bb []), .int 1, .int off, .int d, .int 0, .int fmt,
        .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩)
    (hbbm : m.blocks bb = some ⟨.heap, true, .int false 8, v⟩) (hv : FH.OutByte v)
    (hoff : off < 1) (hneed : 1 ≤ needed) (hneed64 : needed < 18446744073709551616) :
    Returns ctx fn_cJSON_ensure.sym [.ptr (.loc pb []), .int needed] m
      (EnsPost pb [] kb (.loc bb []) off d fmt needed m) := by
  have hvs : ∀ x ∈ [v], FH.OutByte x := by simpa using hv
  have hvl : [v].length = 1 := rfl
  have hlen : 1 < 2147483648 := by omega
  have hra := @realloc_obj_spec
  delta EnsPost
  simp only [FH.PBOK, FH.PBObj, FH.PBData, FH.pbRec, FH.hooksVal, FH.ptrBlock]
  cir_start
  cir_run
  ens_close

set_option maxHeartbeats 20000000 in
set_option cir.inline true in
theorem ens_obj1 (v : Val) (hwf : m.WF) (hpb : pb < m.next) (hbb : bb < m.next)
    (hne : pb ≠ bb) (hkb : kb ≠ .readonly)
    (hpbm : m.blocks pb = some ⟨kb, true, .array (.record "printbuffer") 1,
      .arr [.agg [.ptr (.loc bb []), .int 1, .int off, .int d, .int 0, .int fmt,
        .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]]⟩)
    (hbbm : m.blocks bb = some ⟨.heap, true, .int false 8, v⟩) (hv : FH.OutByte v)
    (hoff : off < 1) (hneed : 1 ≤ needed) (hneed64 : needed < 18446744073709551616) :
    Returns ctx fn_cJSON_ensure.sym [.ptr (.loc pb [.idx 0]), .int needed] m
      (EnsPost pb [.idx 0] kb (.loc bb []) off d fmt needed m) := by
  have hvs : ∀ x ∈ [v], FH.OutByte x := by simpa using hv
  have hvl : [v].length = 1 := rfl
  have hlen : 1 < 2147483648 := by omega
  have hra := @realloc_obj_spec
  delta EnsPost
  simp only [FH.PBOK, FH.PBObj, FH.PBData, FH.pbRec, FH.hooksVal, FH.ptrBlock]
  cir_start
  cir_run
  ens_close

end cases

/-! ### `update_offset` -/

theorem cstr_findIdx {vs : List Val} {off k : Nat} (hk : off + k < vs.length)
    (hz : vs[off + k]? = some (.int 0))
    (hnz : ∀ j, j < k → ∃ c : Int, vs[off + j]? = some (.int c) ∧ c ≠ 0) :
    (vs.drop off).findIdx? Std.isNulVal = some k := by
  have hlen : k < (vs.drop off).length := by rw [List.length_drop]; omega
  rw [List.findIdx?_eq_some_iff_getElem]
  refine ⟨hlen, ?_, ?_⟩
  · have h1 : (vs.drop off)[k]? = some (.int 0) := by rw [List.getElem?_drop]; exact hz
    rw [List.getElem?_eq_getElem hlen, Option.some.injEq] at h1
    rw [h1]
    rfl
  · intro j hj
    obtain ⟨c, hc, hc0⟩ := hnz j hj
    have h1 : (vs.drop off)[j]? = some (.int c) := by rw [List.getElem?_drop]; exact hc
    rw [List.getElem?_eq_getElem (by omega), Option.some.injEq] at h1
    rw [h1]
    simp [Std.isNulVal, hc0]

theorem cstr_all {vs : List Val} {off k : Nat}
    (hnz : ∀ j, j < k → ∃ c : Int, vs[off + j]? = some (.int c) ∧ c ≠ 0) :
    ((vs.drop off).take k).all Std.isIntVal = true := by
  rw [List.all_eq_true]
  intro x hx
  obtain ⟨i, hi⟩ := List.mem_iff_getElem?.mp hx
  rw [List.getElem?_take] at hi
  split at hi
  · rw [List.getElem?_drop] at hi
    obtain ⟨c, hc, _⟩ := hnz i ‹_›
    rw [hc] at hi
    cases hi
    rfl
  · cases hi

set_option maxHeartbeats 20000000 in
set_option cir.inline true in
/-- `strlen` on a NUL-terminated string at index `off` of an array block: `k`, its length (the facts
about `findIdx?` and `all` that the model's `readCStr` asks for are `cirH_` rewrite rules of the VCG). -/
theorem strlen_spec (bb : Nat) (bk : BlockKind) (ty : Ty) (vs : List Val) (off k : Nat) (m : Mem)
    (hbb : m.blocks bb = some ⟨bk, true, ty, .arr vs⟩) (hk : off + k < vs.length)
    (hz : vs[off + k]? = some (.int 0))
    (hnz : ∀ j, j < k → ∃ c : Int, vs[off + j]? = some (.int c) ∧ c ≠ 0) :
    Returns ctx "strlen" [.ptr (.loc bb [.idx off])] m (fun r m' => r = some (.int k) ∧ m' = m) := by
  have cirH_find := cstr_findIdx hk hz hnz
  have cirH_all := cstr_all (vs := vs) (off := off) hnz
  have cirH_len : ((vs.drop off).take k).length = k := by
    simp only [List.length_take, List.length_drop]
    omega
  cir_start
  cir_run

/-- `UpdateOffsetSpec`'s postcondition without `m'.WF`. -/
def UpdPost (pb : Nat) (pre : List PathElem) (kb : BlockKind) (bb len off d : Nat) (fmt : Int)
    (vs : List Val) (m : Mem) (r : Option Val) (m' : Mem) : Prop :=
  r = none ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → b ≠ pb → m'.blocks b = m.blocks b) ∧
    ∃ off', off ≤ off' ∧ off' < len ∧ vs[off']? = some (.int 0) ∧
      FH.PBObj m' pb pre kb (.loc bb [.idx 0]) len off' d fmt

set_option hygiene false in
/-- The exits update_offset's VCG leaves: index arithmetic, then the offset moved to the NUL (`off + k`). -/
macro "uo_close" : tactic => `(tactic| (
  all_goals (try (strict (cir_strip_mdata; omega)))
  all_goals (try (strict
    refine ⟨off + k, ?uo_a, ?uo_b, hz, hkb, ?uo_c⟩
    case uo_a => (cir_strip_mdata; omega)
    case uo_b => (cir_strip_mdata; omega)
    case uo_c => ens_pbo))))

/-- `strlen`'s contract at the string of the buffer, for any index equal to `off`. -/
theorem strlen_at {bb len off k : Nat} {vs : List Val} (hk : off + k < vs.length)
    (hz : vs[off + k]? = some (.int 0))
    (hnz : ∀ j, j < k → ∃ c : Int, vs[off + j]? = some (.int c) ∧ c ≠ 0) :
    ∀ (i : Nat) (m' : Mem), i = off →
      m'.blocks bb = some ⟨.heap, true, .array (.int false 8) len, .arr vs⟩ →
      Returns ctx "strlen" [.ptr (.loc bb [.idx i])] m' (fun r m'' => r = some (.int k) ∧ m'' = m') := by
  intro i m' hi hb
  subst hi
  exact strlen_spec bb .heap _ vs i k m' hb hk hz hnz

section uo

variable (pb : Nat) (kb : BlockKind) (bb len off d : Nat) (fmt : Int) (vs : List Val) (m : Mem) (k : Nat)

set_option maxHeartbeats 20000000 in
set_option cir.inline true in
theorem uo_case0 (_hwf : m.WF) (hpb : pb < m.next) (hbb : bb < m.next) (_hne : pb ≠ bb)
    (hkb : kb ≠ .readonly)
    (hpbm : m.blocks pb = some ⟨kb, true, .record "printbuffer",
      .agg [.ptr (.loc bb [.idx 0]), .int len, .int off, .int d, .int 0, .int fmt,
        .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]⟩)
    (hbbm : m.blocks bb = some ⟨.heap, true, .array (.int false 8) len, .arr vs⟩)
    (hvl : vs.length = len) (hk : off + k < vs.length) (hz : vs[off + k]? = some (.int 0))
    (hnz : ∀ j, j < k → ∃ c : Int, vs[off + j]? = some (.int c) ∧ c ≠ 0) (hlen : len < 2147483648) :
    Returns ctx fn_cJSON_update_offset.sym [.ptr (.loc pb [])] m
      (UpdPost pb [] kb bb len off d fmt vs m) := by
  have hsl := strlen_at (bb := bb) (len := len) hk hz hnz
  delta UpdPost
  simp only [FH.PBObj, FH.pbRec, FH.hooksVal]
  cir_start
  cir_run
  uo_close

set_option maxHeartbeats 20000000 in
set_option cir.inline true in
theorem uo_case1 (_hwf : m.WF) (hpb : pb < m.next) (hbb : bb < m.next) (_hne : pb ≠ bb)
    (hkb : kb ≠ .readonly)
    (hpbm : m.blocks pb = some ⟨kb, true, .array (.record "printbuffer") 1,
      .arr [.agg [.ptr (.loc bb [.idx 0]), .int len, .int off, .int d, .int 0, .int fmt,
        .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]]]⟩)
    (hbbm : m.blocks bb = some ⟨.heap, true, .array (.int false 8) len, .arr vs⟩)
    (hvl : vs.length = len) (hk : off + k < vs.length) (hz : vs[off + k]? = some (.int 0))
    (hnz : ∀ j, j < k → ∃ c : Int, vs[off + j]? = some (.int c) ∧ c ≠ 0) (hlen : len < 2147483648) :
    Returns ctx fn_cJSON_update_offset.sym [.ptr (.loc pb [.idx 0])] m
      (UpdPost pb [.idx 0] kb bb len off d fmt vs m) := by
  have hsl := strlen_at (bb := bb) (len := len) hk hz hnz
  delta UpdPost
  simp only [FH.PBObj, FH.pbRec, FH.hooksVal]
  cir_start
  cir_run
  uo_close

end uo

end FHW

open FHW in
theorem ensure_spec : FH.EnsureSpec := by
  intro pb pre kb buf len off d fmt vs needed m hwf hpb hbuf hne hobj hdata hoff hlen hneed hneed64
  refine returns_of_wf (post := EnsPost pb pre kb buf off d fmt needed m) ?_ hwf
    (fun r m' h hw => by obtain ⟨⟨h1, h2⟩, h3⟩ := h; exact ⟨⟨hw, h1, h2⟩, h3⟩)
  obtain ⟨hkb, ⟨rfl, hpbm⟩ | ⟨rfl, hpbm⟩⟩ := hobj <;>
    obtain ⟨bb, v, rfl, rfl, rfl, hbbm, hv⟩ | ⟨bb, rfl, hbbm, hvl, hvs⟩ := hdata <;>
    simp only [FH.pbRec, FH.hooksVal, FH.ptrBlock] at hpbm hbuf hne
  · have h1 : 1 ≤ needed := by
      rcases hneed with h | ⟨_, h⟩
      · exact h
      · cases h
    exact ens_obj0 pb kb bb off d fmt needed m v hwf hpb hbuf hne hkb hpbm hbbm hv hoff h1 hneed64
  · exact ens_arr0 pb kb bb off d fmt needed m len vs hwf hpb hbuf hne hkb hpbm hbbm hvl hvs hoff hlen
      hneed64
  · have h1 : 1 ≤ needed := by
      rcases hneed with h | ⟨_, h⟩
      · exact h
      · cases h
    exact ens_obj1 pb kb bb off d fmt needed m v hwf hpb hbuf hne hkb hpbm hbbm hv hoff h1 hneed64
  · exact ens_arr1 pb kb bb off d fmt needed m len vs hwf hpb hbuf hne hkb hpbm hbbm hvl hvs hoff hlen
      hneed64

open FHW in
theorem update_offset_spec : FH.UpdateOffsetSpec := by
  intro pb pre kb bb len off d fmt vs m hwf hpb hbb hne hobj hbbm hvl hcs hlen
  obtain ⟨k, hk, hz, hnz⟩ := hcs
  refine returns_of_wf (post := UpdPost pb pre kb bb len off d fmt vs m) ?_ hwf
    (fun r m' h hw => by obtain ⟨h1, h2, h3, h4⟩ := h; exact ⟨h1, hw, h2, h3, h4⟩)
  obtain ⟨hkb, ⟨rfl, hpbm⟩ | ⟨rfl, hpbm⟩⟩ := hobj <;> simp only [FH.pbRec, FH.hooksVal] at hpbm
  · exact uo_case0 pb kb bb len off d fmt vs m k hwf hpb hbb hne hkb hpbm hbbm hvl hk hz hnz hlen
  · exact uo_case1 pb kb bb len off d fmt vs m k hwf hpb hbb hne hkb hpbm hbbm hvl hk hz hnz hlen

#print axioms ensure_spec
#print axioms update_offset_spec
