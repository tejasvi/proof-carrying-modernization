import GivenPA.Instr2

namespace Instr2
open Lean Meta Elab Tactic

/-- Export every goal as a theorem (proved by `sorry`), closed over its
context. Goals with metavariables (a callee's ghost values not yet found)
are grouped by shared metavariables, and each group becomes one theorem
`∃ ghosts, (∀ ctx₁, G₁) ∧ … ∧ (∀ ctxₙ, Gₙ)`. Goals that are not propositions
(the ghosts themselves) are only listed. -/
elab "m2_export4 " n:ident : tactic => do
  let gs ← getGoals
  let pre := (← Lean.Elab.Term.getDeclName?).getD .anonymous
  -- closed types
  let mut closed : Array (Nat × Expr) := #[]
  let mut i := 0
  for g in gs do
    let ok ← g.withContext do isProp (← instantiateMVars (← g.getType))
    if ok then
      let ty ← g.withContext do
        let t ← instantiateMVars (← g.getType)
        let fvars := (← getLCtx).foldl (init := #[]) fun acc d =>
          if d.isImplementationDetail then acc else acc.push d.toExpr
        instantiateMVars (← mkForallFVars fvars t)
      closed := closed.push (i, ty)
    else
      elog s!"goal {i} is data: {← g.withContext do ppExpr (← instantiateMVars (← g.getType))}"
    i := i + 1
  -- groups by shared metavariables (goals without any: alone)
  let mut groups : Array (Array (Nat × Expr)) := #[]
  let mut groupMVars : Array (Array MVarId) := #[]
  for (j, ty) in closed do
    let ms := (← getMVars ty)
    if ms.isEmpty then
      groups := groups.push #[(j, ty)]
      groupMVars := groupMVars.push #[]
      continue
    -- merge every group sharing a metavariable
    let mut merged : Array (Nat × Expr) := #[(j, ty)]
    let mut mergedM : Array MVarId := ms
    let mut keepG : Array (Array (Nat × Expr)) := #[]
    let mut keepM : Array (Array MVarId) := #[]
    for k in [0:groups.size] do
      if groupMVars[k]!.any (ms.contains ·) then
        merged := merged ++ groups[k]!
        mergedM := mergedM ++ groupMVars[k]!.filter (!mergedM.contains ·)
      else
        keepG := keepG.push groups[k]!
        keepM := keepM.push groupMVars[k]!
    groups := keepG.push merged
    groupMVars := keepM.push mergedM
  let mut c := 0
  for grp in groups do
    let body ← if grp.size == 1 then pure grp[0]!.2 else
      grp.foldlM (init := (none : Option Expr)) (fun acc (_, t) => do
        match acc with
        | none => pure (some t)
        | some a => pure (some (← mkAppM ``And #[a, t]))) >>= fun o => pure o.get!
    let body ← instantiateMVars body
    let stmt ← if !body.hasExprMVar then pure body else do
      let r ← abstractMVars body
      -- `fun ghosts => body` as `∃ ghosts, body`
      lambdaBoundedTelescope r.expr r.numMVars fun xs b => do
        let mut e := b
        for x in xs.reverse do
          e ← mkAppM ``Exists #[← mkLambdaFVars #[x] e]
        pure e
    let name := pre ++ n.getId ++ Name.mkSimple s!"c{c}"
    try
      addDecl (.thmDecl { name, levelParams := [], type := stmt, value := ← mkSorry stmt false })
      elog s!"exported {name}: goals {grp.map (·.1)}"
    catch ex =>
      elog s!"export of {name} (goals {grp.map (·.1)}) failed: {← ex.toMessageData.toString}"
    c := c + 1

end Instr2
