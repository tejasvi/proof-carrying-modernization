import FHEntryEarly
import FHEntryB1
import FHEntryF1
import FHEntryF0

open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit

namespace FHEntry

set_option maxHeartbeats 4000000

/-- The full harness's entry point: the mechanical statement, from the case lemmas. -/
theorem entry_main (h_cJSON_ParseWithOpts : ∀ (bc base bg be : Nat) (kc kg ke : BlockKind) (ev : Val) (xs : List Int) (rnt : Int) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (he : ctx.gaddr "cJSON$global_error" = some be) (hbe : be < m.next) (hke : ke ≠ .readonly) (hev : m.blocks be = some ⟨ke, true, .record "error", ev⟩) (hevs : ∃ ej ep, ev = .agg [ej, ep]) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hz : ∃ k, base + k < xs.length ∧ xs[base + k]? = some 0) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hrnt : -2147483648 ≤ rnt ∧ rnt ≤ 2147483647) (hd1 : bg ≠ bc) (hd2 : be ≠ bc) (hd3 : bg ≠ be), Returns ctx fn_cJSON_ParseWithOpts.sym [.ptr (.loc bc [.idx base]), .ptr .null, .int rnt] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ be → m'.blocks b' = m.blocks b') ∧ (∃ ev', m'.blocks be = some ⟨ke, true, .record "error", ev'⟩) ∧ (r = some (.ptr .null) ∨ ∃ t : CJ, r = some (.ptr (listPtr [t.b] 0)) ∧ CJForest m' [t] ∧ (CJ.forestBlocks [t]).Nodup ∧ (∀ x ∈ CJ.forestBlocks [t], m.next ≤ x ∧ x < m'.next) ∧ CJ.forestPrintable xs.length [t] ∧ CJ.forestHeight [t] ≤ 1001))) (h_cJSON_PrintBuffered : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001) (fmt : Int) (hfmt : fmt = 0 ∨ fmt = 1), Returns ctx fn_cJSON_PrintBuffered.sym [.ptr (.loc t.b []), .int 1, .int fmt] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_Print : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001), Returns ctx fn_cJSON_Print.sym [.ptr (.loc t.b [])] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_PrintUnformatted : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001), Returns ctx fn_cJSON_PrintUnformatted.sym [.ptr (.loc t.b [])] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_Minify : FH.MinifySpec) (h_cJSON_Delete : ∀ (bg : Nat) (kg : BlockKind) (a r : Val) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (ts : List CJ) (m : Mem) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [a, .ptr (.fn "free"), r]⟩) (hgn : bg ∉ CJ.forestBlocks ts), Returns ctx fn_cJSON_Delete.sym [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF)) (data : Ptr) (size : Int) (m : Mem) (hm : VerifOrch.Cir.InitExt module m) (hsize : 0 ≤ size ∧ size ≤ 18446744073709551615) (hbuf : VerifOrch.Cir.ReadableBuf module.initMem.next m data size) (hsmall : size < 2 ^ 61) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr data, .int size] m (fun _ _ => True) := by
  obtain ⟨hwf, hnext, hinit⟩ := hm
  obtain ⟨hs0, hs63, b, blk, ys, rfl, hlo, hlive, hty, hval, hlen, helem⟩ := hbuf
  have hb : m.blocks b = some blk ∧ blk.alive = true := by
    unfold Mem.live? at hlive
    revert hlive
    cases h : m.blocks b with
    | none => intro hlive; cases hlive
    | some blk' =>
      intro hlive
      simp only at hlive
      split at hlive
      · cases hlive; exact ⟨rfl, ‹_›⟩
      · cases hlive
  obtain ⟨kd, al, bty, bval⟩ := blk
  simp only at hty hval hb
  subst hty hval
  obtain ⟨hbm, rfl⟩ := hb
  have hys : ∃ xs : List Int, ys = xs.map Val.int ∧ ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255 := by
    refine ⟨ys.map (fun v => match v with | .int k => k | _ => 0), ?_, ?_⟩
    · apply List.ext_getElem?
      intro j
      rw [List.getElem?_map, List.getElem?_map]
      by_cases hj : j < ys.length
      · obtain ⟨k, hk, -⟩ := helem j (by omega)
        rw [hk]; rfl
      · rw [List.getElem?_eq_none (by omega)]; rfl
    · intro x hx
      obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hx
      obtain ⟨j, hj, rfl⟩ := List.getElem_of_mem hv
      obtain ⟨k, hk, hk0, hk1⟩ := helem j (by omega)
      rw [List.getElem?_eq_getElem hj] at hk
      injection hk with hk
      rw [hk]
      exact ⟨hk0, hk1⟩
  obtain ⟨xs, rfl, hxs⟩ := hys
  simp only [List.length_map] at hlen hbm
  by_cases hsz : size ≤ 4
  · exact case_small size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsz
  have hsz' : 4 < size := by omega
  have hl : 4 < xs.length := by omega
  by_cases hb0 : xs[0]? = some 48 ∨ xs[0]? = some 49
  case neg => exact case_bad0 size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsz' ⟨fun h => hb0 (Or.inl h), fun h => hb0 (Or.inr h)⟩
  by_cases hb3 : xs[3]? = some 48 ∨ xs[3]? = some 49
  case neg => exact case_bad3 size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsz' ⟨fun h => hb3 (Or.inl h), fun h => hb3 (Or.inr h)⟩
  rcases hb3 with hb3 | hb3
  · by_cases hb2 : xs[2]? = some 48 ∨ xs[2]? = some 49
    case neg => exact case_bad2 size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsz' ⟨fun h => hb2 (Or.inl h), fun h => hb2 (Or.inr h)⟩
    rcases hb2 with hb2 | hb2 <;> rcases hb0 with hb0 | hb0
    · exact case_b0_f0_m0 h_cJSON_ParseWithOpts h_cJSON_PrintBuffered h_cJSON_Print h_cJSON_PrintUnformatted h_cJSON_Minify h_cJSON_Delete size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsize hsmall hb0 hb2 hb3
    · exact case_b0_f0_m1 h_cJSON_ParseWithOpts h_cJSON_PrintBuffered h_cJSON_Print h_cJSON_PrintUnformatted h_cJSON_Minify h_cJSON_Delete size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsize hsmall hb0 hb2 hb3
    · exact case_b0_f1_m0 h_cJSON_ParseWithOpts h_cJSON_PrintBuffered h_cJSON_Print h_cJSON_PrintUnformatted h_cJSON_Minify h_cJSON_Delete size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsize hsmall hb0 hb2 hb3
    · exact case_b0_f1_m1 h_cJSON_ParseWithOpts h_cJSON_PrintBuffered h_cJSON_Print h_cJSON_PrintUnformatted h_cJSON_Minify h_cJSON_Delete size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsize hsmall hb0 hb2 hb3
  · rcases hb0 with hb0 | hb0
    · exact case_b1_m0 h_cJSON_ParseWithOpts h_cJSON_PrintBuffered h_cJSON_Print h_cJSON_PrintUnformatted h_cJSON_Minify h_cJSON_Delete size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsize hsmall hb0 hb3
    · exact case_b1_m1 h_cJSON_ParseWithOpts h_cJSON_PrintBuffered h_cJSON_Print h_cJSON_PrintUnformatted h_cJSON_Minify h_cJSON_Delete size m b kd xs hwf hnext hinit hs0 hs63 hlo hlen hbm hxs hsize hsmall hb0 hb3

end FHEntry
