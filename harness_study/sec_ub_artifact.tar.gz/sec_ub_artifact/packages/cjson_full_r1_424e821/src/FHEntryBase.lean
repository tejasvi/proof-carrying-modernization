import CIR
import CIR.Logic.CJTree
import VerifOrch.Cir.CJPrintN
import VerifOrch.Cir.PrintSpecsN
import VerifOrch.Cir.Entry
import Gen.v0_fuzzing_cjson_read_fuzzer.Unit

/-! FH (worker-fh-3): the full harness's entry LLVMFuzzerTestOneInput (cJSON 1.7.18 fuzzing/cjson_read_fuzzer.c), proved
case by case: one declaration per case of the flag bytes data[0] (minify), data[2] (formatted) and data[3] (buffered)
in modules FHEntryB1, FHEntryF1, FHEntryF0 (data[1], require_termination, stays symbolic), the early returns in
FHEntryEarly, and `entry_main` in FHEntry, by case analysis over the input. Each case symbolically executes the whole
harness with its flag facts in context. Callee contracts are explicit hypotheses whose texts are the callees' given
statements. This module: rewriting lemmas for the flag selects (`data[k] == '1' ? 1 : 0`). -/

open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit

namespace FHEntry

theorem ite_val_int01 (c : Prop) [Decidable c] (a b : Int) :
    (if c then Val.int a else Val.int b) = Val.int (if c then a else b) := by
  by_cases hc : c <;> simp [hc]

theorem inRange_ite01 (c : Prop) [Decidable c] : inRange true 32 (if c then 1 else 0) = true := by
  by_cases hc : c <;> simp [hc] <;> decide

theorem fitsTy_sel01 (c : Prop) [Decidable c] :
    fitsTy (.int true 32) (if c then Val.int 1 else Val.int 0) = true := by
  by_cases hc : c <;> simp [hc, fitsTy, inRange]

end FHEntry

theorem typedRange_block {ctx : Ctx} {m : Mem} {b : Nat} {p : List PathElem} {n : Int}
    {r : Nat × List PathElem × Option Nat × Nat × Ty}
    (h : Std.typedRange? ctx m (.loc b p) n = some r) : r.1 = b := by
  have hw : ∀ (ty : Ty) (r' : Nat × List PathElem × Option Nat × Nat × Ty),
      (match ctx.typeAt ty p with
       | some t => match ctx.sizeAlign 32 t with | some (sz, _) => if (sz : Int) = n then some (b, p, none, 1, t) else none | none => none
       | none => none) = some r' → r'.1 = b := by
    intro ty r' hr'
    split at hr' <;> try contradiction
    split at hr' <;> try contradiction
    split at hr' <;> (try cases hr'; rfl) <;> contradiction
  unfold Std.typedRange? at h
  dsimp only at h
  rcases h1 : m.blocks b with _ | blk <;> rw [h1] at h
  · contradiction
  · dsimp only at h
    split at h <;> try exact hw _ _ h
    split at h <;> try exact hw _ _ h
    split at h <;> try exact hw _ _ h
    split at h
    · cases h; rfl
    · exact hw _ _ h

theorem FHEntry.memcpyOverlap_diff_block {ctx : Ctx} {m : Mem} {b1 b2 : Nat} {p1 p2 : List PathElem} {n : Int}
    (h : b2 ≠ b1) : Std.memcpyOverlap ctx m (.loc b1 p1) (.loc b2 p2) n = false := by
  unfold Std.memcpyOverlap
  split
  · rfl
  · split
    · rename_i rs rd hrs hrd
      have h1 := typedRange_block hrs
      have h2 := typedRange_block hrd
      rcases rs with ⟨rb1, rp1, rip1, rk1, rt1⟩
      rcases rd with ⟨rb2, rp2, rip2, rk2, rt2⟩
      dsimp only at h1 h2
      subst h1 h2
      simp [Std.rangesOverlap, h]
    · rfl

open Lean Meta Simp in
simproc ↓ [cir_exec] FHEntry.reduceMemcpyOverlapDiffBlock (Std.memcpyOverlap _ _ _ _ _) := fun e => do
  unless e.isAppOfArity ``Std.memcpyOverlap 5 do return .continue
  let args := e.getAppArgs
  let d := args[2]!
  let s := args[3]!
  unless d.isAppOfArity ``Ptr.loc 2 && s.isAppOfArity ``Ptr.loc 2 do return .continue
  let b1 := d.getArg! 0
  let p1 := d.getArg! 1
  let b2 := s.getArg! 0
  let p2 := s.getArg! 1
  if b1 == b2 then return .continue
  let neTy ← mkAppM ``Ne #[b2, b1]
  let some hne ← CIR.Tactic.omegaProof? neTy | return .continue
  let pf ← mkAppOptM ``FHEntry.memcpyOverlap_diff_block
    #[some args[0]!, some args[1]!, some b1, some b2, some p1, some p2, some args[4]!, some hne]
  return .done { expr := mkConst ``Bool.false, proof? := some pf }

@[cir_exec] theorem FHEntry.killRange_idem (lo hi : Nat) (bs : Nat → Option MemBlock) :
    killRange lo hi (killRange lo hi bs) = killRange lo hi bs := by
  funext b
  unfold killRange
  split
  · rcases bs b with _ | blk
    · rfl
    · dsimp only
      split <;> simp_all
  · rfl

@[cir_exec] theorem FHEntry.typedRange_ite_pos {α : Type} {n : Int} {len : Nat} {x y : α}
    (h1 : 0 ≤ n) (h2 : n.toNat ≤ len) :
    (if (1 : Nat) > 0 ∧ 0 ≤ n ∧ n % 1 = 0 ∧ 0 + (n / 1).toNat ≤ len then x else y) = x := by
  rw [Int.ediv_one, ite_eq_left_iff.mpr (fun hc => absurd ⟨by omega, h1, Int.emod_one n, by omega⟩ hc)]

@[cir_exec] theorem FHEntry.bitcast_heap_ite_pos {α : Type} {n : Nat} {x y : α}
    (h : 1 < n) :
    (if (1 : Nat) > 0 ∧ n % 1 = 0 ∧ n / 1 ≠ 1 ∧ n ≠ 0 then x else y) = x := by
  rw [ite_eq_left_iff.mpr (fun hc => absurd ⟨by omega, Nat.mod_one n, by omega, by omega⟩ hc)]

@[cir_exec] theorem FHEntry.bitcast_heap_ite_pos' {α : Type} {n : Nat} {x y : α}
    (h : 1 < n) :
    (if (1 : Nat) > 0 ∧ n % 1 = 0 ∧ ¬n / 1 = 1 ∧ ¬n = 0 then x else y) = x := by
  rw [ite_eq_left_iff.mpr (fun hc => absurd ⟨by omega, Nat.mod_one n, by omega, by omega⟩ hc)]

@[cir_exec] theorem FHEntry.ty_array_inj (t : Ty) (m n : Nat) :
    (t.array m = t.array n) = (m = n) :=
  propext ⟨fun h => by cases h; rfl, fun h => h ▸ rfl⟩

@[cir_exec] theorem FHEntry.bne_self_nat (n : Nat) : (n != n) = false := by simp

@[cir_exec] theorem FHEntry.ite_eq_zero_of_ne {α : Type} {n : Int} {x y : α} (h : n ≠ 0) :
    (if n = 0 then x else y) = y :=
  ite_eq_right_iff.mpr (fun hc => absurd hc h)


open Lean Meta Elab Tactic in
elab "cir_not_holds" : tactic => do
  let t ← whnfR (← instantiateMVars (← (← getMainGoal).getType))
  if t.isAppOfArity ``CIR.Res.holds 3 || t.isAppOfArity ``CIR.Mem.WF 1 ||
     t.isAppOfArity ``CIR.Module.RoGlobals 2 || t.isAppOfArity ``CIR.CJForest 2 then
    throwError "skip cir_close on state/spec goal"

macro "fh_vcg" : tactic =>
  `(tactic| (cir_run; all_goals (try cir_subst_nat); all_goals (try (first
      | (cir_strip_mdata; omega)
      | (cir_strip_mdata; cir_elems; (try cir_unwrap); omega)
      | exact ⟨_, _, rfl, rfl⟩
      | contradiction
      | (cir_not_holds; set_option maxHeartbeats 50000 in cir_close')))))




