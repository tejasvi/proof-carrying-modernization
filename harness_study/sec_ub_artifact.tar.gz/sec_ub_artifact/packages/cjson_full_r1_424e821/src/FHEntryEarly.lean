import FHEntryBase

open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit

namespace FHEntry

set_option maxHeartbeats 4000000

set_option maxHeartbeats 400000000 in
set_option cir.stepHeartbeats 20000000 in
theorem case_small (size : Int) (m : Mem) (b : Nat) (kd : BlockKind) (xs : List Int) (hwf : m.WF) (hnext : (Module.initMem module).next ≤ m.next) (hinit : ∀ b, b < (Module.initMem module).next → m.blocks b = (Module.initMem module).blocks b) (hs0 : 0 ≤ size) (hs63 : size < 2 ^ 63) (hlo : (Module.initMem module).next ≤ b) (hlen : xs.length = size.toNat) (hbm : m.blocks b = some ⟨kd, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hsz : size ≤ 4) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr (.loc b [.idx 0]), .int size] m (fun _ _ => True) := by
  have hn19 : (Module.initMem module).next = 19 := by rfl
  have hbl : b < m.next := Nat.lt_of_not_le fun hc => by rw [hwf b hc] at hbm; cases hbm
  have hlo' : 19 ≤ b := hn19 ▸ hlo
  have hnext' : 19 ≤ m.next := hn19 ▸ hnext
  clear hinit
  cir_start
  cir_vcg
  all_goals (try (exact absurd ‹fn_LLVMFuzzerTestOneInput.nothrow = false› (by decide)))
  all_goals (try cir_wf)
  all_goals (try omega)

set_option maxHeartbeats 400000000 in
set_option cir.stepHeartbeats 20000000 in
theorem case_bad0 (size : Int) (m : Mem) (b : Nat) (kd : BlockKind) (xs : List Int) (hwf : m.WF) (hnext : (Module.initMem module).next ≤ m.next) (hinit : ∀ b, b < (Module.initMem module).next → m.blocks b = (Module.initMem module).blocks b) (hs0 : 0 ≤ size) (hs63 : size < 2 ^ 63) (hlo : (Module.initMem module).next ≤ b) (hlen : xs.length = size.toNat) (hbm : m.blocks b = some ⟨kd, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hsz : 4 < size) (hb : xs[0]? ≠ some 48 ∧ xs[0]? ≠ some 49) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr (.loc b [.idx 0]), .int size] m (fun _ _ => True) := by
  have hn19 : (Module.initMem module).next = 19 := by rfl
  have hbl : b < m.next := Nat.lt_of_not_le fun hc => by rw [hwf b hc] at hbm; cases hbm
  have hlo' : 19 ≤ b := hn19 ▸ hlo
  have hnext' : 19 ≤ m.next := hn19 ▸ hnext
  clear hinit
  have hl0 : 0 < xs.length := by omega
  have hbe : xs[0] ≠ 48 ∧ xs[0] ≠ 49 := by
    rw [List.getElem?_eq_getElem hl0] at hb; simpa using hb
  obtain ⟨hne48, hne49⟩ := hbe
  have hw0 : wrap true 32 xs[0] = xs[0] := wrap_s32_self (by have := hxs _ (List.getElem_mem hl0); omega) (by have := hxs _ (List.getElem_mem hl0); omega)
  cir_start
  cir_vcg
  all_goals (try (exact absurd ‹fn_LLVMFuzzerTestOneInput.nothrow = false› (by decide)))
  all_goals (try cir_wf)
  all_goals (try omega)

set_option maxHeartbeats 400000000 in
set_option cir.stepHeartbeats 20000000 in
theorem case_bad2 (size : Int) (m : Mem) (b : Nat) (kd : BlockKind) (xs : List Int) (hwf : m.WF) (hnext : (Module.initMem module).next ≤ m.next) (hinit : ∀ b, b < (Module.initMem module).next → m.blocks b = (Module.initMem module).blocks b) (hs0 : 0 ≤ size) (hs63 : size < 2 ^ 63) (hlo : (Module.initMem module).next ≤ b) (hlen : xs.length = size.toNat) (hbm : m.blocks b = some ⟨kd, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hsz : 4 < size) (hb : xs[2]? ≠ some 48 ∧ xs[2]? ≠ some 49) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr (.loc b [.idx 0]), .int size] m (fun _ _ => True) := by
  have hn19 : (Module.initMem module).next = 19 := by rfl
  have hbl : b < m.next := Nat.lt_of_not_le fun hc => by rw [hwf b hc] at hbm; cases hbm
  have hlo' : 19 ≤ b := hn19 ▸ hlo
  have hnext' : 19 ≤ m.next := hn19 ▸ hnext
  clear hinit
  have hl2 : 2 < xs.length := by omega
  have hbe : xs[2] ≠ 48 ∧ xs[2] ≠ 49 := by
    rw [List.getElem?_eq_getElem hl2] at hb; simpa using hb
  obtain ⟨hne48, hne49⟩ := hbe
  have hw2 : wrap true 32 xs[2] = xs[2] := wrap_s32_self (by have := hxs _ (List.getElem_mem hl2); omega) (by have := hxs _ (List.getElem_mem hl2); omega)
  cir_start
  cir_vcg
  all_goals (try (exact absurd ‹fn_LLVMFuzzerTestOneInput.nothrow = false› (by decide)))
  all_goals (try cir_wf)
  all_goals (try omega)

set_option maxHeartbeats 400000000 in
set_option cir.stepHeartbeats 20000000 in
theorem case_bad3 (size : Int) (m : Mem) (b : Nat) (kd : BlockKind) (xs : List Int) (hwf : m.WF) (hnext : (Module.initMem module).next ≤ m.next) (hinit : ∀ b, b < (Module.initMem module).next → m.blocks b = (Module.initMem module).blocks b) (hs0 : 0 ≤ size) (hs63 : size < 2 ^ 63) (hlo : (Module.initMem module).next ≤ b) (hlen : xs.length = size.toNat) (hbm : m.blocks b = some ⟨kd, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hsz : 4 < size) (hb : xs[3]? ≠ some 48 ∧ xs[3]? ≠ some 49) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr (.loc b [.idx 0]), .int size] m (fun _ _ => True) := by
  have hn19 : (Module.initMem module).next = 19 := by rfl
  have hbl : b < m.next := Nat.lt_of_not_le fun hc => by rw [hwf b hc] at hbm; cases hbm
  have hlo' : 19 ≤ b := hn19 ▸ hlo
  have hnext' : 19 ≤ m.next := hn19 ▸ hnext
  clear hinit
  have hl3 : 3 < xs.length := by omega
  have hbe : xs[3] ≠ 48 ∧ xs[3] ≠ 49 := by
    rw [List.getElem?_eq_getElem hl3] at hb; simpa using hb
  obtain ⟨hne48, hne49⟩ := hbe
  have hw3 : wrap true 32 xs[3] = xs[3] := wrap_s32_self (by have := hxs _ (List.getElem_mem hl3); omega) (by have := hxs _ (List.getElem_mem hl3); omega)
  cir_start
  cir_vcg
  all_goals (try (exact absurd ‹fn_LLVMFuzzerTestOneInput.nothrow = false› (by decide)))
  all_goals (try cir_wf)
  all_goals (try omega)

end FHEntry
