import FHEntryBase

open CIR Gen.v0_fuzzing_cjson_read_fuzzer.Unit

namespace FHEntry

set_option maxHeartbeats 40000000

attribute [-cir_exec] Std.memcpyOverlap in
attribute [local cir_exec] memcpyOverlap_diff_block List.isEmpty_nil List.isEmpty_cons ite_val_int01 inRange_ite01 fitsTy_sel01 in
set_option cir.inline false in
set_option maxHeartbeats 40000000 in
set_option cir.stepHeartbeats 200000 in
theorem case_b0_f1_m0 (h_cJSON_ParseWithOpts : ∀ (bc base bg be : Nat) (kc kg ke : BlockKind) (ev : Val) (xs : List Int) (rnt : Int) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (he : ctx.gaddr "cJSON$global_error" = some be) (hbe : be < m.next) (hke : ke ≠ .readonly) (hev : m.blocks be = some ⟨ke, true, .record "error", ev⟩) (hevs : ∃ ej ep, ev = .agg [ej, ep]) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hz : ∃ k, base + k < xs.length ∧ xs[base + k]? = some 0) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hrnt : -2147483648 ≤ rnt ∧ rnt ≤ 2147483647) (hd1 : bg ≠ bc) (hd2 : be ≠ bc) (hd3 : bg ≠ be), Returns ctx fn_cJSON_ParseWithOpts.sym [.ptr (.loc bc [.idx base]), .ptr .null, .int rnt] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ be → m'.blocks b' = m.blocks b') ∧ (∃ ev', m'.blocks be = some ⟨ke, true, .record "error", ev'⟩) ∧ (r = some (.ptr .null) ∨ ∃ t : CJ, r = some (.ptr (listPtr [t.b] 0)) ∧ CJForest m' [t] ∧ (CJ.forestBlocks [t]).Nodup ∧ (∀ x ∈ CJ.forestBlocks [t], m.next ≤ x ∧ x < m'.next) ∧ CJ.forestPrintable xs.length [t] ∧ CJ.forestHeight [t] ≤ 1001))) (h_cJSON_PrintBuffered : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001) (fmt : Int) (hfmt : fmt = 0 ∨ fmt = 1), Returns ctx fn_cJSON_PrintBuffered.sym [.ptr (.loc t.b []), .int 1, .int fmt] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_Print : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001), Returns ctx fn_cJSON_Print.sym [.ptr (.loc t.b [])] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_PrintUnformatted : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001), Returns ctx fn_cJSON_PrintUnformatted.sym [.ptr (.loc t.b [])] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_Minify : FH.MinifySpec) (h_cJSON_Delete : ∀ (bg : Nat) (kg : BlockKind) (a r : Val) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (ts : List CJ) (m : Mem) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [a, .ptr (.fn "free"), r]⟩) (hgn : bg ∉ CJ.forestBlocks ts), Returns ctx fn_cJSON_Delete.sym [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF)) (size : Int) (m : Mem) (b : Nat) (kd : BlockKind) (xs : List Int) (hwf : m.WF) (hnext : (Module.initMem module).next ≤ m.next) (hinit : ∀ b, b < (Module.initMem module).next → m.blocks b = (Module.initMem module).blocks b) (hs0 : 0 ≤ size) (hs63 : size < 2 ^ 63) (hlo : (Module.initMem module).next ≤ b) (hlen : xs.length = size.toNat) (hbm : m.blocks b = some ⟨kd, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hsize : 0 ≤ size ∧ size ≤ 18446744073709551615) (hsmall : size < 2 ^ 61) (hx0 : xs[0]? = some 48) (hx2 : xs[2]? = some 49) (hx3 : xs[3]? = some 48) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr (.loc b [.idx 0]), .int size] m (fun _ _ => True) := by
  have hn19 : (Module.initMem module).next = 19 := by rfl
  have hro : Module.RoGlobals module m := by
    intro i g hi hc
    apply hinit i
    obtain ⟨hlt, _⟩ := List.getElem?_eq_some_iff.mp hi
    have h19 : module.globals.length = 19 := rfl
    omega
  have hroE : ∀ mm : Mem, (∀ i, i < 19 → mm.blocks i = m.blocks i) → Module.RoGlobals module mm := by
    intro mm hmm i g hi hc
    obtain ⟨hlt, _⟩ := List.getElem?_eq_some_iff.mp hi
    have h19 : module.globals.length = 19 := rfl
    rw [hmm i (by omega)]
    exact hro i g hi hc
  have hcopy : ∀ (f : Val → Val), (∀ x, f (Val.int x) = Val.int (wrap false 8 x)) →
      List.map f (List.take (size / 1).toNat (List.map Val.int xs)) ++
        List.drop (0 + (List.take (size / 1).toNat (List.map Val.int xs)).length)
          (List.replicate (size.toNat / 1) Val.undef) = List.map Val.int xs := by
    intro f hf
    have h1 : (size / 1).toNat = xs.length := by rw [Int.ediv_one]; omega
    have h2 : size.toNat / 1 = xs.length := by rw [Nat.div_one]; omega
    rw [h1, h2, List.take_of_length_le (by simp), List.length_map, Nat.zero_add, List.drop_replicate, Nat.sub_self,
      List.replicate_zero, List.append_nil, List.map_map]
    apply List.map_congr_left
    intro x hx
    simp only [Function.comp, hf, wrap_u8_self (hxs x hx).1 (hxs x hx).2]
  have hbl : b < m.next := Nat.lt_of_not_le fun hc => by rw [hwf b hc] at hbm; cases hbm
  have cirH_g8 : m.blocks 8 = some ⟨.global, true, .record "internal_hooks",
      .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ := (hinit 8 (by omega)).trans (by rfl)
  have cirH_g6 : m.blocks 6 = some ⟨.global, true, .record "error", .agg [.ptr .null, .int 0]⟩ :=
    (hinit 6 (by omega)).trans (by rfl)
  have hlo' : 19 ≤ b := hn19 ▸ hlo
  have hnext' : 19 ≤ m.next := hn19 ▸ hnext
  clear hinit hlo hnext hn19
  have hsm : size < 2305843009213693952 := by simpa using hsmall
  have h61 : xs.length < 2 ^ 61 := by simp only [Nat.reducePow]; omega
  have hnul : ∀ (j : Nat) (hj : j < xs.length), ¬¬wrap true 32 xs[j] = 0 → j = 4 + (size.toNat - 5) →
      ∃ k, 4 + k < xs.length ∧ xs[4 + k]? = some 0 := by
    intro j hj h hj'
    refine ⟨size.toNat - 5, by omega, ?_⟩
    have h1 := hxs xs[j] (List.getElem_mem hj)
    rw [wrap_s32_self (by omega) (by omega)] at h
    rw [← hj', List.getElem?_eq_getElem hj]
    simpa using h
  have hf01 : ∀ (c : Prop) [Decidable c], fitsTy (.int true 32) (if c then Val.int 1 else Val.int 0) = true := by
    intro c _
    by_cases hc : c <;> simp [hc, fitsTy, inRange]
  have hroK6 : ∀ mm : Mem, (∀ i, i < 19 → i ≠ 6 → mm.blocks i = m.blocks i) → Module.RoGlobals module mm := by
    intro mm hmm i g hi hc
    have hi19 : i < 19 := by
      obtain ⟨hlt, _⟩ := List.getElem?_eq_some_iff.mp hi
      have h19 : module.globals.length = 19 := rfl
      omega
    rw [hmm i hi19 ?_]
    · exact hro i g hi hc
    · intro hib
      rw [hib] at hi
      have h6 : module.globals[6]? = some g_cJSON_global_error := rfl
      rw [h6] at hi
      cases hi
      exact absurd hc (by decide)
  have hmono : ∀ {sym : String} {args : List Val} {mm : Mem} {P Q : Option Val → Mem → Prop},
      Returns ctx sym args mm P → (∀ r m', P r m' → Q r m') → Returns ctx sym args mm Q := by
    intro sym args mm P Q h hPQ
    unfold Returns Calls at *
    apply Res.holds_mono h
    rintro ⟨e, m'⟩ he
    cases e with
    | ret v => exact hPQ v m' he
    | _ => exact he
  have hdelE1 : ∀ (t : CJ) (mm : Mem), CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → mm.WF → 8 < mm.next →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      (∀ x ∈ CJ.forestBlocks [t], m.next + 11 ≤ x) →
      Returns ctx fn_cJSON_Delete.sym [.ptr (listPtr [t.b] 0)] mm (fun r m' => r = none ∧
        (∀ b, b < m.next + 11 → b < mm.next → m'.blocks b = mm.blocks b) ∧ mm.next ≤ m'.next ∧ m'.WF) := by
    intro t mm hf hnd hpr hwf' hb8 hgv hge
    refine hmono (h_cJSON_Delete 8 .global _ _ (by rfl) [t] mm hf hnd xs.length hpr hwf' hb8 hgv
      (fun h => by have := hge 8 h; omega)) ?_
    rintro r m' ⟨h1, h2, h3, h4⟩
    exact ⟨h1, fun b hb hb' => h2 b (fun hm => by have := hge b hm; omega) hb', h3, h4⟩
  have hdelE2 : ∀ (t : CJ) (mm : Mem), CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → mm.WF → 8 < mm.next →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      (∀ x ∈ CJ.forestBlocks [t], m.next + 11 ≤ x) →
      Returns ctx fn_cJSON_Delete.sym [.ptr (.loc t.b [])] mm (fun r m' => r = none ∧
        (∀ b, b < m.next + 11 → b < mm.next → m'.blocks b = mm.blocks b) ∧ mm.next ≤ m'.next ∧ m'.WF) :=
    hdelE1
  have hPB : ∀ (t : CJ) (mm : Mem) (fmt : Int), mm.WF → 19 ≤ mm.next → Module.RoGlobals module mm →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → CJ.forestHeight [t] ≤ 1001 →
      (fmt = 0 ∨ fmt = 1) →
      Returns ctx fn_cJSON_PrintBuffered.sym [.ptr (.loc t.b []), .int 1, .int fmt] mm (fun r m' => m'.WF ∧
        mm.next ≤ m'.next ∧ (∀ b, b < mm.next → m'.blocks b = mm.blocks b) ∧ (r = some (.ptr .null) ∨
        ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ mm.next ≤ pb ∧
          m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩)) :=
    fun t mm fmt h1 h2 h3 h4 h5 h6 h7 h8 h9 =>
      h_cJSON_PrintBuffered 8 .global xs.length t mm h1 h2 h3 (by rfl) (by omega) h4 h5 h6 h7 h61 h8 fmt h9
  have hPF : ∀ (t : CJ) (mm : Mem), mm.WF → 19 ≤ mm.next → Module.RoGlobals module mm →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → CJ.forestHeight [t] ≤ 1001 →
      Returns ctx fn_cJSON_Print.sym [.ptr (.loc t.b [])] mm (fun r m' => m'.WF ∧
        mm.next ≤ m'.next ∧ (∀ b, b < mm.next → m'.blocks b = mm.blocks b) ∧ (r = some (.ptr .null) ∨
        ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ mm.next ≤ pb ∧
          m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩)) :=
    fun t mm h1 h2 h3 h4 h5 h6 h7 h8 =>
      h_cJSON_Print 8 .global xs.length t mm h1 h2 h3 (by rfl) (by omega) h4 h5 h6 h7 h61 h8
  have hPU : ∀ (t : CJ) (mm : Mem), mm.WF → 19 ≤ mm.next → Module.RoGlobals module mm →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → CJ.forestHeight [t] ≤ 1001 →
      Returns ctx fn_cJSON_PrintUnformatted.sym [.ptr (.loc t.b [])] mm (fun r m' => m'.WF ∧
        mm.next ≤ m'.next ∧ (∀ b, b < mm.next → m'.blocks b = mm.blocks b) ∧ (r = some (.ptr .null) ∨
        ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ mm.next ≤ pb ∧
          m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩)) :=
    fun t mm h1 h2 h3 h4 h5 h6 h7 h8 =>
      h_cJSON_PrintUnformatted 8 .global xs.length t mm h1 h2 h3 (by rfl) (by omega) h4 h5 h6 h7 h61 h8
  have hMin : ∀ (cb : Nat) (mm : Mem), (∃ k, 4 + k < xs.length ∧ xs[4 + k]? = some 0) → mm.WF → cb < mm.next →
      mm.blocks cb = some ⟨.heap, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩ →
      Returns ctx fn_cJSON_Minify.sym [.ptr (.loc cb [.idx 4])] mm (fun r m' => r = none ∧ m'.WF ∧ mm.next ≤ m'.next ∧
        (∀ b', b' < mm.next → b' ≠ cb → m'.blocks b' = mm.blocks b') ∧
        ∃ ys', m'.blocks cb = some ⟨.heap, true, .array (.int false 8) xs.length, .arr ys'⟩) := by
    intro cb mm ⟨k, hk, hk0⟩ h1 h2 h3
    have hmb : FH.MinBuf mm cb xs.length xs (4 + k) := by
      unfold FH.MinBuf
      exact ⟨h3, rfl, fun x hx => ⟨by have := (hxs x hx).1; omega, (hxs x hx).2⟩, hk, hk0⟩
    refine hmono (h_cJSON_Minify cb xs.length 4 (4 + k) xs mm h1 h2 hmb (by omega)) ?_
    rintro r m' ⟨e1, e2, e3, e4, xs', e5⟩
    unfold FH.MinBuf at e5
    exact ⟨e1, e2, e3, e4, _, e5.1⟩
  clear h_cJSON_Delete h_cJSON_PrintBuffered h_cJSON_Print h_cJSON_PrintUnformatted h_cJSON_Minify
  obtain ⟨hl0, hx0e⟩ := List.getElem?_eq_some_iff.mp hx0
  obtain ⟨hl2, hx2e⟩ := List.getElem?_eq_some_iff.mp hx2
  obtain ⟨hl3, hx3e⟩ := List.getElem?_eq_some_iff.mp hx3
  cir_start
  fh_vcg
  all_goals (try (exact absurd ‹fn_LLVMFuzzerTestOneInput.nothrow = false› (by decide)))
  all_goals (try cir_wf)
  all_goals (try (exact hroE _ (fun i hi => by cir_simp_frame)))
  all_goals (try (exact hnul _ _ ‹_› (by omega)))
  all_goals (try (rename_i hfit; change fitsTy (Ty.int true 32) _ = false at hfit; rw [hf01] at hfit; cases hfit))
  all_goals (try (rcases cirH_post0bbbb with h0 | ⟨t, h0, hF, hN, hR, hPr, hHt⟩))
  all_goals (try (rw [show listPtr [t.b] 0 = .loc t.b [] from rfl] at h0))
  all_goals (try (subst h0))
  all_goals (try (have cirH_tb : cir_mem0.blocks t.b = some ⟨.heap, true, t.rt, cjRec [t.b] 0 t⟩ :=
                    CJForest.root hF (by simp)))
  all_goals (try (have htb6 : m.next + 11 ≤ t.b :=
                    (hR t.b (by simp only [CJ.forestBlocks, List.append_nil]; exact CJ.root_mem_blocks t)).1))
  all_goals (try (set_option cir.splitOr true in fh_vcg))
  all_goals (try cir_wf)
  all_goals (try (rename_i hfit; change fitsTy (Ty.int true 32) _ = false at hfit; rw [hf01] at hfit; cases hfit))
  all_goals (try (exact hroK6 _ (fun i hi hne => by cir_simp_frame)))
  all_goals (try (refine CJForest.frame hF ?_; intro b hb; have := hR b hb; cir_simp_frame; done))
  all_goals (try (exact hnul _ _ ‹_› (by omega)))
  all_goals (try (split <;> simp; done))
  -- worker-cjson-1's minify-branch closers (pn_proofs/fh/minify_handoff_v1.txt, 24ba1df5)
  all_goals (try (exfalso; have h0 := ‹size = 0›; cir_strip_mdata; omega))
  all_goals (try (exfalso; have h := ‹((_ : Nat) != _) = true›; simp at h; done))
  all_goals (try (rw [Nat.div_one, hlen]; done))
  all_goals (try (show Val.arr _ = Val.arr (List.map Val.int xs); congr 1; exact hcopy _ (fun x => rfl)))
  all_goals (try (rw [hcopy _ (fun x => rfl)]; simp only [List.length_map]; cir_strip_mdata; omega))
  all_goals (try (exact hN))
  all_goals (try (rename_i x hx; exact (hR x hx).1))
  -- after a print call: the printed block is live (free's check) and the memory stays well formed
  all_goals (try (rename_i hlive; simp [killRange_apply, cirH_post4bbbpppbb] at hlive; done))
  all_goals (try (
    have hpb : cir_w_cirH_post4bbb < cir_mem4.next := by
      apply Nat.lt_of_not_le
      intro hc
      have h0 := cirH_post4a _ hc
      rw [h0] at cirH_post4bbbpppbb
      cases cirH_post4bbbpppbb
    repeat (first | refine Mem.WF_killRange ?_ | refine Mem.WF_upd ?_ (by omega) _)
    exact cirH_post4a))
  -- free(printed): the printed block is a heap block (free?'s kind check through the scope exits)
  all_goals (try (
    rename_i heq hnk
    simp [killRange_apply, cirH_post4bbbpppbb] at heq
    subst heq
    rfl))

attribute [-cir_exec] Std.memcpyOverlap in
attribute [local cir_exec] memcpyOverlap_diff_block List.isEmpty_nil List.isEmpty_cons ite_val_int01 inRange_ite01 fitsTy_sel01 in
set_option cir.inline false in
set_option maxHeartbeats 40000000 in
set_option cir.stepHeartbeats 200000 in
theorem case_b0_f1_m1 (h_cJSON_ParseWithOpts : ∀ (bc base bg be : Nat) (kc kg ke : BlockKind) (ev : Val) (xs : List Int) (rnt : Int) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (he : ctx.gaddr "cJSON$global_error" = some be) (hbe : be < m.next) (hke : ke ≠ .readonly) (hev : m.blocks be = some ⟨ke, true, .record "error", ev⟩) (hevs : ∃ ej ep, ev = .agg [ej, ep]) (hc : bc < m.next) (hcc : m.blocks bc = some ⟨kc, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hz : ∃ k, base + k < xs.length ∧ xs[base + k]? = some 0) (h63 : xs.length < 2 ^ 63) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hrnt : -2147483648 ≤ rnt ∧ rnt ≤ 2147483647) (hd1 : bg ≠ bc) (hd2 : be ≠ bc) (hd3 : bg ≠ be), Returns ctx fn_cJSON_ParseWithOpts.sym [.ptr (.loc bc [.idx base]), .ptr .null, .int rnt] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b', b' < m.next → b' ≠ be → m'.blocks b' = m.blocks b') ∧ (∃ ev', m'.blocks be = some ⟨ke, true, .record "error", ev'⟩) ∧ (r = some (.ptr .null) ∨ ∃ t : CJ, r = some (.ptr (listPtr [t.b] 0)) ∧ CJForest m' [t] ∧ (CJ.forestBlocks [t]).Nodup ∧ (∀ x ∈ CJ.forestBlocks [t], m.next ≤ x ∧ x < m'.next) ∧ CJ.forestPrintable xs.length [t] ∧ CJ.forestHeight [t] ≤ 1001))) (h_cJSON_PrintBuffered : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001) (fmt : Int) (hfmt : fmt = 0 ∨ fmt = 1), Returns ctx fn_cJSON_PrintBuffered.sym [.ptr (.loc t.b []), .int 1, .int fmt] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_Print : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001), Returns ctx fn_cJSON_Print.sym [.ptr (.loc t.b [])] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_PrintUnformatted : ∀ (bg : Nat) (kg : BlockKind) (N : Nat) (t : CJ) (m : Mem) (hwf : m.WF) (hgn : 19 ≤ m.next) (hro : Module.RoGlobals module m) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩) (hf : CJForest m [t]) (hnd : (CJ.forestBlocks [t]).Nodup) (hpr : CJ.forestPrintable N [t]) (hN : N < 2 ^ 61) (hh : CJ.forestHeight [t] ≤ 1001), Returns ctx fn_cJSON_PrintUnformatted.sym [.ptr (.loc t.b [])] m (fun r m' => m'.WF ∧ m.next ≤ m'.next ∧ (∀ b, b < m.next → m'.blocks b = m.blocks b) ∧ (r = some (.ptr .null) ∨ ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ m.next ≤ pb ∧ m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩))) (h_cJSON_Minify : FH.MinifySpec) (h_cJSON_Delete : ∀ (bg : Nat) (kg : BlockKind) (a r : Val) (hg : ctx.gaddr "cJSON$global_hooks" = some bg) (ts : List CJ) (m : Mem) (hf : CJForest m ts) (hnd : (CJ.forestBlocks ts).Nodup) (N : Nat) (hpr : CJ.forestPrintable N ts) (hwf : m.WF) (hbg : bg < m.next) (hgv : m.blocks bg = some ⟨kg, true, .record "internal_hooks", .agg [a, .ptr (.fn "free"), r]⟩) (hgn : bg ∉ CJ.forestBlocks ts), Returns ctx fn_cJSON_Delete.sym [.ptr (listPtr (ts.map CJ.b) 0)] m (fun r m' => r = none ∧ (∀ b, b ∉ CJ.forestBlocks ts → b < m.next → m'.blocks b = m.blocks b) ∧ m.next ≤ m'.next ∧ m'.WF)) (size : Int) (m : Mem) (b : Nat) (kd : BlockKind) (xs : List Int) (hwf : m.WF) (hnext : (Module.initMem module).next ≤ m.next) (hinit : ∀ b, b < (Module.initMem module).next → m.blocks b = (Module.initMem module).blocks b) (hs0 : 0 ≤ size) (hs63 : size < 2 ^ 63) (hlo : (Module.initMem module).next ≤ b) (hlen : xs.length = size.toNat) (hbm : m.blocks b = some ⟨kd, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩) (hxs : ∀ x ∈ xs, 0 ≤ x ∧ x ≤ 255) (hsize : 0 ≤ size ∧ size ≤ 18446744073709551615) (hsmall : size < 2 ^ 61) (hx0 : xs[0]? = some 49) (hx2 : xs[2]? = some 49) (hx3 : xs[3]? = some 48) :
    Returns ctx fn_LLVMFuzzerTestOneInput.sym [.ptr (.loc b [.idx 0]), .int size] m (fun _ _ => True) := by
  have hn19 : (Module.initMem module).next = 19 := by rfl
  have hro : Module.RoGlobals module m := by
    intro i g hi hc
    apply hinit i
    obtain ⟨hlt, _⟩ := List.getElem?_eq_some_iff.mp hi
    have h19 : module.globals.length = 19 := rfl
    omega
  have hroE : ∀ mm : Mem, (∀ i, i < 19 → mm.blocks i = m.blocks i) → Module.RoGlobals module mm := by
    intro mm hmm i g hi hc
    obtain ⟨hlt, _⟩ := List.getElem?_eq_some_iff.mp hi
    have h19 : module.globals.length = 19 := rfl
    rw [hmm i (by omega)]
    exact hro i g hi hc
  have hcopy : ∀ (f : Val → Val), (∀ x, f (Val.int x) = Val.int (wrap false 8 x)) →
      List.map f (List.take (size / 1).toNat (List.map Val.int xs)) ++
        List.drop (0 + (List.take (size / 1).toNat (List.map Val.int xs)).length)
          (List.replicate (size.toNat / 1) Val.undef) = List.map Val.int xs := by
    intro f hf
    have h1 : (size / 1).toNat = xs.length := by rw [Int.ediv_one]; omega
    have h2 : size.toNat / 1 = xs.length := by rw [Nat.div_one]; omega
    rw [h1, h2, List.take_of_length_le (by simp), List.length_map, Nat.zero_add, List.drop_replicate, Nat.sub_self,
      List.replicate_zero, List.append_nil, List.map_map]
    apply List.map_congr_left
    intro x hx
    simp only [Function.comp, hf, wrap_u8_self (hxs x hx).1 (hxs x hx).2]
  have hbl : b < m.next := Nat.lt_of_not_le fun hc => by rw [hwf b hc] at hbm; cases hbm
  have cirH_g8 : m.blocks 8 = some ⟨.global, true, .record "internal_hooks",
      .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ := (hinit 8 (by omega)).trans (by rfl)
  have cirH_g6 : m.blocks 6 = some ⟨.global, true, .record "error", .agg [.ptr .null, .int 0]⟩ :=
    (hinit 6 (by omega)).trans (by rfl)
  have hlo' : 19 ≤ b := hn19 ▸ hlo
  have hnext' : 19 ≤ m.next := hn19 ▸ hnext
  clear hinit hlo hnext hn19
  have hsm : size < 2305843009213693952 := by simpa using hsmall
  have h61 : xs.length < 2 ^ 61 := by simp only [Nat.reducePow]; omega
  have hnul : ∀ (j : Nat) (hj : j < xs.length), ¬¬wrap true 32 xs[j] = 0 → j = 4 + (size.toNat - 5) →
      ∃ k, 4 + k < xs.length ∧ xs[4 + k]? = some 0 := by
    intro j hj h hj'
    refine ⟨size.toNat - 5, by omega, ?_⟩
    have h1 := hxs xs[j] (List.getElem_mem hj)
    rw [wrap_s32_self (by omega) (by omega)] at h
    rw [← hj', List.getElem?_eq_getElem hj]
    simpa using h
  have hf01 : ∀ (c : Prop) [Decidable c], fitsTy (.int true 32) (if c then Val.int 1 else Val.int 0) = true := by
    intro c _
    by_cases hc : c <;> simp [hc, fitsTy, inRange]
  have hroK6 : ∀ mm : Mem, (∀ i, i < 19 → i ≠ 6 → mm.blocks i = m.blocks i) → Module.RoGlobals module mm := by
    intro mm hmm i g hi hc
    have hi19 : i < 19 := by
      obtain ⟨hlt, _⟩ := List.getElem?_eq_some_iff.mp hi
      have h19 : module.globals.length = 19 := rfl
      omega
    rw [hmm i hi19 ?_]
    · exact hro i g hi hc
    · intro hib
      rw [hib] at hi
      have h6 : module.globals[6]? = some g_cJSON_global_error := rfl
      rw [h6] at hi
      cases hi
      exact absurd hc (by decide)
  have hmono : ∀ {sym : String} {args : List Val} {mm : Mem} {P Q : Option Val → Mem → Prop},
      Returns ctx sym args mm P → (∀ r m', P r m' → Q r m') → Returns ctx sym args mm Q := by
    intro sym args mm P Q h hPQ
    unfold Returns Calls at *
    apply Res.holds_mono h
    rintro ⟨e, m'⟩ he
    cases e with
    | ret v => exact hPQ v m' he
    | _ => exact he
  have hdelE1 : ∀ (t : CJ) (mm : Mem), CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → mm.WF → 8 < mm.next →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      (∀ x ∈ CJ.forestBlocks [t], m.next + 11 ≤ x) →
      Returns ctx fn_cJSON_Delete.sym [.ptr (listPtr [t.b] 0)] mm (fun r m' => r = none ∧
        (∀ b, b < m.next + 11 → b < mm.next → m'.blocks b = mm.blocks b) ∧ mm.next ≤ m'.next ∧ m'.WF) := by
    intro t mm hf hnd hpr hwf' hb8 hgv hge
    refine hmono (h_cJSON_Delete 8 .global _ _ (by rfl) [t] mm hf hnd xs.length hpr hwf' hb8 hgv
      (fun h => by have := hge 8 h; omega)) ?_
    rintro r m' ⟨h1, h2, h3, h4⟩
    exact ⟨h1, fun b hb hb' => h2 b (fun hm => by have := hge b hm; omega) hb', h3, h4⟩
  have hdelE2 : ∀ (t : CJ) (mm : Mem), CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → mm.WF → 8 < mm.next →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      (∀ x ∈ CJ.forestBlocks [t], m.next + 11 ≤ x) →
      Returns ctx fn_cJSON_Delete.sym [.ptr (.loc t.b [])] mm (fun r m' => r = none ∧
        (∀ b, b < m.next + 11 → b < mm.next → m'.blocks b = mm.blocks b) ∧ mm.next ≤ m'.next ∧ m'.WF) :=
    hdelE1
  have hPB : ∀ (t : CJ) (mm : Mem) (fmt : Int), mm.WF → 19 ≤ mm.next → Module.RoGlobals module mm →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → CJ.forestHeight [t] ≤ 1001 →
      (fmt = 0 ∨ fmt = 1) →
      Returns ctx fn_cJSON_PrintBuffered.sym [.ptr (.loc t.b []), .int 1, .int fmt] mm (fun r m' => m'.WF ∧
        mm.next ≤ m'.next ∧ (∀ b, b < mm.next → m'.blocks b = mm.blocks b) ∧ (r = some (.ptr .null) ∨
        ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ mm.next ≤ pb ∧
          m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩)) :=
    fun t mm fmt h1 h2 h3 h4 h5 h6 h7 h8 h9 =>
      h_cJSON_PrintBuffered 8 .global xs.length t mm h1 h2 h3 (by rfl) (by omega) h4 h5 h6 h7 h61 h8 fmt h9
  have hPF : ∀ (t : CJ) (mm : Mem), mm.WF → 19 ≤ mm.next → Module.RoGlobals module mm →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → CJ.forestHeight [t] ≤ 1001 →
      Returns ctx fn_cJSON_Print.sym [.ptr (.loc t.b [])] mm (fun r m' => m'.WF ∧
        mm.next ≤ m'.next ∧ (∀ b, b < mm.next → m'.blocks b = mm.blocks b) ∧ (r = some (.ptr .null) ∨
        ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ mm.next ≤ pb ∧
          m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩)) :=
    fun t mm h1 h2 h3 h4 h5 h6 h7 h8 =>
      h_cJSON_Print 8 .global xs.length t mm h1 h2 h3 (by rfl) (by omega) h4 h5 h6 h7 h61 h8
  have hPU : ∀ (t : CJ) (mm : Mem), mm.WF → 19 ≤ mm.next → Module.RoGlobals module mm →
      mm.blocks 8 = some ⟨.global, true, .record "internal_hooks", .agg [.ptr (.fn "malloc"), .ptr (.fn "free"), .ptr (.fn "realloc")]⟩ →
      CJForest mm [t] → (CJ.forestBlocks [t]).Nodup → CJ.forestPrintable xs.length [t] → CJ.forestHeight [t] ≤ 1001 →
      Returns ctx fn_cJSON_PrintUnformatted.sym [.ptr (.loc t.b [])] mm (fun r m' => m'.WF ∧
        mm.next ≤ m'.next ∧ (∀ b, b < mm.next → m'.blocks b = mm.blocks b) ∧ (r = some (.ptr .null) ∨
        ∃ (pb n : Nat) (vs : List Val), r = some (.ptr (.loc pb [.idx 0])) ∧ mm.next ≤ pb ∧
          m'.blocks pb = some ⟨.heap, true, .array (.int false 8) n, .arr vs⟩)) :=
    fun t mm h1 h2 h3 h4 h5 h6 h7 h8 =>
      h_cJSON_PrintUnformatted 8 .global xs.length t mm h1 h2 h3 (by rfl) (by omega) h4 h5 h6 h7 h61 h8
  have hMin : ∀ (cb : Nat) (mm : Mem), (∃ k, 4 + k < xs.length ∧ xs[4 + k]? = some 0) → mm.WF → cb < mm.next →
      mm.blocks cb = some ⟨.heap, true, .array (.int false 8) xs.length, .arr (xs.map .int)⟩ →
      Returns ctx fn_cJSON_Minify.sym [.ptr (.loc cb [.idx 4])] mm (fun r m' => r = none ∧ m'.WF ∧ mm.next ≤ m'.next ∧
        (∀ b', b' < mm.next → b' ≠ cb → m'.blocks b' = mm.blocks b') ∧
        ∃ ys', m'.blocks cb = some ⟨.heap, true, .array (.int false 8) xs.length, .arr ys'⟩) := by
    intro cb mm ⟨k, hk, hk0⟩ h1 h2 h3
    have hmb : FH.MinBuf mm cb xs.length xs (4 + k) := by
      unfold FH.MinBuf
      exact ⟨h3, rfl, fun x hx => ⟨by have := (hxs x hx).1; omega, (hxs x hx).2⟩, hk, hk0⟩
    refine hmono (h_cJSON_Minify cb xs.length 4 (4 + k) xs mm h1 h2 hmb (by omega)) ?_
    rintro r m' ⟨e1, e2, e3, e4, xs', e5⟩
    unfold FH.MinBuf at e5
    exact ⟨e1, e2, e3, e4, _, e5.1⟩
  clear h_cJSON_Delete h_cJSON_PrintBuffered h_cJSON_Print h_cJSON_PrintUnformatted h_cJSON_Minify
  obtain ⟨hl0, hx0e⟩ := List.getElem?_eq_some_iff.mp hx0
  obtain ⟨hl2, hx2e⟩ := List.getElem?_eq_some_iff.mp hx2
  obtain ⟨hl3, hx3e⟩ := List.getElem?_eq_some_iff.mp hx3
  cir_start
  fh_vcg
  all_goals (try (exact absurd ‹fn_LLVMFuzzerTestOneInput.nothrow = false› (by decide)))
  all_goals (try cir_wf)
  all_goals (try (exact hroE _ (fun i hi => by cir_simp_frame)))
  all_goals (try (exact hnul _ _ ‹_› (by omega)))
  all_goals (try (rename_i hfit; change fitsTy (Ty.int true 32) _ = false at hfit; rw [hf01] at hfit; cases hfit))
  all_goals (try (rcases cirH_post0bbbb with h0 | ⟨t, h0, hF, hN, hR, hPr, hHt⟩))
  all_goals (try (rw [show listPtr [t.b] 0 = .loc t.b [] from rfl] at h0))
  all_goals (try (subst h0))
  all_goals (try (have cirH_tb : cir_mem0.blocks t.b = some ⟨.heap, true, t.rt, cjRec [t.b] 0 t⟩ :=
                    CJForest.root hF (by simp)))
  all_goals (try (have htb6 : m.next + 11 ≤ t.b :=
                    (hR t.b (by simp only [CJ.forestBlocks, List.append_nil]; exact CJ.root_mem_blocks t)).1))
  all_goals (try (set_option cir.splitOr true in fh_vcg))
  all_goals (try cir_wf)
  all_goals (try (rename_i hfit; change fitsTy (Ty.int true 32) _ = false at hfit; rw [hf01] at hfit; cases hfit))
  all_goals (try (exact hroK6 _ (fun i hi hne => by cir_simp_frame)))
  all_goals (try (refine CJForest.frame hF ?_; intro b hb; have := hR b hb; cir_simp_frame; done))
  all_goals (try (exact hnul _ _ ‹_› (by omega)))
  all_goals (try (split <;> simp; done))
  -- worker-cjson-1's minify-branch closers (pn_proofs/fh/minify_handoff_v1.txt, 24ba1df5)
  all_goals (try (exfalso; have h0 := ‹size = 0›; cir_strip_mdata; omega))
  all_goals (try (exfalso; have h := ‹((_ : Nat) != _) = true›; simp at h; done))
  all_goals (try (rw [Nat.div_one, hlen]; done))
  all_goals (try (show Val.arr _ = Val.arr (List.map Val.int xs); congr 1; exact hcopy _ (fun x => rfl)))
  all_goals (try (rw [hcopy _ (fun x => rfl)]; simp only [List.length_map]; cir_strip_mdata; omega))
  all_goals (try (exact hN))
  all_goals (try (rename_i x hx; exact (hR x hx).1))
  -- after a print call: the printed block is live (free's check) and the memory stays well formed
  all_goals (try (rename_i hlive; simp [killRange_apply, cirH_post4bbbpppbb] at hlive; done))
  all_goals (try (
    have hpb : cir_w_cirH_post4bbb < cir_mem4.next := by
      apply Nat.lt_of_not_le
      intro hc
      have h0 := cirH_post4a _ hc
      rw [h0] at cirH_post4bbbpppbb
      cases cirH_post4bbbpppbb
    repeat (first | refine Mem.WF_killRange ?_ | refine Mem.WF_upd ?_ (by omega) _)
    first | exact cirH_post4a | exact Mem.WF_mono cirH_post4a (by omega)))
  -- free(printed): the printed block is a heap block (free?'s kind check through the scope exits)
  all_goals (try (
    rename_i heq hnk
    simp [killRange_apply, cirH_post4bbbpppbb] at heq
    subst heq
    rfl))

end FHEntry
